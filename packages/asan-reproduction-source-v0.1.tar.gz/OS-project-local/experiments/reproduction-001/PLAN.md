# reproduction-001: portable ARM64 reproduction entry

| Field | Value |
| --- | --- |
| `controlled_object_id` | `reproduction-001-plan` |
| `exact_version` | `v0.1` |
| `status` | `frozen_for_main_validation` |
| `document_role` | `current_engineering_validation_plan` |
| `created_at` | `2026-11-25 (Asia/Shanghai)` |
| `last_verified_at` | `2026-11-25 (Asia/Shanghai)` |
| `approval_state` | User explicitly approved fresh exported-package acquisition, preparation and main validation only; cumulative 7200 s, download 1800 s |
| `freeze_state` | `frozen_for_main_validation` |
| `supersedes` | `v0.0` |
| `next_allowed_version` | `v0.2` |
| `major_version_authorization` | `absent` |
| `archive_ref` | [Version archive v0.1](VERSION_ARCHIVE.md#v01) |
| `operator_guide` | [Fresh-machine reproduction guide](../../docs/reproduction.md) |

## Purpose and authorization boundary

Provide an entry point that can acquire verified public inputs, build a new local launcher and guest dependency base, bind new campaign configurations and collect independently verifiable evidence on another supported Mac. It must operate without the original author's ignored disks, compiled launcher, private runtime state or historical authorization files.

This is an engineering validation object. It does not replace the scientific plans [`exp-001` v0.2](../../docs/governance/snapshots/exp-001-plan-v0.2.md.snapshot) and [`exp-002` v0.2](../../docs/governance/snapshots/exp-002-plan-v0.2.md.snapshot), add a new paper claim, or retrospectively change their frozen bytes and runs. The linked immutable snapshots preserve the original plan bytes and original-path restoration semantics; their historical relative links and authorizations are not activated by a new session. The six-workload time method and redzone design remain those plans' designs. New-machine performance evidence belongs to new campaigns and run IDs.

The current user instruction explicitly approves one fresh exported-package main-validation sequence: acquire public inputs, prepare a clean VM base, collect three independent main batches and verify them, with cumulative machine activity at most 7200 s and downloads at most 1800 s. Use the same 2 vCPU/3 GiB/per-disk 30 GiB bounds. Do not reuse old assets, run an extension, renew the allowance through another ID or change the frozen scientific design. Local implementation, English documentation and offline checks remain in scope. Prior D-025/D-026 authorization stays attached to the original campaigns. Fresh-base preparation and main acceptance remain pending until actual evidence is recorded; extension execution has no approval in this validation.

The readable ID `reproduction-001` is a local naming exception to the governance default `exp-NNN`: it distinguishes infrastructure validation from the unchanged scientific experiments. It applies only to this plan and preparation-stage IDs for its lifecycle, creates no new scientific arm and does not rename historical runs. Any later naming migration must preserve an explicit ID mapping and the prior evidence.

## Entry point and source identity

Use `python3 -B scripts/asan-reproduce.py --root . <stage>` with the public template [`config/asan-reproduction.json`](../../config/asan-reproduction.json). Stages are `check`, `fetch`, `prepare`, `freeze`, `run` and `verify`. The template contains no claim of execution permission. Record the actual source commit where available and a file-level source snapshot/hash inventory, including uncommitted changes. An uncommitted source identity is never presented as a release commit.

Work takes place only in the independent `OS-project-local` repository, with `.local/workspace-role` equal to `work` and no remotes. In the full source repository, follow its `AGENTS.md` and `docs/governance/FILE_MANAGEMENT.md`; those project-maintenance records are intentionally omitted from the standalone bundle. The public source bundle uses its standalone reproduction workspace checker: canonical work directory, independent `.git`, work marker and no remote; a new `git init` without a commit is accepted with recorded source snapshots and `uncommitted` revision. This scoped public-bundle bootstrap does not alter the full source repository's stricter historical checker or fabricate a release history. Maintaining project releases continues to use the independent release repository. No release mutation, commit, push or tag is authorized by this plan.

## Fixed inputs and measurement design

| Item | Requirement |
| --- | --- |
| Host target | Apple Silicon / macOS / Apple Virtualization.framework; Python >=3.9; Xcode Command Line Tools, Git and documented system utilities |
| Ubuntu input | Pinned `noble/20261017` ARM64 cloud disk and boot assets; verify known SHA-256 values before use |
| Guest | Ubuntu 24.04.5 LTS/aarch64, Linux 6.8.0-147-generic |
| Toolchain | Clang/LLVM/compiler-rt 18.1.3, CMake 3.28.3, Ninja 1.11.1; exact package pins checked and complete package list recorded |
| LLVM workload source | `https://github.com/llvm/llvm-test-suite.git`, official tag `llvmorg-18.1.3`, commit `72a946a42cbce06afef68b2326ff6c3869d09799` |
| Source lock | [222 paths](../../workloads/llvm-suite-lock.json), SHA-256 `169b5f76f4cd73bd0d9ad0c25d3f636e9dc316d0bd9369d3cf4631e2ba0a56f0` |
| Workloads | `bisort 700000`; `em3d 1024 1000 125`; `mst 1000`; `perimeter 10`; `treeadd 22`; `tsp 1024000` |
| Main factor | Baseline versus `-fsanitize=address`; other compiler/link settings and input bytes equal |
| Extension factor | Same ASan binary; only `redzone` and `max_redzone` jointly change 32 B to 64 B |
| Common flags | C `-O2 -g -fno-omit-frame-pointer -std=gnu89`; C++ omits the C standard option; no extra CMake Release flags |
| Sampling | Three independent VM batches per campaign, one warmup and five timed executions per workload/arm/batch; frozen alternating/rotating order |
| Metric | Upstream `timeit real`, seconds, process start/init/output included; compile and output-comparison work excluded |
| Statistics | Six-workload equal arithmetic mean of ratios per batch; across three batches mean and sample SD; per-workload, geometric and no-`mst` sensitivity outputs retained |

The baseline ASan option set is `detect_leaks=0:redzone=32:max_redzone=32:quarantine_size_mb=0:thread_local_quarantine_size_kb=0:malloc_context_size=0:detect_stack_use_after_return=0:halt_on_error=1:exitcode=86`. Preserve `LC_ALL=C`, `TZ=UTC`, a cleared `LD_PRELOAD`, and the same core affinity/resource limits. LLVM 18.1.3 normalizes requested `malloc_context_size=0` to effective 1; verify and record this rather than silently changing the requested option.

The scientific interpretation and verdict rules remain the referenced frozen plans. New hardware and setup differences must be reported. This package cannot validate the original paper's 1.73x SPEC CPU2006 number, its Table 1 memory metric, a universal absence of false positives or an ISA-only causal explanation.

## Stages and evidence

1. **check:** Inspect the work zone, host architecture/framework, Python/system tools, template and source-lock integrity. Report missing prerequisites without fetching or starting a VM. Unit tests are offline and must exercise real assertions, including boundary and refusal cases.
2. **fetch:** Create a new session and bounded activity ledger. Obtain pinned Ubuntu assets and exact LLVM sources using the local Git CLI. Record URLs, retrieval times, bytes, SHA-256 and source version. Fail on a missing/ambiguous checksum or source mismatch; retain partial/failed acquisition evidence. No moving tag, fallback mirror or unpinned replacement is accepted automatically.
3. **prepare:** Build and ad-hoc sign the launcher from current recorded source/SDK; initialize a new disposable guest from the verified original disk. Install the pinned dependencies, record their complete versions and provenance, verify kernel/toolchain/runtime option diagnostics and normal tiny ASan probes, power off normally and hash the sealed dependency base. Do not copy an old measured guest as the public bootstrap route.
4. **freeze:** Bind the reviewed plan/configuration, source lock, observed host/power state and accepted fresh session assets to new create-only campaign JSON files. Record newly built disk/launcher/package hashes after validation. Historical signed-binary/disk hashes are evidence references, not required equality targets on another machine.
5. **run:** Require the frozen new configuration and sufficient remaining campaign/session allowance. Reuse the unchanged guest measurement and audit logic. Create a new VM/run per attempt. Seal three valid main batches before extension collection. Extension uses independent new samples and identical binary hashes between its arms.
6. **verify:** Validate sample identities, order, outputs, environment, flags, binary equality where required, inner/outer SHA manifests and cross-batch independence. Recompute statistics into create-only derived output and compare completion references. A process exit or a generated JSON file alone is insufficient.

Preparation records use unique `runs/run-<UTC>-reproduction-001-aNN/` with the stage kind. The established collector uses `runs/run-<UTC>-exp-001-aNN/` or `exp-002` IDs. Sessions, assets, launchers, sparse disks and dependency bases live in ignored `.local/asan-reproduction/sessions/<session>/`. Campaign summaries and completion receipts are `results/<campaign>/summary.json` and `completion.json`, with the contributing run IDs. Source/configuration/commands/raw output/validation and resource timing must be retained for successful, failed and stopped attempts. New IDs never overwrite an existing directory or reset a task's approved allowance.

## Isolation, resource envelope and stopping

The table below records the user-approved main-validation envelope. Bind the instruction and exact plan/source/configuration hashes before active stages. Each stage is bounded both by its local cap and the remaining cumulative session allowance; include failed stages, preparation, collection, shutdown and audit. Manual review waiting is separately recorded. Creating another session does not renew this approved total. A leftover balance does not authorize extension execution.

| Scope | Approved main-validation upper bound |
| --- | --- |
| Session cumulative machine activity | 7200 seconds, explicitly supplied at acquisition; includes all stages, failures, shutdown and verification |
| Fetch | 1800 seconds maximum download/acquisition activity; pinned bounded downloads; record actual downloaded bytes |
| Prepare | 900 seconds, including bounded provisioning and shutdown |
| Freeze operation | 120 seconds; its supplied activity-limit argument separately binds the next campaign's cap |
| Main campaign only | 3600 seconds; per-attempt and guest subordinate limits inherited from scientific plans; no more than four attempts |
| Extension | Not authorized by this validation; separate future scope and budget required |
| Guest allocation | 2 vCPU, 3 GiB memory, 30 GiB sparse-disk maximum |
| Measurement process | Non-root, 2 CPU quota, 2 GiB memory, no swap, 128 PIDs, 768 MiB tmpfs, build jobs 2, core dumps off |
| Host gate | Normal memory pressure, at least 20 GiB free space, fixed/recorded AC power mode |

Guest dependency installation may use guest administrator privileges only. Disable SSH and external guest interfaces after provisioning; measurement additionally uses a private network namespace. No host shared directory, inbound port, host credentials or real user data is exposed. Only boot input and the narrowly scoped experiment payload enter the guest. Inputs/code must be read-only during measurement.

Stop the affected instance on timeout, exhausted budget, host resource threshold, checksum/source/environment drift, isolation failure, filesystem/I/O error, OOM, output mismatch or unexpected ASan diagnostic. Request normal guest poweroff first; after the bounded grace period stop only the current launcher/instance. Keep logs, resource receipts and failed disks under local control. Do not disable TLS/APT/date/signature validation, drop pins, increase limits or repeat until a desired ratio is observed. A retry receives a new run ID, explicit failure linkage and the remaining shared allowance. Changes to environment or acceptance criteria require a recorded next plan version before further collection.

## Acceptance and pending validation

Offline engineering acceptance requires coherent help/guide/template, no dependencies on old `.local` state or historical execution grants, valid manifests and tests that reject malformed evidence, drift, duplicate/partial samples, exhausted budgets, existing outputs and release-zone writes. Record actual test commands and results separately; this plan does not assert that they passed merely because they are specified.

Fresh main-validation acceptance requires a newly acquired verified input set from the exported package, a newly built/signed launcher, clean guest provisioning with pinned versions and accepted tiny runtime probes, a frozen new main campaign, three valid independently created main batches and verification/recomputation. Preserve an inventory proving old `exp-001`/`exp-002` plan/config/run/result bytes did not change. The fresh execution evidence must identify host/guest/settings, source/config hashes, all commands, raw samples, failed/invalid counts, resources and final dispositions. A complete two-experiment fresh-machine acceptance would additionally require three independently verified extension batches under separate future authorization; it is not the completion condition for this main-only task.

At the v0.1 freeze, fresh exported-package download, clean-base preparation and main collection results are **not yet observed**; each remains pending. The main-only execution budget is approved as recorded above, while extension execution is not approved. Original known results are exp-001 `2.270457x` and exp-002 `1.079945x` from their existing campaigns; these are known during development and must not be described as unseen outcomes or new package acceptance. Existing x86/ARM environment checks and pilot results remain separate evidence.

Completion claims are limited to observed milestones: implementation and offline checks, clean-base preparation, main-campaign acceptance, extension acceptance and full fresh-machine acceptance are distinct statuses. Later revisions append the known-results context, affected scope, recovery snapshot/hash and rerun decision to the [version archive](VERSION_ARCHIVE.md).
