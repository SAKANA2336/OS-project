# Reproduction-plan recovery snapshots

These `.md.snapshot` files preserve exact bytes of the plan at the recorded version. They are immutable recovery inputs, not active execution plans. A snapshot retains the original plan's role labels and relative links for restoration at `experiments/reproduction-001/PLAN.md`; those links are not interpreted relative to this directory.

Read the current [`PLAN.md`](../PLAN.md) and its append-only [`VERSION_ARCHIVE.md`](../VERSION_ARCHIVE.md) first. Verify a snapshot's SHA-256 against its archive entry before using it. A later correction creates the next continuous plan version and a new snapshot; do not overwrite a snapshot or historical run. Restoring a document does not grant download, VM, experiment, commit, push or tag authorization.
