# reproduction-001-plan version archive

Current operative document: [PLAN.md](PLAN.md), `reproduction-001-plan v0.1 / frozen_for_main_validation`.

This archive is append-only. It records the context and recovery material for each version; an entry does not itself authorize execution or claim acceptance.

## v0.0

- `controlled_object_id`: `reproduction-001-plan`; `exact_version`: `v0.0`.
- Date: 2026-11-25 (Asia/Shanghai). Initial independent engineering-validation object; next allowed version is `v0.1`; major-version authorization is absent.
- Authority and status: the current user task authorizes a public reproducibility implementation, English documentation and offline checks. Fresh download/provisioning/VM-collection budget for an agent remains pending. This entry does not extend original D-025/D-026 campaign permissions.
- Previous requirement: the historical formal route depended on one author's ignored prepared disk, signed launcher, fixed local asset paths and original approval records. Those frozen scientific plans/configurations/runs must remain unchanged.
- New content and reason: a portable staged entry point (`check`, `fetch`, `prepare`, `freeze`, `run`, `verify`) with fixed public input verification, locally built/signed launcher, fresh pinned dependency provisioning, new asset/environment bindings, create-only evidence and a cumulative session ledger. A standalone extracted source bundle may initialize an independent remote-free work Git repository with no initial commit, recording `uncommitted` plus source hashes; it does not change the full source repository's historical role checker.
- Controlled scope: `scripts/asan-reproduce.py`, its public template and guide, and new `reproduction-001` validation evidence. Scientific measurement/aggregation logic follows unchanged exp-001/exp-002 v0.2. No new workload, paper claim, memory metric, success threshold or scientific result is adopted here.
- Naming exception: readable `reproduction-001` distinguishes infrastructure validation from `exp-NNN` scientific arms. It applies only to this object's plan and stage records; historical IDs stay unchanged. Rationale, migration boundary and lifecycle are recorded in the plan.
- Known results at creation: original ARM64 exp-001 `2.270457x` and exp-002 `1.079945x` are already exposed, as are old pilots/environment checks. No fresh-machine public-package acquisition, provisioning or collection result is asserted. Offline acceptance is established only by actual test records, not by this plan.
- Resource design: operator-selected total session activity up to 10800 s; proposed maximum fetch 1800 s, prepare 900 s, freeze operation 120 s and each campaign 3600 s. Failed activity is included; new IDs do not replenish an approved task budget. The exact approval and consumed balance must be recorded before active stages.
- Alternatives not adopted: copying the old mutable VM disk; requiring another Mac to match the old ad-hoc signed binary hash; running benchmarks directly on the daily host; importing old execution grants; weakening package/source pins on failure; rewriting old raw evidence; resetting consumed budget by choosing another ID; presenting repeated timings as independent VM batches.
- Compatibility and migration: supports Apple Silicon/macOS/Apple Virtualization.framework with Python >=3.9. New bundle/workspace/session/config/run/result IDs are independent of old runtime state. Original exp-001/exp-002 plans, frozen configurations, runs and results retain their original bytes; no historical ID or author is rewritten. Other host platforms remain unsupported by this entry point.
- Affected historical runs: none. Rerun decision: none is required merely for engineering changes; new-machine end-to-end acceptance requires its own new recorded execution after an applicable budget is allocated. It must not be backdated as pre-registration for old results.
- Plan SHA-256: `431816ea57a3f3640d4f6ea1b4c62150d596bae58f505012fdb7a31dc49c9d44`.
- Immutable recovery snapshot: [snapshots/reproduction-001-plan-v0.0.md.snapshot](snapshots/reproduction-001-plan-v0.0.md.snapshot), byte-identical to this version's operative plan. [Snapshot semantics](snapshots/README.md).
- Git recovery: no commit or tag is created under this task. If later separately authorized, append the actual commit reference without rewriting this initial history.

## v0.1

- `controlled_object_id`: `reproduction-001-plan`; `exact_version`: `v0.1`.
- Date: 2026-11-25 (Asia/Shanghai). Supersedes v0.0; next allowed version is v0.2; major-version authorization is absent. Status is `frozen_for_main_validation`, not complete.
- Explicit authorization: the user approved a clean exported-package main reproduction only, with cumulative machine activity <=7200 s, download/acquisition <=1800 s, VM 2 vCPU/3 GiB and each sparse disk <=30 GiB. This permits new public acquisition, clean-base provisioning, three independent main batches and verification. It does not authorize extension execution, reuse of old runtime assets, increased limits, commits, pushes or tags.
- Previous/revised requirements: replace the v0.0 pending execution/proposed 10800 s two-experiment envelope with a frozen main-only 7200 s allowance. Fetch <=1800 s, prepare <=900 s, freeze operation <=120 s and main campaign <=3600 s are subordinate caps; all activity, failures, shutdown and verification also consume the single cumulative total. Unused balance cannot authorize the extension or be renewed by a new session ID.
- Reason and scope: perform the concrete clean-environment main acceptance now authorized by the user, using the exported public source package rather than any author's old assets. The implemented extension recipe stays documented as a separate later task requiring its own explicit scope and budget.
- Known results at freeze: original exp-001 2.270457x and exp-002 1.079945x remain exposed historical observations. Runtime/exporter offline tests have been reported passing (20 + 11 checks); their command logs are implementation evidence, not new guest measurements. Fresh acquisition, clean-base provisioning and main-collection outcomes are not yet observed at this freeze.
- Scientific compatibility: no workload, compiler flag, ASan option, batch design, statistic, verdict threshold or original exp-001/exp-002 byte is changed. The v0.0 snapshot and archive entry are preserved verbatim. New actual evidence receives new session/campaign/run IDs.
- Alternatives not adopted: immediately running both experiments within the generic 10800 s capability; treating the current 7200 s balance as extension permission; borrowing old disks/launchers; claiming a pending main run has passed; rewriting v0.0 to imply earlier execution permission.
- Affected runs and rerun decision: no historical run is affected and none is invalidated. Execute new main-validation runs under v0.1; no extension run is permitted by this revision. Freeze runtime asset hashes only after the new inputs and dependencies pass preflight.
- Plan SHA-256: `e5bcecd56d64ef756b5c47b7d348dcc8a9bdcf134c32f4dff2ddfa6190c03626`.
- Immutable recovery snapshot: [snapshots/reproduction-001-plan-v0.1.md.snapshot](snapshots/reproduction-001-plan-v0.1.md.snapshot). Snapshot is byte-identical to the v0.1 operative plan; v0.0 remains independently recoverable.
- Completion boundary: clean-base and main acceptance remain pending until verified new logs exist. A successful main-only task would not establish fresh-machine extension acceptance or reproduce the paper's original SPEC number.
