# Clean-source main reproduction validation

The standalone public entry completed a fresh Ubuntu acquisition, exact LLVM source retrieval, locally rebuilt/signed launcher, verified dependency base and three independent ARM64 VM batches on November 25, 2026 (Asia/Shanghai). No original prepared VM disk or signed binary was reused.

The new ASan/baseline wall-clock result is **2.273131x ± 0.006420x** across **three independent batches**, with 180 measured observations and 36 warmups. This validates the new execution workflow on this host. It remains a six-Olden-workload method/direction replication, not a numerical replication of SPEC CPU2006. The original formal results are unchanged.

[Summary](summary.json), [completion](completion.json), [inert execution-configuration snapshot](effective.json.snapshot), [activity ledger](activity.jsonl) and [CSV provenance](provenance.json) preserve the source links. The byte-exact per-batch CSVs are under `evidence/`. Full raw output, build commands, source snapshots, environment and two-layer seals remain in the logical archive recorded by provenance; run the guide's `verify` command there to repeat the complete audit. The public CSVs support recomputing headline statistics.

Two Git transport failures, a pre-launch host-memory-pressure stop and a results-parent initialization failure were preserved. Git succeeded after honoring the existing OS HTTP(S) proxy only in the child environment, without changing global/system settings or recording proxy values. The initialization repair occurred before any measurement batch and used a new campaign with fresh code bindings. The same-session ledger retained the failed activity. Total ledger activity was 671.707313 s, of which acquisition was 135.228419 s; final independent auditing is recorded separately. Both are within the approved ceilings.

The host was an Apple M1 MacBookAir10,1 with 8 GiB RAM; each VM used 2 vCPUs/3 GiB. Guest and workload versions follow the [reproduction guide](../../docs/reproduction.md) and its frozen engineering plan. All three VMs shut down normally. The extension was not rerun under this authorization. Another group member's independent cross-machine verification remains a separate handoff task.

The configuration snapshot is a byte-exact historical record of the completed session, not authority for a new run. Follow the guide to prepare new assets and freeze a new configuration.
