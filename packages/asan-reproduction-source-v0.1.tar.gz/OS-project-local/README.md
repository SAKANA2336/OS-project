# Reproduce the ARM64 ASan experiments

This guide describes a fresh-machine route for the six-workload Olden ASan time experiment and its 32 B versus 64 B heap-redzone extension. The entry point is `scripts/asan-reproduce.py`; its portable template is [`config/asan-reproduction.json`](config/asan-reproduction.json). It creates new assets, dependency evidence, campaign configurations and runs. It does not need the original author's VM disks, signed launcher, local authorization files or completed campaign directories.

The engineering and validation scope is recorded in the unchanged execution plan [`reproduction-001` v0.1](experiments/reproduction-001/PLAN.md). On November 25, 2026 (Asia/Shanghai), the exported package passed fresh acquisition, clean-base preparation and three main-experiment VM batches in a new repository on this one Apple M1 host. The independently audited result was **2.273131x ± 0.006420x (n=3 independent batches)**, with 180 timed observations, 36 warmups and three normal shutdowns; see the [clean-main validation evidence](results/clean-main-20261125-a02/README.md). This validates the new workflow on that host. Another member's independent reproduction on another machine remains **pending**. The validation used a 7200 s cumulative allowance and 1800 s download limit; it did not rerun the extension or alter the original formal results.

## Supported host and fixed guest

Use an Apple Silicon Mac with macOS and Apple Virtualization.framework, Python 3.9 or later, the Xcode Command Line Tools (`xcrun`, `clang` and `codesign`), Git, `curl`, `tar` and `gzip`. The launcher is built locally and ad-hoc signed. No host `sudo`, privileged container, host kernel change or port forwarding is part of this route. Intel Macs, Windows, Linux hosts and x86 emulation are outside this entry point's supported target.

Keep the Mac on AC power with a fixed power mode throughout one campaign. The check records the actual host, SDK and power settings; another Mac need not identify as the original MacBook Air M1. Stop if host memory pressure is high or less than 20 GiB is available. Each VM has 2 vCPUs, 3 GiB memory and a 30 GiB sparse disk limit. Sparse files can grow: retain space for all new instances rather than treating their initial allocation as their final footprint.

The guest target is Ubuntu 24.04.5 LTS/aarch64, Linux `6.8.0-147-generic`, Clang/LLVM/compiler-rt `18.1.3`, CMake `3.28.3` and Ninja `1.11.1`. Provisioning uses explicit package pins and records the complete installed package inventory. If a pinned image or package is unavailable, preserve the failure and stop. Substituting a newer package changes the environment and needs a recorded plan/configuration revision. The Ubuntu image checksums come from the pinned official HTTPS source; detached GPG signature verification is not claimed.

Ubuntu inputs are downloaded locally from the [pinned official cloud-image source](https://cloud-images.ubuntu.com/noble/20261017/). Ubuntu is an aggregate distribution whose components retain their individual licenses; see [Canonical's intellectual property rights policy](https://canonical.com/legal/intellectual-property-policy). This source bundle redistributes neither VM images nor downloaded package binaries. LLVM Test Suite/Olden sources are acquired separately at the fixed Git commit. The bundled [LLVM license](third_party/llvm-test-suite/LICENSE.TXT) and [additional Olden conditions](third_party/llvm-test-suite/OLDEN-LICENSE.TXT) preserve the applicable notices; retain them with any permitted source use or redistribution.

## Prepare a new work repository

Extract the public source bundle into a new directory named `OS-project-local`, then open a terminal in its parent directory. The bundle contains source, fixed-input metadata, licenses and instructions; downloaded images and compiled launchers are rebuilt locally. Initialize an independent work repository and its local role marker:

```sh
cd OS-project-local
git init
mkdir -p .local
printf '%s\n' work > .local/workspace-role
git rev-parse --show-toplevel
git status --short --branch
git remote -v
bash scripts/check-workspace-zone.sh work
```

The public bundle's workspace checker accepts an initialized independent `.git` without an initial commit. The runner records the source identity as `uncommitted` and preserves file hashes/snapshots; this does not fabricate commit history. The work repository must have no remote. Leave any detected remote configured and resolve the workspace identity before writing. These bootstrap commands are for a new directory, not a way to replace an existing repository or its edits.

When maintaining the full OS-project source repository, follow its stricter historical workspace checker and preserve its existing Git history. Use two independent repositories: remote-free `OS-project-local` for work and canonical `OS-project` for releases. The release repository stays on `main`, tracking `origin/main`, with `https://github.com/SAKANA2336/OS-project.git` as both origin URLs, and is read-only during reproduction. A bundle-only reproduction does not need a release repository. Do not use linked worktrees or mirror one repository over the other.

When working in the full source repository, also read its `AGENTS.md`, `docs/PROJECT_STATE.md`, `docs/PROTOCOL.md`, `docs/DECISIONS.md` and `docs/governance/FILE_MANAGEMENT.md`. The standalone public bundle intentionally omits those project-maintenance records; the reproduction guide, new plan, archived scientific plans and executable checks provide its self-contained operating instructions.

## Check before downloading or starting a VM

From the work repository root:

```sh
python3 -B scripts/asan-reproduce.py --root . check
python3 -B scripts/asan-reproduce.py --help
python3 -B -m unittest discover -s tests
```

Before collecting, capture the host model, CPU description, physical memory and logical CPU count with the following command. These fields do not include a serial number or hardware UUID. Retain the output with the new session's environment evidence:

```sh
sysctl hw.model machdep.cpu.brand_string hw.memsize hw.ncpu
```

`check` validates the host, work zone, source template and prerequisites. Missing downloaded assets at this stage do not mean they have been fetched. Offline unit checks cover control flow and evidence validation; they do not start a guest or produce performance samples. Keep their diagnostics when a prerequisite fails.

## Acquire, prepare and freeze a new session

Choose a new session ID and new campaign IDs. Existing output directories are not overwritten. A session records elapsed machine activity across stages, including failed stages. A new ID does not replenish an operator-approved resource allowance. Define the total allowance before downloads; each stage is also bounded by its own limit. The completed validation was authorized for a fresh exported-package main sequence with total activity <=7200 s, fetch/download <=1800 s, prepare <=900 s and main campaign <=3600 s; the commands below show that bounded route. The freeze operation itself is capped at 120 s. All stages, failed attempts, shutdown and verification consume the cumulative allowance. That completed authorization covered the main sequence and excluded the extension; unused balance does not broaden or renew its scope. A reader running a separate task must allocate their own applicable resource budget before active stages.

```sh
python3 -B scripts/asan-reproduce.py --root . fetch \
  --session reproduction-001-a01 --activity-limit-seconds 1800 \
  --total-budget-seconds 7200
python3 -B scripts/asan-reproduce.py --root . prepare \
  --session reproduction-001-a01 --activity-limit-seconds 900
python3 -B scripts/asan-reproduce.py --root . freeze \
  --session reproduction-001-a01 --experiment exp-001 \
  --campaign reproduction-main-a01 --activity-limit-seconds 3600
```

`fetch` obtains the pinned Ubuntu disk/boot inputs and the exact LLVM Test Suite revision through the local Git CLI. It verifies the known asset checksums and all 222 source-lock entries. Source checkout preserves the historical lock's CRLF/LF bytes; comparison copies may normalize CRLF to LF as documented by the guest runner. Upstream input files remain unchanged.

For a transient Git transport failure after verified downloads, keep the failed run and continue the **same** session with `fetch --resume`, the unchanged `--total-budget-seconds`, and a new stage allowance no greater than `1800 - previous fetch elapsed seconds`. For example, after about 100 seconds of failed fetch activity, an allowance of 1600 seconds remains within the download ceiling. The ledger also continues to charge the approved total. Already complete assets are rechecked and reused; a partial or mismatched file stops for review. The Git transport uses HTTP/1.1 and honors an existing OS/environment HTTP(S) proxy for the child process. It does not change system/global Git proxy settings, source commits or checksums; proxy endpoint values and credentials are not recorded.

`prepare` compiles and signs a new launcher, provisions a disposable guest from the verified original image, checks the exact kernel and dependencies and tests the 32 B/64 B ASan options with tiny normal-exit programs. The measured guest is offline. It records the new base disk, kernel/initrd, launcher and full package inventory hashes. These newly built artifacts need not equal the original author's signed binary or prepared disk hash. Their provenance and observed versions must pass before their hashes are bound to this session.

`freeze` binds a new campaign to the plan, source lock, actual host and verified session assets. Its own operation is capped at 120 s; `--activity-limit-seconds 3600` sets the subsequent campaign's maximum activity, not a 3600 s allowance to freeze. Both operations draw from the cumulative session ledger. The historical `config/asan-exp-001-v0.2.json` and `asan-exp-002-v0.2.json` remain immutable records for the old campaigns. Do not edit their machine hashes or borrow their execution authorization to run a new campaign.

Acquisition and provisioning time depends on the network and available pinned packages. The command limits are stop conditions, not a runtime guarantee. Historical measurement batches took minutes on one M1 host; allow the stated per-stage ceiling and stop on failure instead of repeatedly restarting the budget.

## Collect and verify the main experiment

```sh
python3 -B scripts/asan-reproduce.py --root . run \
  --config .local/asan-reproduction/sessions/reproduction-001-a01/reproduction-main-a01.json
python3 -B scripts/asan-reproduce.py --root . verify \
  --campaign reproduction-main-a01
```

The main campaign requires three complete independent VM batches. Every batch uses a new instance of the same verified base and produces 12 warmups plus 60 timed records. Three batches yield 36 warmups, 180 timed records and 90 pairs; the cross-batch statistical sample size is **3**. Baseline and ASan use the same fixed build settings except for `-fsanitize=address`. Collection order, output checking and aggregation follow the archived [`exp-001` v0.2 plan](docs/governance/snapshots/exp-001-plan-v0.2.md.snapshot).

An exit code alone is insufficient. Verification must accept the raw output, reference comparisons, sample identities/order, environment and inner/outer hash manifests, then recompute the statistics. Incomplete or invalid batches remain recorded and cannot be silently replaced because their ratios are inconvenient.

## Collect and verify the extension

**The completed 7200 s main-only validation did not authorize this section.** Its execution stopped after main verification. A later extension needs a separately approved scope and resource budget; merely having a remaining session balance is insufficient.

The optional recipe below is for a future session explicitly allocated to both phases, after that session's own main campaign has three valid sealed batches and passes verification. Its example session ID is deliberately different from the current main-only session. Acquire/prepare/freeze and validate that future session using its separately allocated total before these extension commands:

```sh
python3 -B scripts/asan-reproduce.py --root . freeze \
  --session reproduction-both-a01 --experiment exp-002 \
  --campaign reproduction-redzone-a01 --activity-limit-seconds 3600
python3 -B scripts/asan-reproduce.py --root . run \
  --config .local/asan-reproduction/sessions/reproduction-both-a01/reproduction-redzone-a01.json
python3 -B scripts/asan-reproduce.py --root . verify \
  --campaign reproduction-redzone-a01
```

The extension collects new paired `rz32`/`rz64` samples in three new VM batches. Within each batch both arms use the identical ASan binary; only `redzone` and `max_redzone`, jointly representing one redzone-size factor, change from 32 to 64. Follow the archived [`exp-002` v0.2 plan](docs/governance/snapshots/exp-002-plan-v0.2.md.snapshot). It measures wall-clock time, not memory usage or detection coverage.

The archived plans preserve original bytes, historical references and original authorization context. Their relative links describe restoration at the original plan paths; they are not all navigation targets in the standalone bundle. The bundle also provides these two snapshots under `archive/2026-11-19-formal/`. The new session uses this guide and the portable template, rather than activating the archived machine-specific bindings.

## Evidence, expected outputs and interpretation

Session assets and large VM files stay under ignored `.local/asan-reproduction/sessions/<session>/`. Stage evidence uses unique `runs/run-<UTC>-reproduction-001-aNN/` directories; collected batches use unique `runs/run-<UTC>-exp-001-aNN/` or `exp-002` IDs. The stage kind identifies acquisition, provisioning or other preparation. Campaign analysis is under `results/<campaign>/`, including `summary.json` and `completion.json`, with references to the contributing run IDs. Each run contains its effective configuration, source/environment provenance, commands, original output, validation and hashes. Preserve failed and stopped attempts too.

The primary time measure is `timeit real` in seconds. Per batch, divide each workload's five-sample ASan mean by its baseline mean, then average the six ratios equally. Report the mean and sample standard deviation of the three batch aggregates. The extension uses `mean(rz64) / mean(rz32)` with the same aggregation. Report per-workload results, short-duration flags, the geometric aggregate and the predeclared sensitivity result without `mst` alongside the main result.

This is modern-toolchain **method replication on six Olden workloads**. The paper's Figure 2 average is 1.73x on its historical SPEC CPU2006 setup. Compare descriptively, with absolute/relative gaps and a full deviations table. Different hardware, ISA, virtualization, toolchain and workloads prevent attribution of a difference to one factor and prevent a claim of reproducing the original SPEC number. A passing fresh-machine verification also does not repair missing evidence in unrelated old upstream C-001/C-002 runs.

If a stage times out, a checksum/version differs, the output fails, the host crosses its resource threshold or isolation fails, stop that instance and retain diagnostics. Use the recorded run ID and session ledger to decide recovery within the remaining allowance. Do not change package pins, input sizes, statistics, success thresholds or old raw logs to make a run pass. A changed plan receives the next version and a new run.

Small public logs/configurations can be reviewed for version control. VM disks, compiled binaries, downloaded archives and credentials remain local. Review absolute paths and the release allowlist before any separately authorized commit, push or tag.
