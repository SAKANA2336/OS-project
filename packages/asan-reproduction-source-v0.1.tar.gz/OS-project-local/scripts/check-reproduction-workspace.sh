#!/bin/sh
# Work-only checker for an extracted public source package (no historical commit required).
set -eu
[ "${1:-}" = work ] || { echo 'This public reproduction package supports the work role only' >&2; exit 2; }
root=$(git rev-parse --show-toplevel)
[ "$(basename "$root")" = OS-project-local ] || { echo 'Expected OS-project-local directory' >&2; exit 1; }
[ -d "$root/.git" ] && [ ! -L "$root/.git" ] || { echo 'Independent .git directory required' >&2; exit 1; }
[ "$(cat "$root/.local/workspace-role")" = work ] || { echo 'Work role marker required' >&2; exit 1; }
[ -z "$(git -C "$root" remote)" ] || { echo 'Work repository has remotes; stop without changing them' >&2; exit 1; }
echo 'workspace-zone check passed (independent public work package)'
