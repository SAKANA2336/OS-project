#!/usr/bin/env python3
"""Stage the reviewed ASan reproduction files in a new, self-contained directory."""

import argparse
import ast
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import re
import posixpath
import stat
import subprocess
import sys


FORMAT_VERSION = 1
MAX_FILE_BYTES = 50_000_000
MAX_PACKAGE_BYTES = 100_000_000
# Additions require a source review. There is deliberately no recursive copy or
# command-line option to add arbitrary files to the package.
PROOF_PREFIX = "results/clean-main-20261125-a02/"
PROOF_FILES = (
    "results/clean-main-20261125-a02/README.md",
    "results/clean-main-20261125-a02/summary.json",
    "results/clean-main-20261125-a02/completion.json",
    "results/clean-main-20261125-a02/provenance.json",
    "results/clean-main-20261125-a02/validation.json",
    "results/clean-main-20261125-a02/activity.jsonl",
    "results/clean-main-20261125-a02/effective.json.snapshot",
    "results/clean-main-20261125-a02/evidence/run-20261124t181411z-exp-001-a01.csv",
    "results/clean-main-20261125-a02/evidence/run-20261124t181552z-exp-001-a02.csv",
    "results/clean-main-20261125-a02/evidence/run-20261124t181731z-exp-001-a03.csv",
)
# Only this reviewed historical configuration may carry a past activation.
# Its .snapshot suffix and byte-equality check keep it separate from templates.
INERT_CONFIG_SNAPSHOTS = {
    "results/clean-main-20261125-a02/effective.json.snapshot":
        "results/clean-main-20261125-a02/effective.json",
}
FILES = (
    ("docs/reproduction.md", "README.md"),
    ("docs/reproduction.md", "docs/reproduction.md"),
    ("scripts/asan-reproduce.py", "scripts/asan-reproduce.py"),
    ("scripts/export-asan-reproduction.py", "scripts/export-asan-reproduction.py"),
    ("scripts/run-arm64-formal.py", "scripts/run-arm64-formal.py"),
    ("scripts/run-arm64-pilot.py", "scripts/run-arm64-pilot.py"),
    ("scripts/llvm-asan-formal.py", "scripts/llvm-asan-formal.py"),
    ("scripts/llvm-asan.py", "scripts/llvm-asan.py"),
    ("scripts/analyze-asan-formal.py", "scripts/analyze-asan-formal.py"),
    ("scripts/prepare-arm64-formal-base.py", "scripts/prepare-arm64-formal-base.py"),
    ("scripts/fetch-arm64-ubuntu.py", "scripts/fetch-arm64-ubuntu.py"),
    ("scripts/run-arm64-vm.m", "scripts/run-arm64-vm.m"),
    ("scripts/check-reproduction-workspace.sh", "scripts/check-reproduction-workspace.sh"),
    ("scripts/check-reproduction-workspace.sh", "scripts/check-workspace-zone.sh"),
    ("config/arm64-vm.entitlements.plist", "config/arm64-vm.entitlements.plist"),
    ("config/asan-reproduction.json", "config/asan-reproduction.json"),
    ("workloads/llvm-suite-lock.json", "workloads/llvm-suite-lock.json"),
    ("third_party/llvm-test-suite/LICENSE.TXT", "third_party/llvm-test-suite/LICENSE.TXT"),
    ("third_party/llvm-test-suite/OLDEN-LICENSE.TXT", "third_party/llvm-test-suite/OLDEN-LICENSE.TXT"),
    ("experiments/reproduction-001/PLAN.md", "experiments/reproduction-001/PLAN.md"),
    ("experiments/reproduction-001/VERSION_ARCHIVE.md", "experiments/reproduction-001/VERSION_ARCHIVE.md"),
    ("experiments/reproduction-001/snapshots/README.md", "experiments/reproduction-001/snapshots/README.md"),
    ("experiments/reproduction-001/snapshots/reproduction-001-plan-v0.0.md.snapshot",
     "experiments/reproduction-001/snapshots/reproduction-001-plan-v0.0.md.snapshot"),
    ("experiments/reproduction-001/snapshots/reproduction-001-plan-v0.1.md.snapshot",
     "experiments/reproduction-001/snapshots/reproduction-001-plan-v0.1.md.snapshot"),
    ("tests/test_asan_reproduce.py", "tests/test_asan_reproduce.py"),
    ("tests/test_export_asan_reproduction.py", "tests/test_export_asan_reproduction.py"),
    ("docs/governance/snapshots/exp-001-plan-v0.2.md.snapshot", "docs/governance/snapshots/exp-001-plan-v0.2.md.snapshot"),
    ("docs/governance/snapshots/exp-002-plan-v0.2.md.snapshot", "docs/governance/snapshots/exp-002-plan-v0.2.md.snapshot"),
    ("docs/governance/snapshots/exp-001-plan-v0.2.md.snapshot",
     "archive/2026-11-19-formal/exp-001-plan-v0.2.md.snapshot"),
    ("docs/governance/snapshots/exp-002-plan-v0.2.md.snapshot",
     "archive/2026-11-19-formal/exp-002-plan-v0.2.md.snapshot"),
    ("experiments/exp-001/VERSION_ARCHIVE.md",
     "archive/2026-11-19-formal/exp-001-version-archive.md.snapshot"),
    ("experiments/exp-002/VERSION_ARCHIVE.md",
     "archive/2026-11-19-formal/exp-002-version-archive.md.snapshot"),
)
FILES += tuple((logical, logical) for logical in PROOF_FILES)
GENERATED_FILES = {
    ".gitignore": ".local/\nscratch/\nworkloads/downloads/\n__pycache__/\n*.pyc\n.DS_Store\n*.raw\n*.iso\n",
    ".gitattributes": "# Preserve manifest-bound source and historical snapshot bytes.\n* -text\n",
    "docs/governance/snapshots/README.md": (
        "# Frozen historical plan snapshots\n\n"
        "Read these files as byte-exact records of the completed formal experiments. "
        "Their relative links describe the original repository layout. They are "
        "not active execution instructions, permission, or the new reproduction plan.\n\n"
        "Use experiments/reproduction-001/PLAN.md and the reproduction guide for new runs. "
        "The package manifest records source and destination hashes.\n"
    ),
    "archive/2026-11-19-formal/README.md": (
        "# Historical formal experiment plans\n\n"
        "These byte-exact copies document the completed November 19, 2026 experiments. "
        "They are recovery material, not active instructions or permission for a new run. "
        "Relative links inside snapshots retain their original repository-path meaning.\n\n"
        "Use the current reproduction guide and reproduction-001 plan for new work. "
        "Preserve these snapshots and their manifest hashes. Original decisions, "
        "machine-specific execution configurations, disk images and personal inputs "
        "are not part of this package.\n"
    ),
}
FORBIDDEN_PARTS = {".git", ".local", ".aws", ".ssh", ".codex", ".agents",
                   "__pycache__", "downloads", "node_modules"}
FORBIDDEN_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip",
                      ".tar", ".gz", ".raw", ".img", ".iso", ".dmg", ".deb",
                      ".so", ".dylib", ".o", ".a", ".exe", ".pyc", ".pem", ".key"}
CONTENT_CHECKS = (
    ("personal absolute path", re.compile(r"/(?:Users|home)/[^/\s\"'<>]+(?:/|\b)")),
    ("personal Windows path", re.compile(r"[A-Za-z]:[\\/]+Users[\\/]+[^\\/\s\"']+", re.I)),
    ("private key", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----")),
    ("GitHub token", re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b")),
    ("AWS access key", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")),
    ("URL credentials", re.compile(r"https?://[^\s/:@\"']+:[^\s/@\"']+@", re.I)),
)
SCRIPT_REFERENCE = re.compile(r"(?<![A-Za-z0-9_-])scripts/[A-Za-z0-9_-]+\.py\b")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def logical_path(value):
    require(isinstance(value, str) and value and value.isascii()
            and not re.search(r"\s|\\", value), "Invalid logical path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.as_posix() == value
            and not any(part in {"", ".", ".."} for part in path.parts), "Unsafe logical path: " + value)
    require(not any(part.casefold() in FORBIDDEN_PARTS for part in path.parts)
            and path.suffix.casefold() not in FORBIDDEN_SUFFIXES,
            "Forbidden public package path: " + value)
    require(not any(part.casefold() in {"credentials", ".env", "id_rsa", "id_ed25519"}
                    for part in path.parts), "Credential path in allowlist: " + value)
    return path


def regular_source(root, logical):
    relative = logical_path(logical)
    current = root
    for part in relative.parts:
        current = current / part
        require(not current.is_symlink(), "Symlink in source path: " + logical)
    require(current.is_file() and stat.S_ISREG(current.stat().st_mode),
            "Required source file missing: " + logical)
    require(current.resolve().is_relative_to(root), "Source escapes repository: " + logical)
    require(current.stat().st_size <= MAX_FILE_BYTES, "Source exceeds 50 MB: " + logical)
    return current


def check_content(data, logical):
    require(b"\0" not in data, "Binary data in public source: " + logical)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("Public source is not UTF-8 text: " + logical) from None
    for label, pattern in CONTENT_CHECKS:
        require(pattern.search(text) is None, label + " in " + logical)
    inert_config = logical in INERT_CONFIG_SNAPSHOTS
    if logical.endswith(".json.snapshot"):
        require(inert_config, "Unreviewed historical configuration snapshot: " + logical)
    if logical.endswith(".json") or inert_config:
        try:
            payload = json.loads(text)
        except ValueError:
            raise ValueError("Malformed JSON source: " + logical) from None
        # Templates are never exported with an executable approval inherited
        # from the author's machine. Historical execution configs are excluded.
        if isinstance(payload, dict) and not inert_config:
            require(payload.get("execution_authorized") is not True,
                    "Active historical authorization in " + logical)
            require(payload.get("execution_authorization") in (None, False),
                    "Bound execution approval in " + logical)
    return text


def check_dependencies(files):
    """Reject unbundled literal Python script dependencies before writing."""
    packaged = {item["path"] for item in files}
    local_modules = {PurePosixPath(item["path"]).stem: item["path"] for item in files
                     if item["path"].startswith("scripts/") and item["path"].endswith(".py")}
    for item in files:
        logical = item["path"]
        if not logical.endswith(".py"):
            continue
        text = item["data"].decode("utf-8")
        tree = ast.parse(text, filename=logical)
        # Do not inspect the exporter's allowlist/test fixtures as runtime
        # dependencies. All executable entry points are checked below.
        if PurePosixPath(logical).name == "export-asan-reproduction.py" or logical.startswith("tests/"):
            continue
        references = set(SCRIPT_REFERENCE.findall(text))
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "with_name" and node.args
                    and isinstance(node.args[0], ast.Constant)
                    and isinstance(node.args[0].value, str) and node.args[0].value.endswith(".py")):
                references.add((PurePosixPath(logical).parent / node.args[0].value).as_posix())
            if isinstance(node, ast.Import):
                for name in node.names:
                    if name.name in local_modules:
                        references.add(local_modules[name.name])
            if isinstance(node, ast.ImportFrom) and node.module in local_modules:
                references.add(local_modules[node.module])
        missing = references - packaged
        require(not missing, "Missing local script dependencies for " + logical + ": " + ", ".join(sorted(missing)))


def relocated_readme(data, source):
    """Resolve inline relative Markdown links from the guide's original path."""
    parent = PurePosixPath(source).parent.as_posix()
    def replace(match):
        target = match.group(1)
        if target.startswith(("#", "/", "<")) or re.match(r"[A-Za-z][A-Za-z0-9+.-]*:", target):
            return match.group(0)
        path, separator, anchor = target.partition("#")
        rewritten = posixpath.normpath(posixpath.join(parent, path))
        require(not rewritten.startswith("../"), "README link escapes package: " + target)
        return "](" + rewritten + (separator + anchor if separator else "") + ")"
    return re.sub(r"\]\(([^)\s]+)\)", replace, data.decode("utf-8")).encode("utf-8")


def plan_export(root, entries=None):
    root = Path(root).resolve()
    entries = FILES if entries is None else tuple(entries)
    require(entries, "Empty package allowlist")
    seen = set()
    files = []
    for source, destination in entries:
        target = logical_path(destination).as_posix()
        require(target.casefold() not in seen and target.casefold() != "package-manifest.json",
                "Duplicate or reserved destination: " + target)
        seen.add(target.casefold())
        original = regular_source(root, source)
        raw = original.read_bytes()
        if source in INERT_CONFIG_SNAPSHOTS:
            recorded = regular_source(root, INERT_CONFIG_SNAPSHOTS[source]).read_bytes()
            require(raw == recorded, "Historical config snapshot differs from its recorded original")
        data = relocated_readme(raw, source) if target == "README.md" and source.endswith(".md") else raw
        require(len(data) <= MAX_FILE_BYTES, "Source grew beyond 50 MB: " + source)
        check_content(raw, source)
        check_content(data, target)
        if target in INERT_CONFIG_SNAPSHOTS:
            role = "historical_evidence"
        elif target.startswith(PROOF_PREFIX):
            role = "measurement_evidence"
        elif target.startswith("archive/"):
            role = "historical_plan"
        else:
            role = "reproduction_source"
        files.append({"source": source, "source_sha256": sha256(raw).hexdigest(), "source_bytes": len(raw),
                      "transformation": "resolve_relative_readme_links" if data != raw else "none",
                      "path": target, "bytes": len(data),
                      "sha256": sha256(data).hexdigest(), "data": data,
                      "mode": 0o755 if original.stat().st_mode & 0o111 or target.endswith(".sh") else 0o644,
                      "role": role})
    for logical, text in GENERATED_FILES.items():
        require(logical.casefold() not in seen, "Generated package path collision: " + logical)
        seen.add(logical.casefold())
        data = text.encode("utf-8")
        check_content(data, logical)
        files.append({"source": None, "source_sha256": None, "source_bytes": None, "transformation": "generated",
                      "path": logical, "bytes": len(data),
                      "sha256": sha256(data).hexdigest(), "data": data, "mode": 0o644,
                      "role": "package_metadata"})
    require(sum(item["bytes"] for item in files) <= MAX_PACKAGE_BYTES, "Package exceeds 100 MB bound")
    check_dependencies(files)
    return files


def stage_package(root, destination, source_commit, entries=None):
    files = plan_export(root, entries)
    require(re.fullmatch(r"[a-f0-9]{40,64}", source_commit or "") is not None,
            "A verified source Git commit is required")
    destination = Path(destination).absolute()
    require(not destination.exists() and not destination.is_symlink(), "Destination already exists")
    require(destination.parent.is_dir(), "Destination parent must already exist")
    # Resolve conventional OS aliases such as the macOS temporary directory.
    # The final component is still checked above and created exclusively.
    destination = destination.parent.resolve() / destination.name
    destination.mkdir(exist_ok=False)
    # Failures after mkdir intentionally leave their partial package in place
    # for inspection. Nothing is overwritten or automatically cleaned up.
    for item in files:
        target = destination / item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(item["data"])
        target.chmod(item["mode"])
        require(sha256(target.read_bytes()).hexdigest() == item["sha256"],
                "Staged byte verification failed: " + item["path"])
    manifest = {
        "format_version": FORMAT_VERSION,
        "source_git_commit": source_commit,
        "scope": "Reviewed reproduction sources; per-file hashes bind current source bytes, including uncommitted work.",
        "original_experiments": "Historical plans and configuration snapshots are read-only evidence. New executions require a new configuration and evidence.",
        "validation_evidence_scope": "The public CSVs support statistical recalculation. Full raw output, build/environment evidence and run seals remain in the controlled archive cited by provenance.",
        "files": [{key: item[key] for key in ("source", "source_sha256", "source_bytes", "transformation", "path", "bytes", "sha256", "role")}
                  for item in files],
    }
    with (destination / "package-manifest.json").open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2, ensure_ascii=True, sort_keys=True)
        stream.write("\n")
    return manifest


def source_commit(root):
    require(root.name == "OS-project-local", "Export from the canonical work repository")
    require((root / ".git").is_dir() and not (root / ".git").is_symlink(),
            "Export from an independent work repository")
    require((root / ".local/workspace-role").read_text().strip() == "work", "Work role is required")
    git = ["git", "-C", str(root)]
    require(Path(subprocess.check_output(git + ["rev-parse", "--show-toplevel"], text=True).strip()).resolve() == root,
            "Source repository root differs")
    require(not subprocess.check_output(git + ["remote"], text=True).strip(), "Work repository must have no remotes")
    return subprocess.check_output(git + ["rev-parse", "HEAD"], text=True).strip()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--destination", type=Path, required=True, help="New directory with an existing parent")
    parser.add_argument("--check", action="store_true", help="Validate the allowlist without creating files")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    commit = source_commit(root)
    if args.check:
        files = plan_export(root)
        require(not args.destination.exists() and not args.destination.is_symlink(), "Destination already exists")
        result = {"status": "checked", "files": len(files), "bytes": sum(item["bytes"] for item in files),
                  "source_git_commit": commit, "destination_created": False}
    else:
        manifest = stage_package(root, args.destination, commit)
        result = {"status": "staged", "files": len(manifest["files"]),
                  "bytes": sum(item["bytes"] for item in manifest["files"]), "destination_created": True}
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, SyntaxError, subprocess.SubprocessError) as error:
        raise SystemExit("Export failed: " + str(error)) from None
