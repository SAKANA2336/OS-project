"""Fetch one pinned, checksum-verified Ubuntu image within a fixed byte/time cap."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--destination', type=Path, required=True)
    p.add_argument('--evidence', type=Path, required=True)
    p.add_argument('--asset-set', choices=('disk', 'boot'), default='disk')
    args = p.parse_args()
    args.destination.mkdir(parents=True, exist_ok=False)
    args.evidence.mkdir(parents=True, exist_ok=False)
    origin = 'https://cloud-images.ubuntu.com/noble/20261017/'
    image = 'noble-server-cloudimg-arm64.tar.gz'
    files = [('SHA256SUMS', 100000), (image, 800000000)]
    if args.asset_set == 'boot':
        origin += 'unpacked/'
        files = [('SHA256SUMS', 100000),
                 ('noble-server-cloudimg-arm64-vmlinuz-generic', 40000000),
                 ('noble-server-cloudimg-arm64-initrd-generic', 60000000)]
    records = []
    for name, max_bytes in files:
        dest = args.destination / name
        partial = dest.with_name(name + '.partial')
        argv = ['curl', '--fail', '--location', '--silent', '--show-error',
                '--connect-timeout', '20', '--max-time', '900',
                '--speed-limit', '1024', '--speed-time', '60',
                '--max-filesize', str(max_bytes), '--output', str(partial),
                '--dump-header', str(args.evidence / (name + '.headers.txt')),
                '--write-out', '%{http_code} %{size_download} %{time_total}\n',
                origin + name]
        started = datetime.now(timezone.utc).isoformat()
        result = subprocess.run(argv, capture_output=True, text=True, timeout=920)
        record = {'source_url': origin + name, 'name': name,
                  'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
                  'returncode': result.returncode, 'transport_metrics': result.stdout,
                  'stderr': result.stderr,
                  'local_asset_role': 'ignored VM input; not repository content',
                  'logical_path': '.local/arm64-vm/assets/ubuntu-noble-20261017/' + ('boot/' if args.asset_set == 'boot' else '') + name}
        if partial.exists():
            record.update(bytes=partial.stat().st_size, sha256=sha256(partial))
        records.append(record)
        (args.evidence / 'acquisition.json').write_text(json.dumps(records, indent=2) + '\n')
        print(name, result.returncode, result.stdout.strip(), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        if name != 'SHA256SUMS':
            entries = (args.destination / 'SHA256SUMS').read_text().splitlines()
            found = [line.split()[0] for line in entries if line.split()[-1].lstrip('*') == name]
            if len(found) != 1 or record['sha256'] != found[0]:
                raise RuntimeError('Official SHA-256 mismatch or ambiguous manifest')
            record['official_sha256_match'] = True
            record['signature_verification'] = 'SHA256SUMS obtained from official HTTPS origin; detached GPG signature not checked'
        partial.rename(dest)
        (args.evidence / 'acquisition.json').write_text(json.dumps(records, indent=2) + '\n')
    print('Pinned Ubuntu archive verified.', flush=True)


if __name__ == '__main__':
    main()
