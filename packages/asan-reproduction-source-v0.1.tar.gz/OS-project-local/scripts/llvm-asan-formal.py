#!/usr/bin/env python3
"""Run one bounded formal Olden batch in the disposable Linux ARM64 VM."""

import argparse
import csv
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import platform
import re
import resource
import runpy
import shlex
import signal
import statistics
import tempfile
import time
import traceback


WORKLOADS = (
    ("bisort", ["700000"]),
    ("em3d", ["1024", "1000", "125"]),
    ("mst", ["1000"]),
    ("perimeter", ["10"]),
    ("treeadd", ["22"]),
    ("tsp", ["1024000"]),
)
ROTATIONS = ((0, 2, 4, 1, 3), (1, 3, 5, 0, 2), (4, 0, 5, 1, 3))
SOURCE_COMMIT = "72a946a42cbce06afef68b2326ff6c3869d09799"
LOCK_SHA256 = "169b5f76f4cd73bd0d9ad0c25d3f636e9dc316d0bd9369d3cf4631e2ba0a56f0"
ASAN_BASE = (
    "detect_leaks=0:redzone=32:max_redzone=32:quarantine_size_mb=0:"
    "thread_local_quarantine_size_kb=0:malloc_context_size=0:"
    "detect_stack_use_after_return=0:halt_on_error=1:exitcode=86"
)
ARM_NAMES = {"exp-001": ("baseline", "asan"), "exp-002": ("rz32", "rz64")}
COMMON_CXX = "-O2 -g -fno-omit-frame-pointer"
COMMON_C = COMMON_CXX + " -std=gnu89"


class InvalidSample(RuntimeError):
    """A timed pair cannot contribute to a complete valid batch."""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def options_map(options):
    entries = [item.split("=", 1) for item in options.split(":")]
    values = dict(entries)
    require(len(entries) == len(values), "Duplicate ASan runtime option")
    return values


def arm_configs(experiment_id, options):
    require(options == ASAN_BASE, "Input ASan options differ from the frozen baseline")
    if experiment_id == "exp-001":
        return {
            "baseline": {"build": "baseline", "asan_options": options},
            "asan": {"build": "asan", "asan_options": options},
        }
    larger = dict(options_map(options), redzone="64", max_redzone="64")
    options64 = ":".join(f"{key}={value}" for key, value in larger.items())
    return {
        "rz32": {"build": "asan", "asan_options": options},
        "rz64": {"build": "asan", "asan_options": options64},
    }


def schedule(experiment_id, batch_slot, benchmarks):
    """Freeze adjacent fresh-process order for the selected experiment and slot."""
    arms = ARM_NAMES[experiment_id]
    for index, rotation in enumerate((batch_slot, *ROTATIONS[batch_slot])):
        phase = "warmup" if index == 0 else "measure"
        iteration = max(1, index)
        round_zero = max(0, index - 1)
        for position in range(len(benchmarks)):
            ordinal = (rotation + position) % len(benchmarks)
            ordered = arms if (batch_slot + round_zero + ordinal) % 2 == 0 else arms[::-1]
            for arm in ordered:
                yield benchmarks[ordinal], phase, iteration, arm


def runtime_values(output, requested):
    found = {}
    lines = output.splitlines()
    for index, line in enumerate(lines):
        name = line.strip()
        if name not in requested or index + 1 == len(lines):
            continue
        match = re.search(r"\(Current Value: ([^)]+)\)", lines[index + 1])
        if match:
            require(name not in found, "Duplicate effective flag in runtime probe: " + name)
            found[name] = match.group(1).strip()
    booleans = {
        "detect_leaks", "detect_stack_use_after_return", "halt_on_error",
    }
    normalized = {
        name: {"false": "0", "true": "1"}.get(value, value) if name in booleans else value
        for name, value in found.items()
    }
    # The pinned runtime canonicalizes a requested zero to one during initialization.
    observed_expected = dict(requested)
    if requested.get("malloc_context_size") == "0":
        observed_expected["malloc_context_size"] = "1"
    require(normalized == observed_expected, "Effective ASan flags disagree: " + repr(normalized))
    return found


def verify_configuration(cfg, slot):
    require(cfg.get("kind") == "formal-olden-arm64"
            and cfg.get("experiment_id") in ARM_NAMES, "Unknown formal experiment")
    require(cfg.get("execution_authorized") is True and cfg.get("frozen") is True,
            "Formal execution not authorized and frozen")
    require(slot in (0, 1, 2), "Invalid batch slot")
    require(cfg.get("execution_profile") == "systemd-vm", "Unexpected execution profile")
    require(cfg["source"]["commit"] == SOURCE_COMMIT, "Different test-suite revision")
    expected = [(name, args, "MultiSource/Benchmarks/Olden/" + name) for name, args in WORKLOADS]
    observed = [(b["name"], b["args"], b["directory"]) for b in cfg["benchmarks"]]
    require(observed == expected, "Workload, input, or ordering differs")
    require(cfg["cc"] == "clang-18" and cfg["cxx"] == "clang++-18"
            and cfg["c_flags"] == COMMON_C and cfg["cxx_flags"] == COMMON_CXX
            and cfg["asan_flags"] == "-fsanitize=address", "Build flags differ")
    require(cfg["warmups"] == 1 and cfg["repetitions"] == 5
            and cfg["minimum_interpretable_seconds"] == 0.05
            and cfg["reference_line_endings"] == "normalize-crlf-to-lf-for-comparison-only",
            "Sampling settings differ")
    require(cfg["command_timeout_seconds"] == 60 and cfg["overall_timeout_seconds"] == 240,
            "Guest service limits differ")
    require(cfg["limits"] == {"cpus": 2, "memory": "2g", "pids": 128, "tmpfs": "768m", "build_jobs": 2},
            "Guest resource settings differ")
    require(cfg["asan_options"] == ASAN_BASE, "Base ASan options differ")


def tmpfs_evidence(text):
    mounts = [line.split() for line in text.splitlines()
              if len(line.split()) > 4 and line.split()[4] == "/tmp"]
    require(len(mounts) == 1, "Expected one /tmp mount")
    mount = mounts[0]
    _, _, options = mount[mount.index("-") + 1:]
    require(mount[mount.index("-") + 1] == "tmpfs", "Unexpected /tmp filesystem")
    mount_options = set(mount[5].split(","))
    require({"rw", "nosuid", "nodev"} <= mount_options and "noexec" not in mount_options,
            "Unexpected /tmp mount flags")
    require(any(value in options.split(",") for value in ("size=786432k", "size=805306368")),
            "Unexpected /tmp size limit")
    return {"size_bytes": 768 * 1024 ** 2, "options": sorted(mount_options)}


def record_environment(base, cfg, output, env, deadline):
    expected = cfg["expected_guest"]
    provenance = output / "provenance"
    commands = {
        "compiler": [cfg["cc"], "--version"],
        "cmake": ["cmake", "--version"],
        "ninja": ["ninja", "--version"],
        "kernel": ["uname", "-a"],
        "cpu": ["lscpu"],
        "packages": ["bash", "-o", "pipefail", "-c",
                     r"dpkg-query -W '-f=${binary:Package}\t${Version}\n' | sort"],
    }
    for name, argv in commands.items():
        base["checked"](argv, provenance / name, 20, env=env, deadline=deadline)
    for label, source in {
        "os-release": "/etc/os-release", "cpuinfo": "/proc/cpuinfo",
        "self-cgroup": "/proc/self/cgroup", "self-status": "/proc/self/status",
        "mountinfo": "/proc/self/mountinfo",
    }.items():
        base["copy_new"](source, provenance / (label + ".txt"))
    tmpfs = tmpfs_evidence((provenance / "mountinfo.txt").read_text())
    core = list(resource.getrlimit(resource.RLIMIT_CORE))
    require(core == [0, 0], "Expected both core dump limits to be zero")
    base["save"](output / "validation" / "mount-and-core.json", {"tmpfs": tmpfs, "rlimit_core": core})
    lines = {
        name: (provenance / (name + ".stdout.log")).read_text().splitlines()[0]
        for name in ("compiler", "cmake", "ninja")
    }
    compiler = re.search(r"\bclang version ([0-9.]+)\b", lines["compiler"])
    distro = next(line.partition("=")[2].strip('"')
                  for line in (provenance / "os-release.txt").read_text().splitlines()
                  if line.startswith("VERSION="))
    os_version = expected.get("os_version", "24.04.5 LTS")
    require(distro == os_version or distro.startswith(os_version + " ("),
            "Guest distribution version differs")
    observed = {
        "kernel_release": platform.release(),
        "compiler_version": compiler.group(1) if compiler else None,
        "cmake_version": lines["cmake"].removeprefix("cmake version "),
        "ninja_version": lines["ninja"],
        "packages_sha256": base["sha256"](provenance / "packages.stdout.log"),
    }
    require(observed == {key: expected[key] for key in observed},
            "Guest toolchain/kernel/package set drift: " + repr(observed))
    return dict(observed, os_version=os_version)


def build_arm(base, source, build_root, output, cfg, name, env, deadline):
    directory = build_root / name
    sanitizer = " " + cfg["asan_flags"] if name == "asan" else ""
    configure = [
        "cmake", "-G", "Ninja", "-S", str(source), "-B", str(directory),
        "-DCMAKE_C_COMPILER=" + cfg["cc"], "-DCMAKE_CXX_COMPILER=" + cfg["cxx"],
        "-DTEST_SUITE_HOST_CC=" + cfg["cc"], "-DCMAKE_BUILD_TYPE=Release",
        "-DCMAKE_C_FLAGS_RELEASE=", "-DCMAKE_CXX_FLAGS_RELEASE=",
        "-DCMAKE_C_FLAGS=" + cfg["c_flags"] + sanitizer,
        "-DCMAKE_CXX_FLAGS=" + cfg["cxx_flags"] + sanitizer,
        "-DCMAKE_EXE_LINKER_FLAGS=" + sanitizer.strip(),
        "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
        "-DTEST_SUITE_COLLECT_CODE_SIZE=OFF", "-DTEST_SUITE_COLLECT_COMPILE_TIME=OFF",
        "-DTEST_SUITE_COPY_DATA=ON",
        "-DTEST_SUITE_SUBDIRS=" + ";".join(item["directory"] for item in cfg["benchmarks"]),
    ]
    base["checked"](configure, output / "logs" / ("configure-" + name),
                    cfg["configure_timeout_seconds"], env=env, deadline=deadline)
    argv = ["cmake", "--build", str(directory), "--parallel", str(cfg["limits"]["build_jobs"])]
    tools_only = cfg["experiment_id"] == "exp-002" and name == "baseline"
    if tools_only:
        argv.extend(["--target", "build-timeit", "build-fpcmp"])
    base["checked"](argv, output / "logs" / ("build-" + name),
                    cfg["build_timeout_seconds"], env=env, deadline=deadline)
    dest = output / "provenance" / name
    for source_name, dest_name in (
        ("CMakeCache.txt", "cmake-cache.txt"), ("build.ninja", "build.ninja"),
        ("CMakeFiles/rules.ninja", "rules.ninja"),
        ("compile_commands.json", "compile-commands.json"),
    ):
        base["copy_new"](directory / source_name, dest / dest_name)
    binaries = {}
    if not tools_only:
        for item in cfg["benchmarks"]:
            executable = directory / item["directory"] / item["name"]
            binaries[item["name"]] = base["sha256"](executable)
            base["copy_new"](executable.with_suffix(".test"), dest / (item["name"] + ".test"))
            prefix = output / "validation" / ("symbols-" + name + "-" + item["name"])
            base["checked"](["llvm-nm-18", "--just-symbol-name", str(executable)],
                            prefix, 10, env=env, deadline=deadline)
            symbols = prefix.with_suffix(".stdout.log").read_text().splitlines()
            require(("__asan_init" in symbols) == (name == "asan"),
                    "Unexpected link to ASan on " + name + "/" + item["name"])
    base["save"](dest / "binaries.json", binaries)
    return binaries


def compile_signature(path, directory, expect_asan):
    rows = json.loads(path.read_text())
    signature = []
    for row in rows:
        tokens = row.get("arguments") or shlex.split(row["command"])
        sanitizer_count = tokens.count("-fsanitize=address")
        require(sanitizer_count == int(expect_asan), "Effective compilation flags lack exact ASan delta")
        signature.append((
            row["file"].replace(str(directory), "<build>"),
            tuple(token.replace(str(directory), "<build>")
                  for token in tokens if token != "-fsanitize=address"),
        ))
    require(signature, "Empty compilation database")
    return sorted(signature)


def runtime_probe(base, build_root, output, cfg, arms, env, deadline):
    file = output / "provenance" / "runtime-probe.c"
    with file.open("x") as handle:
        handle.write("int main(void) { return 0; }\n")
    probe = build_root / "runtime-probe"
    argv = [cfg["cc"], *shlex.split(cfg["c_flags"]), cfg["asan_flags"], str(file), "-o", str(probe)]
    base["checked"](argv, output / "validation" / "runtime-probe-build", 20, env=env, deadline=deadline)
    known = {}
    receipt = {}
    for arm, recipe in arms.items():
        options = recipe["asan_options"]
        if options not in known:
            prefix = output / "validation" / ("runtime-" + arm)
            base["checked"]([str(probe)], prefix, 10,
                            env=dict(env, ASAN_OPTIONS=options + ":help=1"), deadline=deadline)
            parsed = runtime_values(prefix.with_suffix(".stderr.log").read_text(), options_map(options))
            known[options] = {
                "requested": options_map(options), "observed": parsed,
                "command": prefix.with_suffix(".command.json").relative_to(output).as_posix(),
                "probe_sha256": base["sha256"](probe),
            }
        receipt[arm] = known[options]
    base["save"](output / "validation" / "runtime-options.json", receipt)
    return receipt


def measure(base, output, source, build_root, cfg, arm, recipe, hashes, item, row, env, deadline):
    label = row["sample_id"]
    raw = output / "raw-outputs"
    stdout = raw / (label + ".output.txt")
    timing = raw / (label + ".time.txt")
    executable = build_root / recipe["build"] / item["directory"] / item["name"]
    row["binary_sha256"] = hashes[recipe["build"]][item["name"]]
    require(base["sha256"](executable) == row["binary_sha256"], "Measured binary changed before invocation")
    row["asan_options"] = recipe["asan_options"]
    timer = build_root / "baseline/tools/timeit"
    compare = build_root / "baseline/tools/fpcmp"
    argv = [str(timer), "--timeout", str(cfg["command_timeout_seconds"]), "--limit-core", "0",
            "--append-exitstatus", "--redirect-output", str(stdout), "--summary", str(timing),
            "--chdir", str(executable.parent), str(executable), *item["args"]]
    sample_env = dict(env, ASAN_OPTIONS=recipe["asan_options"])
    log = output / "logs" / label
    row["started_at"] = utc_now()
    result = base["command"](argv, log, cfg["command_timeout_seconds"], env=sample_env, deadline=deadline)
    row["finished_at"] = utc_now()
    row.update(exit_code=result["exit_code"], timed_out=result["timed_out"])
    if timing.is_file():
        parsed = base["parse_time"](timing)
        row["program_exit_code"] = parsed["exit"]
        for name in ("real", "user", "sys"):
            value = parsed[name]
            require(math.isfinite(value) and value >= 0, "Nonfinite or negative raw timing")
            row[name + "_seconds"] = value
    if stdout.is_file():
        row["output_sha256"] = base["sha256"](stdout)
        normalized = output / "validation" / "normalized-output" / (label + ".txt")
        expected = output / "validation" / "normalized-reference" / (item["name"] + ".txt")
        source_ref = source / item["directory"] / (item["name"] + ".reference_output")
        base["normalize_crlf"](stdout, normalized)
        if not expected.exists():
            base["normalize_crlf"](source_ref, expected)
        validation = base["command"]([str(compare), str(normalized), str(expected)],
                                     output / "validation" / label, 10, env=sample_env, deadline=deadline)
        row.update(reference_match=validation["exit_code"] == 0 and not validation["timed_out"],
                   normalized_output_sha256=base["sha256"](normalized),
                   normalized_reference_sha256=base["sha256"](expected))
    outputs = (stdout, log.with_suffix(".stdout.log"), log.with_suffix(".stderr.log"))
    row["sanitizer_report"] = any(path.is_file() and b"AddressSanitizer" in path.read_bytes()
                                   for path in outputs)
    row["valid"] = (row["exit_code"] == row.get("program_exit_code") == 0
                    and row.get("real_seconds", 0) > 0 and row["reference_match"]
                    and not row["timed_out"] and not row["sanitizer_report"])
    if not row["valid"]:
        raise InvalidSample("Invalid sample; batch stopped at " + label)


def summarize(records, experiment_id, batch_slot, cfg):
    arms = ARM_NAMES[experiment_id]
    programs = []
    for item in cfg["benchmarks"]:
        name = item["name"]
        groups = {}
        for arm in arms:
            measured = [row["real_seconds"] for row in records if row["benchmark"] == name
                        and row["arm"] == arm and row["phase"] == "measure" and row["valid"]]
            warmups = [row for row in records if row["benchmark"] == name and row["arm"] == arm
                       and row["phase"] == "warmup" and row["valid"]]
            groups[arm] = {
                "valid_runs": len(measured), "warmups_valid": len(warmups) == 1,
                "complete": len(measured) == 5 and len(warmups) == 1,
                "mean_seconds": statistics.mean(measured) if measured else None,
                "sample_stddev_seconds": statistics.stdev(measured) if len(measured) > 1 else None,
            }
        complete = all(group["complete"] for group in groups.values())
        lower, upper = (groups[arm]["mean_seconds"] for arm in arms)
        programs.append({
            "benchmark": name, **groups, "complete": complete,
            "runtime_ratio": upper / lower if complete else None,
            "short_run_warning": complete and min(lower, upper) < cfg["minimum_interpretable_seconds"],
        })
    complete = len(records) == 72 and all(program["complete"] for program in programs)
    ratios = [program["runtime_ratio"] for program in programs] if complete else []
    return {
        "kind": "formal-olden-arm64", "experiment_id": experiment_id, "batch_slot": batch_slot,
        "all_benchmarks_valid": complete, "benchmarks": programs,
        "arithmetic_mean_runtime_ratio": statistics.mean(ratios) if ratios else None,
        "geometric_mean_runtime_ratio": statistics.geometric_mean(ratios) if ratios else None,
        "arithmetic_mean_runtime_ratio_without_mst": statistics.mean(
            program["runtime_ratio"] for program in programs if program["benchmark"] != "mst"
        ) if ratios else None,
    }


def write_results(base, output, records, summary):
    base["save"](output / "metrics" / "records.json", records)
    base["save"](output / "metrics" / "summary.json", summary)
    columns = [
        "experiment_id", "batch_slot", "sequence", "sample_id", "benchmark", "arm",
        "phase", "iteration", "started_at", "finished_at", "valid", "real_seconds",
        "user_seconds", "sys_seconds", "exit_code", "program_exit_code", "timed_out",
        "reference_match", "sanitizer_report", "output_sha256", "binary_sha256", "asan_options",
    ]
    with (output / "metrics" / "samples.csv").open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)


def run(args):
    started = time.monotonic()
    base = runpy.run_path(str(Path(__file__).with_name("llvm-asan.py")))
    cfg = base["load"](args.config)
    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    for part in ("logs", "raw-outputs", "metrics", "config", "provenance", "validation"):
        (output / part).mkdir()
    experiment_id = cfg.get("experiment_id")
    manifest = {
        "run_id": args.run_id, "vm_id": args.vm_id, "project_commit": args.project_commit,
        "experiment_id": experiment_id, "batch_slot": args.batch_slot,
        "status": "started", "kind": "formal-olden-arm64", "profile": args.profile,
        "started_at": utc_now(), "platform": "-".join((platform.system(), platform.release(), platform.machine())),
        "runner_sha256": base["sha256"](__file__), "shared_runner_sha256": base["sha256"](
            Path(__file__).with_name("llvm-asan.py")
        ),
    }
    records = []
    summary = None
    try:
        base["save"](output / "run-intent.json", manifest)
        base["save"](output / "config" / "effective.json", cfg)
        manifest["config_sha256"] = base["sha256"](output / "config" / "effective.json")
        verify_configuration(cfg, args.batch_slot)
        require(manifest["runner_sha256"] == cfg["formal_guest_sha256"]
                and manifest["shared_runner_sha256"] == cfg["pilot_runner_sha256"],
                "Guest runner script SHA differs from frozen configuration")
        require(args.run_id == args.vm_id and str(output) == "/evidence/" + args.run_id,
                "Run, VM, or output path identity differs")
        require(platform.system() == "Linux" and platform.machine() in ("aarch64", "arm64"),
                "Formal runs require Linux on ARM64")
        # Reserve the final 10 seconds of the 240-second unit for evidence sealing.
        deadline = base["Deadline"](230 - (time.monotonic() - started))
        base["check_isolation"](cfg, source, output, args.profile, args.parent_network_namespace_file)
        isolation = base["load"](output / "validation" / "isolation.json")["observation"]["effective_limits"]
        require(isolation == {"cpus": 2, "memory.max": 2 * 1024 ** 3,
                              "memory.swap.max": 0, "pids.max": 128}, "Effective resource limits differ")
        root = Path(__file__).resolve().parents[1]
        lock_path = root / "workloads/llvm-suite-lock.json"
        require(base["sha256"](lock_path) == LOCK_SHA256, "Frozen source lock differs")
        manifest["source"] = base["check_source"](source, cfg, deadline)
        require(manifest["source"]["files_verified"] == 222, "Unexpected locked source count")
        source_files = (
            (lock_path, "llvm-suite-lock.json"),
            (source / "LICENSE.TXT", "LLVM-LICENSE.TXT"),
            (source / "MultiSource/Benchmarks/Olden/LICENSE.TXT", "OLDEN-LICENSE.TXT"),
        )
        for path, name in source_files:
            base["copy_new"](path, output / "provenance" / name)
        environment = dict(os.environ, LC_ALL="C", TZ="UTC", ASAN_OPTIONS=cfg["asan_options"])
        environment.pop("LD_PRELOAD", None)
        observed = record_environment(base, cfg, output, environment, deadline)
        manifest["guest"] = observed
        manifest["compiler_version"] = observed["compiler_version"]
        arms = arm_configs(experiment_id, cfg["asan_options"])
        base["save"](output / "config" / "arms.json", arms)
        build_root = Path(tempfile.mkdtemp(prefix="llvm-asan-build-", dir="/tmp"))
        manifest["build_directory"] = str(build_root)
        runtime_probe(base, build_root, output, cfg, arms, environment, deadline)
        hashes = {
            arm: build_arm(base, source, build_root, output, cfg, arm, environment, deadline)
            for arm in ("baseline", "asan")
        }
        if experiment_id == "exp-001":
            signatures = {
                arm: compile_signature(output / "provenance" / arm / "compile-commands.json",
                                       build_root / arm, arm == "asan")
                for arm in ("baseline", "asan")
            }
            require(signatures["baseline"] == signatures["asan"], "The two compile command databases differ beyond ASan")
        available = sorted(os.sched_getaffinity(0))
        os.sched_setaffinity(0, {available[0]})
        manifest["cpu_affinity"] = sorted(os.sched_getaffinity(0))
        require(manifest["cpu_affinity"] == [cfg.get("logical_cpu", 0)], "Pinned vCPU differs")
        tools = {name: base["sha256"](build_root / "baseline/tools" / name)
                 for name in ("timeit", "fpcmp")}
        base["save"](output / "provenance" / "measurement-tools.json", tools)
        for sequence, (item, phase, iteration, arm) in enumerate(
            schedule(experiment_id, args.batch_slot, cfg["benchmarks"]), start=1
        ):
            deadline.check()
            row = {
                "experiment_id": experiment_id, "batch_slot": args.batch_slot,
                "sequence": sequence, "benchmark": item["name"], "arm": arm,
                "phase": phase, "iteration": iteration,
                "sample_id": f"{experiment_id}-{item['name']}-{phase}-{iteration:02}-{arm}",
                "valid": False, "exit_code": None, "timed_out": False,
                "reference_match": False, "sanitizer_report": False,
            }
            try:
                measure(base, output, source, build_root, cfg, arm, arms[arm], hashes,
                        item, row, environment, deadline)
            finally:
                records.append(row)
                base["save"](output / "metrics" / "records" / f"{sequence:03}.json", row)
        summary = summarize(records, experiment_id, args.batch_slot, cfg)
        require(summary["all_benchmarks_valid"], "Batch did not complete exactly 72 valid records")
        manifest["status"] = "passed_batch"
    except BaseException as error:
        manifest.update(status="invalid_batch" if isinstance(error, InvalidSample) else "failed",
                        error=type(error).__name__ + ": " + str(error))
        with (output / "logs" / "failure.log").open("x") as handle:
            traceback.print_exc(file=handle)
    finally:
        manifest["samples"] = len(records)
        manifest["finished_at"] = utc_now()
        manifest["elapsed_seconds"] = time.monotonic() - started
        try:
            if summary is None and experiment_id in ARM_NAMES:
                summary = summarize(records, experiment_id, args.batch_slot, cfg)
            write_results(base, output, records, summary)
            manifest["evidence_sha256"] = {
                f.relative_to(output).as_posix(): base["sha256"](f)
                for f in sorted(output.rglob("*")) if f.is_file()
            }
        except Exception as error:
            manifest.update(status="failed", finalization_error=type(error).__name__ + ": " + str(error))
        base["save"](output / "run-manifest.json", manifest)
        with (output / "SHA256SUMS.txt").open("x") as handle:
            handle.writelines(
                base["sha256"](f) + "  " + f.relative_to(output).as_posix() + "\n"
                for f in sorted(output.rglob("*")) if f.is_file() and f.name != "SHA256SUMS.txt"
            )
    print(json.dumps({"status": manifest["status"], "run_id": args.run_id, "samples": len(records)}, sort_keys=True))
    return 0 if manifest["status"] == "passed_batch" else 1


def stop_on_signal(signum, _frame):
    raise KeyboardInterrupt(f"Termination signal {signum} received")


def main():
    signal.signal(signal.SIGTERM, stop_on_signal)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("run",))
    parser.add_argument("--profile", required=True, choices=("systemd-vm",))
    parser.add_argument("--config", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--parent-network-namespace-file", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--project-commit", required=True)
    parser.add_argument("--vm-id", required=True)
    parser.add_argument("--batch-slot", required=True, type=int, choices=(0, 1, 2))
    return run(parser.parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
