#!/usr/bin/env python3
"""Host transport, caps and evidence validation for one frozen ARM64 batch."""

import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import runpy
import selectors
import signal
import stat
import statistics
import subprocess
import tarfile
import time


WORKLOADS = ("bisort", "em3d", "mst", "perimeter", "treeadd", "tsp")
ROTATIONS = ((0, 2, 4, 1, 3), (1, 3, 5, 0, 2), (4, 0, 5, 1, 3))
ARMS = {"exp-001": ("baseline", "asan"), "exp-002": ("rz32", "rz64")}
PREP_SECONDS = 150
VM_SECONDS = 480
LAUNCHER_SECONDS = 420
SEAL_SECONDS = 90
INIT_SECONDS = 150
GUEST_START_MARKER = b"FORMAL_GUEST_MEASURE_START"
FINAL_RESERVE_SECONDS = 240
ATTEMPT_SECONDS = PREP_SECONDS + VM_SECONDS + SEAL_SECONDS
HOST_SCRIPT = "scripts/run-arm64-formal.py"
GUEST_SCRIPT = "scripts/llvm-asan-formal.py"
PILOT_GUEST = "scripts/llvm-asan.py"
SOURCE_LOCK = "workloads/llvm-suite-lock.json"
SOURCE_LOCK_SHA256 = "169b5f76f4cd73bd0d9ad0c25d3f636e9dc316d0bd9369d3cf4631e2ba0a56f0"
REQUIRED_ISOLATION = {
    "linux_arm64", "non_root", "cpu_limit", "memory_limit", "no_swap", "pid_limit",
    "no_capabilities", "no_new_privileges", "network_disabled", "private_network_namespace",
    "readonly_project", "readonly_source",
}


class BatchError(RuntimeError):
    def __init__(self, category, message):
        super().__init__(message)
        self.category = category


def require(condition, message, category="preflight"):
    if not condition:
        raise BatchError(category, message)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def schedule(experiment, slot):
    left, right = ARMS[experiment]
    phases = [("warmup", 1, slot, slot)] + [
        ("measure", round_index + 1, rotation, slot + round_index)
        for round_index, rotation in enumerate(ROTATIONS[slot])
    ]
    for phase, iteration, rotation, offset in phases:
        for index in range(len(WORKLOADS)):
            number = (index + rotation) % len(WORKLOADS)
            arms = (right, left) if (offset + number) % 2 else (left, right)
            for arm in arms:
                yield WORKLOADS[number], phase, iteration, arm


def assert_batch_records(records, experiment, slot):
    expected = list(schedule(experiment, slot))
    require(isinstance(records, list) and len(records) == len(expected),
            "Expected 72 unique records in the frozen order", "sample_integrity")
    for sequence, (row, (name, phase, iteration, arm)) in enumerate(zip(records, expected), 1):
        sample_id = f"{experiment}-{name}-{phase}-{iteration:02}-{arm}"
        require(isinstance(row, dict) and row.get("experiment_id") == experiment
                and type(row.get("batch_slot")) is int and row["batch_slot"] == slot
                and type(row.get("sequence")) is int and row["sequence"] == sequence
                and row.get("benchmark") == name and row.get("phase") == phase
                and type(row.get("iteration")) is int and row["iteration"] == iteration
                and row.get("arm") == arm and row.get("sample_id") == sample_id,
                "Wrong batch order or identity at " + sample_id, "sample_integrity")
        require(row.get("valid") is True and row.get("reference_match") is True
                and row.get("timed_out") is False and row.get("sanitizer_report") is False
                and type(row.get("exit_code")) is int and row["exit_code"] == 0
                and type(row.get("program_exit_code")) is int and row["program_exit_code"] == 0,
                "Invalid sample " + sample_id, "sample_integrity")
        for key in ("real_seconds", "user_seconds", "sys_seconds"):
            value = row.get(key)
            require(type(value) in (int, float) and math.isfinite(value)
                    and (value > 0 if key == "real_seconds" else value >= 0),
                    "Invalid timer value at " + sample_id, "sample_integrity")


def verify_inventory(root, pilot):
    inventory = root / "SHA256SUMS.txt"
    require(inventory.is_file(), "No guest evidence inventory", "transport")
    checked = set()
    for line in inventory.read_text().splitlines():
        expected, separator, logical = line.partition("  ")
        require(bool(separator) and re.fullmatch(r"[0-9a-f]{64}", expected)
                and logical not in checked, "Invalid guest inventory", "transport")
        file = pilot["under"](root, logical)
        require(file.is_file() and sha(file) == expected, "Guest SHA mismatch: " + logical, "transport")
        checked.add(logical)
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p != inventory}
    require(checked == actual, "Incomplete guest inventory", "transport")
    return len(checked)


def signed_launcher(root, pilot):
    launch = root / ".local/arm64-vm/bin/run-arm64-vm"
    require(sha(launch) == pilot["BINARY_SHA"]
            and sha(root / "scripts/run-arm64-vm.m") == pilot["NATIVE_SOURCE_SHA"],
            "Retained native launcher or its source differs")
    subprocess.run(["codesign", "--verify", "--strict", str(launch)], check=True, capture_output=True, timeout=15)
    return launch


def frozen_inputs(args, root, pilot):
    project_commit = pilot["verify_zone"](root)
    config_path = args.config.resolve()
    require(config_path.is_relative_to(root), "Config must be in the verified work repository")
    cfg = pilot["read_json"](config_path)
    experiment = cfg.get("experiment_id")
    require(cfg.get("frozen") is True and cfg.get("execution_authorized") is True
            and cfg.get("kind") == "formal-olden-arm64"
            and experiment in ARMS, "A frozen formal experiment config is required")
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]{4,79}", str(cfg.get("campaign_id"))), "Invalid campaign ID")
    require(isinstance(cfg.get("expected_guest"), dict)
            and set(cfg["expected_guest"]) >= {"packages_sha256", "kernel_release", "compiler_version", "cmake_version", "ninja_version"}
            and re.fullmatch(r"[a-f0-9]{64}", str(cfg["expected_guest"]["packages_sha256"])),
            "Frozen package and guest version expectations are mandatory")
    require(cfg.get("plan_path") == f"experiments/{experiment}/PLAN.md", "Unexpected experiment plan path")
    plan = pilot["under"](root, cfg["plan_path"])
    require(sha(plan) == cfg.get("plan_sha256") and re.search(r"\|\s*`freeze_state`\s*\|\s*`frozen`\s*\|", plan.read_text()),
            "Formal plan is not frozen or its SHA differs")
    decision = pilot["under"](root, cfg["decision_path"])
    require(sha(decision) == cfg.get("decision_sha256"), "Frozen decision SHA differs")
    bindings = {HOST_SCRIPT: "formal_host_sha256", GUEST_SCRIPT: "formal_guest_sha256", PILOT_GUEST: "pilot_runner_sha256"}
    for path, key in bindings.items():
        require(sha(root / path) == cfg.get(key), "Frozen runtime script SHA differs: " + path)
    require(Path(__file__).resolve() == (root / HOST_SCRIPT).resolve(), "Run the frozen host script from the work repository")
    require(tuple(value["name"] for value in cfg["benchmarks"]) == WORKLOADS
            and cfg.get("warmups") == 1 and cfg.get("repetitions") == 5
            and cfg.get("overall_timeout_seconds") == 240 and cfg.get("execution_profile") == "systemd-vm",
            "Formal K/W design differs from plan")
    pilot_config = pilot["read_json"](root / "config/llvm-asan-arm64.json")
    for key in ("source", "cc", "cxx", "c_flags", "cxx_flags", "asan_flags", "asan_options", "limits", "benchmarks",
                "reference_line_endings", "minimum_interpretable_seconds", "command_timeout_seconds"):
        require(cfg.get(key) == pilot_config.get(key), "Locked design differs on " + key)
    lock = pilot["read_json"](root / SOURCE_LOCK)
    require(sha(root / SOURCE_LOCK) == SOURCE_LOCK_SHA256, "Fixed upstream source inventory SHA differs")
    source = args.source.resolve()
    source_receipt = pilot["verify_source"](source, lock, cfg)
    base = pilot["under"](root, cfg["base_disk_path"])
    require(base.is_file() and not (stat.S_IMODE(base.stat().st_mode) & 0o222)
            and 0 < base.stat().st_size <= 30 * pilot["GIB"] and sha(base) == cfg.get("base_sha256"),
            "Read-only prepared dependency base missing or SHA differs")
    if "base_receipt_path" in cfg or "base_receipt_sha256" in cfg:
        receipt_path = pilot["under"](root, cfg["base_receipt_path"])
        require(sha(receipt_path) == cfg.get("base_receipt_sha256"), "Base provisioning receipt differs")
    kernel = pilot["under"](root, cfg["kernel_path"])
    initrd = pilot["under"](root, cfg["initrd_path"])
    require(sha(kernel) == cfg.get("kernel_sha256") and sha(initrd) == cfg.get("initrd_sha256"),
            "Frozen boot kernel/initrd differs")
    resources = pilot["host_resources"](root)
    return cfg, project_commit, plan, decision, config_path, lock, source, source_receipt, base, kernel, initrd, resources


@contextmanager
def phase_budget(seconds, category):
    def expire(_sig, _frame):
        raise BatchError(category, "Phase exceeded its elapsed-time bound")
    previous = signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def input_archive(root, config_path, source, lock):
    files = {"project/" + GUEST_SCRIPT: root / GUEST_SCRIPT,
             "project/" + PILOT_GUEST: root / PILOT_GUEST,
             "project/" + SOURCE_LOCK: root / SOURCE_LOCK,
             "project/config/llvm-asan-arm64.json": config_path}
    files.update({"suite/" + item["path"]: source / item["path"] for item in lock["files"]})
    output = io.BytesIO()
    hashes = {}
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            hashes[name] = checksum(data)
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
    packed = output.getvalue()
    require(len(packed) < 10 * 1024 ** 2, "Input too big for the signed native launcher's cloud seed")
    require(all(hashes["suite/" + item["path"]] == item["sha256"] for item in lock["files"]),
            "Workload changed while building the guest input archive")
    return packed, hashes


def setup_text(run_id, project_commit, slot, input_sha, host_epoch):
    template = r'''#!/bin/bash
set -eu
export LC_ALL=C TZ=UTC
root=/var/log/arm64-formal-evidence
mkdir -p "$root/setup" "$root/data"
exec >"$root/setup/setup.log" 2>&1
finish() {
  rc=$?; trap - EXIT; set +e
  printf '%s\n' "$rc" > "$root/setup/setup-exit-code.txt"
  date -u +%FT%TZ > "$root/setup/finished-at.txt"
  if [ "$(du -sx -B1 "$root" | cut -f1)" -le 100663296 ]; then
    tar -C "$root" -czf /tmp/formal-evidence.tar.gz .
    if [ $? -eq 0 ] && [ "$(stat -c%s /tmp/formal-evidence.tar.gz)" -le 33554432 ]; then
      printf '\nPILOT_EVIDENCE_SHA256 %s\n' "$(sha256sum /tmp/formal-evidence.tar.gz | cut -d' ' -f1)" > /dev/hvc0
      printf '\nPILOT_EVIDENCE_BEGIN\n' > /dev/hvc0
      base64 /tmp/formal-evidence.tar.gz > /dev/hvc0
      printf '\nPILOT_EVIDENCE_END\n' > /dev/hvc0
    fi
  fi
  sync; /sbin/poweroff
}
trap finish EXIT
printf '%s\n' "$(date -u +%FT%TZ)" > "$root/setup/clock-before.txt"
date -u -s '@HOST_EPOCH' > "$root/setup/clock-after.txt"
for entry in /sys/class/net/*; do [ "$(basename "$entry")" = lo ] || exit 31; done
ip -json address > "$root/setup/network-offline.json"
readlink /proc/self/ns/net > /run/llvm-asan-parent-netns
chmod 0444 /run/llvm-asan-parent-netns
mkdir -p /opt/pilot /project /suite /evidence
printf '%s  %s\n' 'INPUT_SHA' /opt/pilot-inputs.tar.gz | sha256sum -c -
tar -xzf /opt/pilot-inputs.tar.gz -C /opt/pilot --no-same-owner
id pilotcheck || useradd --create-home --shell /bin/bash pilotcheck
chown pilotcheck:pilotcheck "$root/data"
printf '\nFORMAL_GUEST_MEASURE_START\n' > /dev/hvc0
# The launcher also uses no virtio network device for this attempt.
set +e
systemd-run --unit=arm64-formal --wait --pipe --collect \
 --property=User=pilotcheck --property=CPUQuota=200% --property=MemoryMax=2G \
 --property=MemorySwapMax=0 --property=TasksMax=128 --property=LimitCORE=0 \
 --property=RuntimeMaxSec=240 --property=PrivateNetwork=yes --property=NoNewPrivileges=yes \
 --property=CapabilityBoundingSet= --property=ProtectSystem=strict --property=ProtectHome=yes \
 --property=PrivateDevices=yes --property=ReadWritePaths=/evidence \
 --property=BindPaths="$root/data:/evidence" \
 --property=BindReadOnlyPaths='/opt/pilot/project:/project /opt/pilot/suite:/suite' \
 --property=TemporaryFileSystem='/tmp:rw,exec,nosuid,nodev,size=768M,mode=1777' \
 python3 /project/scripts/llvm-asan-formal.py run --profile systemd-vm \
 --config /project/config/llvm-asan-arm64.json --source /suite \
 --parent-network-namespace-file /run/llvm-asan-parent-netns \
 --output /evidence/RUN_ID --run-id RUN_ID --project-commit PROJECT_COMMIT --vm-id RUN_ID --batch-slot BATCH_SLOT \
 > "$root/setup/formal-command.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$root/setup/formal-exit-code.txt"
exit "$rc"
'''
    return (template.replace("RUN_ID", run_id).replace("PROJECT_COMMIT", project_commit)
            .replace("BATCH_SLOT", str(slot)).replace("INPUT_SHA", input_sha).replace("HOST_EPOCH", str(host_epoch)))


def prepare(args, root, run, instance, context, pilot):
    cfg, project_commit, plan, decision, config_path, lock, source, source_receipt, base, kernel, initrd, resources = context
    instance.mkdir(parents=True)
    provenance = run / "provenance"
    provenance.mkdir()
    pilot["write_new"](provenance / "host-preflight.json", resources)
    pilot["write_new"](provenance / "source-receipt.json", {**source_receipt, "lock_sha256": SOURCE_LOCK_SHA256})
    for relative in (HOST_SCRIPT, GUEST_SCRIPT, PILOT_GUEST, "scripts/run-arm64-pilot.py", SOURCE_LOCK, cfg["plan_path"], cfg["decision_path"]):
        output = provenance / "source" / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes((root / relative).read_bytes())
    config_folder = run / "config"
    config_folder.mkdir()
    (config_folder / "effective.json").write_bytes(config_path.read_bytes())
    payload, input_hashes = input_archive(root, config_path, source, lock)
    pilot["write_new"](provenance / "guest-inputs.json", input_hashes)
    raw = instance / "root.raw"
    subprocess.run(["cp", "-c", str(base), str(raw)], check=True, capture_output=True, timeout=90)
    raw.chmod(0o600)
    require(sha(raw) == cfg["base_sha256"], "Fresh VM clone does not match the frozen dependency base")
    launch = signed_launcher(root, pilot)
    kernel_image = instance / "Image"
    kernel_bytes = kernel.read_bytes()
    kernel_image.write_bytes(gzip.decompress(kernel_bytes) if kernel_bytes.startswith(b"\x1f\x8b") else kernel_bytes)
    setup = setup_text(args.run_id, project_commit, args.batch_slot, checksum(payload), int(time.time()))
    (config_folder / "guest-setup.sh").write_text(setup)
    cloud = {"hostname": "arm64-formal", "ssh_pwauth": False, "disable_root": True,
             "ssh_genkeytypes": [], "package_update": False, "package_upgrade": False,
             "users": [{"name": "pilotcheck", "lock_passwd": True}],
             "write_files": [{"path": "/opt/pilot-inputs.tar.gz", "encoding": "b64", "permissions": "0644",
                              "content": base64.b64encode(payload).decode()},
                             {"path": "/opt/formal-setup.sh", "encoding": "b64", "permissions": "0755",
                              "content": base64.b64encode(setup.encode()).decode()}],
             "runcmd": [["bash", "/opt/formal-setup.sh"]]}
    seed_files = instance / "seed-files"
    seed_files.mkdir()
    (seed_files / "user-data").write_text("#cloud-config\n" + json.dumps(cloud) + "\n")
    (seed_files / "meta-data").write_text(json.dumps({"instance-id": args.run_id, "local-hostname": "arm64-formal"}) + "\n")
    seed = instance / "seed.iso"
    subprocess.run(["hdiutil", "makehybrid", "-iso", "-joliet", "-default-volume-name", "cidata",
                    "-o", str(seed), str(seed_files)], check=True, capture_output=True, timeout=40)
    require(0 < seed.stat().st_size <= 16 * 1024 ** 2, "Seed is above native launcher cap")
    pilot["write_new"](config_folder / "boot-inputs.json", {
        "run_id": args.run_id, "base_sha256": cfg["base_sha256"], "kernel_sha256": sha(kernel_image),
        "initrd_sha256": cfg["initrd_sha256"], "seed_sha256": sha(seed), "payload_sha256": checksum(payload),
        "launcher_sha256": pilot["BINARY_SHA"], "network": "none", "launcher_seconds": LAUNCHER_SECONDS,
        "vm_lifecycle_seconds": VM_SECONDS, "project_commit": project_commit,
    })
    return [str(launch), "--disk", str(raw), "--kernel", str(kernel_image), "--initrd", str(initrd),
            "--seed", str(seed), "--network", "none", "--timeout", str(LAUNCHER_SECONDS)]


def collect_serial(argv, console, lifecycle, pilot):
    start = time.monotonic()
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    selector = selectors.DefaultSelector()
    limits = {console: pilot["MAX_CONSOLE"], lifecycle: 4 * 1024 ** 2}
    counts = {console: 0, lifecycle: 0}
    prefix = b""
    guest_initialized = False
    selector.register(process.stdout, selectors.EVENT_READ, console)
    selector.register(process.stderr, selectors.EVENT_READ, lifecycle)
    try:
        while selector.get_map():
            # Leave 40s for this launcher's own graceful shutdown after TERM.
            limit = start + (VM_SECONDS - 40 if guest_initialized else INIT_SECONDS)
            require(guest_initialized or time.monotonic() < limit,
                    "Guest initialization did not finish within 150 seconds", "initialization_timeout")
            require(time.monotonic() < limit, "VM or evidence transport exceeded its outer time bound", "vm_timeout")
            for key, _ in selector.select(min(0.25, max(0.0, limit - time.monotonic()))):
                block = os.read(key.fileobj.fileno(), 65536)
                if not block:
                    selector.unregister(key.fileobj)
                    continue
                file = key.data
                if file is console and not guest_initialized:
                    marker_window = prefix + block
                    guest_initialized = GUEST_START_MARKER in marker_window
                    prefix = marker_window[-len(GUEST_START_MARKER):]
                counts[file] += len(block)
                require(counts[file] <= limits[file], "Console or lifecycle log above bounded capture", "transport")
                file.write(block)
        return process.wait(timeout=max(0.1, min(5, start + VM_SECONDS - time.monotonic())))
    finally:
        selector.close()
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=max(0.1, min(40, start + VM_SECONDS - time.monotonic() - 1)))
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1)
        process.stdout.close()
        process.stderr.close()


def options_for(cfg):
    options = cfg["asan_options"]
    if cfg["experiment_id"] == "exp-001":
        return {"baseline": options, "asan": options}
    settings = options.split(":")
    larger = [part.split("=", 1)[0] + "=64" if part in {"redzone=32", "max_redzone=32"} else part
              for part in settings]
    require(sum(x != y for x, y in zip(settings, larger)) == 2, "Frozen redzone pair is not valid", "environment")
    return {"rz32": options, "rz64": ":".join(larger)}


def verify_guest_artifacts(guest, cfg, project_commit, slot, run_id, source, pilot):
    setup = guest / "setup"
    require((setup / "setup-exit-code.txt").is_file(), "Guest setup terminal status absent", "transport")
    guest_run = guest / "data" / run_id
    require(guest_run.is_dir(), "Guest initialization or VM safety check failed", "environment")
    files_checked = verify_inventory(guest_run, pilot)
    state = pilot["read_json"](guest_run / "run-manifest.json")
    if state.get("status") != "passed_batch":
        message = state.get("error", state.get("status", "unknown"))
        raise BatchError("sample_integrity", "Guest experiment failed: " + str(message))
    require((setup / "setup-exit-code.txt").read_text().strip() == "0"
            and (setup / "formal-exit-code.txt").read_text().strip() == "0",
            "Guest setup or formal runner did not exit successfully", "environment")
    require(state.get("run_id") == run_id and state.get("vm_id") == run_id and state.get("batch_slot") == slot
            and state.get("project_commit") == project_commit and state.get("kind") == "formal-olden-arm64"
            and state.get("experiment_id") == cfg["experiment_id"] and state.get("samples") == 72
            and state.get("runner_sha256") == cfg["formal_guest_sha256"]
            and state.get("shared_runner_sha256") == cfg["pilot_runner_sha256"],
            "Guest draft, code, or batch identity mismatch", "sample_integrity")
    require(pilot["read_json"](guest_run / "config/effective.json") == cfg,
            "Guest did not run with the exact frozen configuration", "environment")
    require(sha(guest_run / "provenance/packages.stdout.log") == cfg["expected_guest"]["packages_sha256"],
            "Guest package inventory differs from the sealed dependency base", "environment")
    require(all(state.get("guest", {}).get(key) == value for key, value in cfg["expected_guest"].items()),
            "Guest kernel or toolchain receipt differs", "environment")
    isolation = pilot["read_json"](guest_run / "validation/isolation.json")
    checks = isolation.get("checks", {})
    require(set(checks) >= REQUIRED_ISOLATION and all(value is True for value in checks.values()),
            "One or more effective offline guest controls failed", "isolation")
    records = pilot["read_json"](guest_run / "metrics/records.json")
    assert_batch_records(records, cfg["experiment_id"], slot)
    arm_options = options_for(cfg)
    by_arm = pilot["read_json"](guest_run / "config/arms.json")
    require(set(by_arm) == set(arm_options) and all(by_arm[arm]["asan_options"] == value
                for arm, value in arm_options.items()), "Guest runtime arm variables differ", "environment")
    observed_options = pilot["read_json"](guest_run / "validation/runtime-options.json")
    require(set(observed_options) == set(arm_options), "Missing effective runtime-option receipts", "environment")
    for arm, expected in arm_options.items():
        receipt = observed_options[arm]
        requested = dict(part.split("=", 1) for part in expected.split(":"))
        observed = {key: {"false": "0", "true": "1"}.get(value, value)
                    for key, value in receipt["observed"].items()}
        observed_expected = dict(requested, malloc_context_size="1")
        require(receipt["requested"] == requested and observed == observed_expected,
                "ASan effective runtime options differ", "environment")
    expected_binaries = {}
    for name, arm_config in by_arm.items():
        build = arm_config["build"]
        require(build == ("baseline" if name == "baseline" else "asan"), "Wrong binary for arm", "environment")
        expected_binaries[name] = pilot["read_json"](guest_run / "provenance" / build / "binaries.json")
    benchmark_paths = {entry["name"]: entry["directory"] for entry in cfg["benchmarks"]}
    for index, row in enumerate(records, start=1):
        sample_id = row["sample_id"]
        individual = pilot["read_json"](guest_run / "metrics/records" / f"{index:03}.json")
        require(individual == row, "Per-record manifest disagrees with batch manifest", "sample_integrity")
        require(row.get("asan_options") == arm_options[row["arm"]]
                and row.get("binary_sha256") == expected_binaries[row["arm"]][row["benchmark"]],
                "Wrong executable or option evidence at " + sample_id, "environment")
        raw = (guest_run / "raw-outputs" / (sample_id + ".output.txt")).read_bytes()
        require(checksum(raw) == row.get("output_sha256") and b"AddressSanitizer" not in raw,
                "Raw output checksum or sanitizer result disagrees", "sample_integrity")
        timing_lines = (guest_run / "raw-outputs" / (sample_id + ".time.txt")).read_text().splitlines()
        timings = dict(line.split() for line in timing_lines)
        require(len(timing_lines) == 4 and set(timings) == {"exit", "real", "user", "sys"}
                and int(timings["exit"]) == 0 and all(float(timings[key]) == row[key + "_seconds"]
                for key in ("real", "user", "sys")), "Raw timer values disagree", "sample_integrity")
        output = guest_run / "validation/normalized-output" / (sample_id + ".txt")
        reference = guest_run / "validation/normalized-reference" / (row["benchmark"] + ".txt")
        fixed_ref = source / benchmark_paths[row["benchmark"]] / (row["benchmark"] + ".reference_output")
        require(output.read_bytes() == raw.replace(b"\r\n", b"\n")
                and reference.read_bytes() == fixed_ref.read_bytes().replace(b"\r\n", b"\n"),
                "Normalized output or frozen reference bytes disagree", "sample_integrity")
        comparison = pilot["read_json"](guest_run / "validation" / (sample_id + ".command.json"))
        prefix = "/evidence/" + run_id + "/validation/"
        argv = comparison.get("argv", [])
        require(len(argv) == 3 and Path(argv[0]).name == "fpcmp"
                and argv[1] == prefix + "normalized-output/" + sample_id + ".txt"
                and argv[2] == prefix + "normalized-reference/" + row["benchmark"] + ".txt"
                and comparison.get("timed_out") is False and comparison.get("exit_code") == 0,
                "No verified original comparison at " + sample_id, "sample_integrity")
    verify_batch_summary(guest_run, records, cfg["experiment_id"], slot, pilot)
    return files_checked, len(records)


def verify_batch_summary(guest_run, records, experiment, slot, pilot):
    summary = pilot["read_json"](guest_run / "metrics/summary.json")
    require(summary.get("all_benchmarks_valid") is True and summary.get("experiment_id") == experiment
            and summary.get("batch_slot") == slot, "Guest batch summary is incomplete", "sample_integrity")
    means = {}
    for name in WORKLOADS:
        means[name] = [statistics.mean(row["real_seconds"] for row in records
                       if row["benchmark"] == name and row["arm"] == arm and row["phase"] == "measure")
                       for arm in ARMS[experiment]]
    ratios = {name: upper / lower for name, (lower, upper) in means.items()}
    expected = {"arithmetic_mean_runtime_ratio": statistics.mean(ratios.values()),
                "geometric_mean_runtime_ratio": statistics.geometric_mean(ratios.values()),
                "arithmetic_mean_runtime_ratio_without_mst": statistics.mean(value for name, value in ratios.items()
                                                                               if name != "mst")}
    require(all(math.isclose(summary[key], value, rel_tol=1e-10) for key, value in expected.items()),
            "Guest suite aggregates disagree with raw records", "sample_integrity")


def seal(run, manifest, pilot):
    manifest["finished_at"] = utc_now()
    temp = run / ".terminal.tmp"
    pilot["write_new"](temp, manifest)
    inventory = run / "SHA256SUMS.txt"
    pending = run / ".inventory.tmp"
    with pending.open("x") as handle:
        for file in sorted(run.rglob("*")):
            if file.is_file() and file not in (temp, pending, run / "run-manifest.json"):
                handle.write(sha(file) + "  " + file.relative_to(run).as_posix() + "\n")
        handle.write(sha(temp) + "  run-manifest.json\n")
    os.replace(pending, inventory)
    os.replace(temp, run / "run-manifest.json")


def launch_batch(argv, run, instance, pilot):
    logs = run / "logs"
    logs.mkdir()
    serial_log = logs / "console.log"
    native_log = instance / "native.raw.log"
    try:
        with serial_log.open("xb") as console, native_log.open("xb") as lifecycle:
            returncode = collect_serial(argv, console, lifecycle, pilot)
    finally:
        if native_log.is_file():
            raw = native_log.read_text(errors="replace")
            (logs / "lifecycle.log").write_text(raw.replace(str(run.parent.parent), "<work-zone>"))
    return returncode


def recover_guest(run, instance, returncode, pilot):
    stdout = run / "logs/console.log"
    lifecycle = run / "logs/lifecycle.log"
    events = []
    for line in lifecycle.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    terminal = next((event for event in reversed(events) if event.get("event") == "host_finished"), {})
    try:
        packed = pilot["parse_frame"](stdout.read_bytes())
        (instance / "guest-evidence.tar.gz").write_bytes(packed)
        pilot["extract_safe"](packed, run / "guest-evidence")
    except Exception as error:
        category = "transport" if returncode == 0 and terminal.get("reason") == "guest_powered_off" else "vm_failure"
        raise BatchError(category, "Could not recover bounded guest evidence: " + str(error)) from error
    require(returncode == 0 and terminal.get("reason") == "guest_powered_off" and terminal.get("exit_code") == 0,
            "Native launcher did not observe a normal guest shutdown", "vm_failure")
    require(any(e.get("event") == "configuration_validated" and e.get("network") == "none"
            and e.get("shared_directories") == 0 and e.get("published_ports") == 0
            and e.get("vcpus") == 2 and e.get("memory_bytes") == 3 * pilot["GIB"]
            and 0 < e.get("disk_bytes_max", 0) <= 30 * pilot["GIB"] for e in events),
            "Native launcher resource or network evidence differs", "isolation")
    return checksum(packed)


def collection(args, root, pilot):
    require(args.remaining_seconds is not None and args.remaining_seconds >= ATTEMPT_SECONDS + FINAL_RESERVE_SECONDS,
            "Remaining campaign time will not cover a full attempt and final audit", "budget")
    require(args.batch_slot in (0, 1, 2) and isinstance(args.run_id, str)
            and re.fullmatch(r"run-\d{8}t\d{6}z-exp-00[12]-a\d{2}", args.run_id),
            "A unique frozen-format run ID and batch slot are required")
    run = root / "runs" / args.run_id
    instance = root / ".local/arm64-formal/instances" / args.run_id
    require(args.output is not None and args.output.resolve() == run.resolve()
            and not run.exists() and not instance.exists(), "Run output or VM instance is not fresh")
    manifest = None
    started = time.monotonic()
    sealing_started = None
    try:
        with phase_budget(PREP_SECONDS, "preparation_timeout"):
            context = frozen_inputs(args, root, pilot)
            cfg, project_commit, plan, decision, config_path, _, source, _, _, _, _, _ = context
            require(f"-{cfg['experiment_id']}-" in args.run_id, "Run ID and frozen experiment differ")
            run.mkdir()
            manifest = {"status": "preparing", "kind": cfg["kind"], "experiment_id": cfg["experiment_id"],
                        "campaign_id": cfg["campaign_id"], "run_id": args.run_id, "vm_id": args.run_id,
                        "batch_slot": args.batch_slot, "project_commit": project_commit, "base_commit": project_commit,
                        "plan_sha256": sha(plan), "decision_sha256": sha(decision), "config_payload_sha256": sha(config_path),
                        "base_sha256": cfg["base_sha256"], "started_at": utc_now(), "remaining_seconds_at_start": args.remaining_seconds}
            pilot["write_new"](run / "run-manifest.json", manifest)
            argv = prepare(args, root, run, instance, context, pilot)
            resource_recheck = pilot["host_resources"](root)
            pilot["write_new"](run / "provenance/host-prelaunch.json", resource_recheck)
        require(args.remaining_seconds - (time.monotonic() - started) >= VM_SECONDS + SEAL_SECONDS + FINAL_RESERVE_SECONDS,
                "Remaining campaign time fails the post-rehash launch gate", "budget")
        manifest["vm_launch_at"] = utc_now()
        returncode = launch_batch(argv, run, instance, pilot)
        sealing_started = time.monotonic()
        with phase_budget(SEAL_SECONDS - 10, "sealing_timeout"):
            manifest["archive_sha256"] = recover_guest(run, instance, returncode, pilot)
            files, records = verify_guest_artifacts(run / "guest-evidence", cfg, project_commit, args.batch_slot,
                                                   args.run_id, source, pilot)
            manifest.update(status="passed_batch", host_exit_code=returncode, guest_files_checked=files,
                            records_checked=records, samples=records)
    except (Exception, KeyboardInterrupt) as error:
        if manifest is None:
            raise
        failed = getattr(error, "category", "operational")
        manifest.update(status="invalid_batch" if failed in {"sample_integrity", "environment", "isolation"} else "failed",
                        failure_class=failed, error=str(error).replace(str(root), "<work-zone>"))
    manifest["elapsed_seconds"] = time.monotonic() - started
    elapsed_sealing = time.monotonic() - sealing_started if sealing_started is not None else 0
    with phase_budget(max(1, SEAL_SECONDS - elapsed_sealing), "sealing_timeout"):
        seal(run, manifest, pilot)
    return manifest


def selftest():
    for experiment in ARMS:
        for slot in range(3):
            samples = []
            for sequence, (name, phase, iteration, arm) in enumerate(schedule(experiment, slot), 1):
                samples.append(dict(experiment_id=experiment, batch_slot=slot, sequence=sequence, benchmark=name,
                                    phase=phase, iteration=iteration, arm=arm,
                                    sample_id=f"{experiment}-{name}-{phase}-{iteration:02}-{arm}",
                                    valid=True, reference_match=True, timed_out=False, sanitizer_report=False,
                                    exit_code=0, program_exit_code=0, real_seconds=0.75, user_seconds=0.5, sys_seconds=0.0))
            require(len({row["sample_id"] for row in samples}) == 72, "Bad fixture")
            assert_batch_records(samples, experiment, slot)
            for changed in (samples[1:], [samples[1], samples[0], *samples[2:]],
                            [{**samples[0], "timed_out": True}, *samples[1:]]):
                try:
                    assert_batch_records(changed, experiment, slot)
                except BatchError:
                    continue
                raise AssertionError("Invalid fixture was accepted")
    main_first_measure = list(schedule("exp-001", 1))[12:14]
    require(main_first_measure == [("em3d", "measure", 1, "baseline"), ("em3d", "measure", 1, "asan")],
            "Batch 1 rotation and parity should match the approved design")
    return {"status": "passed_selftest", "matrices": 6, "negative_cases": 18, "vm_started": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--mode", choices=("preflight", "collect", "selftest"), required=True)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--batch-slot", type=int)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--remaining-seconds", type=int)
    args = parser.parse_args()
    root = args.root.resolve()
    def interrupted(sig, _frame):
        raise KeyboardInterrupt(f"Signal {sig}; only the task VM is being stopped")
    signal.signal(signal.SIGTERM, interrupted)
    try:
        if args.mode == "selftest":
            print(json.dumps(selftest(), sort_keys=True))
            return 0
        require(args.config is not None and args.source is not None, "Supply frozen config and pinned checkout")
        pilot = runpy.run_path(str(root / "scripts/run-arm64-pilot.py"))
        if args.mode == "preflight":
            with phase_budget(PREP_SECONDS, "preparation_timeout"):
                cfg, commit, _, _, config, _, _, verified_source, _, _, _, resources = frozen_inputs(args, root, pilot)
                signed_launcher(root, pilot)
                report = {"status": "passed_preflight", "vm_started": False, "experiment_id": cfg["experiment_id"],
                          "source": verified_source, "project_commit": commit, "resources": resources,
                          "config_payload_sha256": sha(config), "plan_sha256": cfg["plan_sha256"]}
        else:
            report = collection(args, root, pilot)
        print(json.dumps(report, sort_keys=True))
        return 0 if report["status"].startswith("passed_") else 1
    except (Exception, KeyboardInterrupt) as error:
        print(json.dumps({"status": "blocked", "failure_class": getattr(error, "category", "operational"),
                          "error": str(error).replace(str(root), "<work-zone>")}, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
