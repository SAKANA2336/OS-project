#!/usr/bin/env python3
"""Audit sealed ARM64 Olden batches and compute the frozen cross-batch results."""

import argparse
import hashlib
import json
import math
import re
from datetime import datetime
from pathlib import Path, PurePosixPath
from statistics import geometric_mean, mean, stdev


BENCHMARKS = ("bisort", "em3d", "mst", "perimeter", "treeadd", "tsp")
ARMS = {"exp-001": ("baseline", "asan"), "exp-002": ("rz32", "rz64")}
ROTATIONS = ((0, 2, 4, 1, 3), (1, 3, 5, 0, 2), (4, 0, 5, 1, 3))
SHA256_RE = re.compile(r"[0-9a-f]{64}")
OTHER_TERMINAL = {"failed", "stopped", "invalid_batch"}


class EvidenceError(ValueError):
    """A required run or sample could not be independently verified."""


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def digest(path):
    with path.open("rb") as stream:
        sha = hashlib.sha256()
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(part)
        return sha.hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_object)


def is_digest(value):
    return isinstance(value, str) and SHA256_RE.fullmatch(value) is not None


def check_seal(run):
    require(run.is_dir() and not run.is_symlink(), "Run must be a real directory")
    seal = run / "SHA256SUMS.txt"
    require(seal.is_file() and not seal.is_symlink(), "Missing outer checksum seal")
    inventory = {}
    for line in seal.read_text(encoding="utf-8").splitlines():
        checksum, marker, logical = line.partition("  ")
        path = PurePosixPath(logical)
        require(
            marker and is_digest(checksum) and logical == path.as_posix()
            and not path.is_absolute() and path.parts and ".." not in path.parts
            and logical != seal.name and logical not in inventory,
            "Invalid or duplicate checksum path",
        )
        inventory[logical] = checksum
    actual = set()
    for path in run.rglob("*"):
        require(not path.is_symlink(), f"Unexpected symlink: {path.relative_to(run)}")
        if path != seal and path.is_file():
            actual.add(path.relative_to(run).as_posix())
    require(set(inventory) == actual, "Seal and actual file inventories differ")
    require("run-manifest.json" in inventory, "Outer manifest is outside the seal")
    for name, expected in inventory.items():
        require(digest(run / name) == expected, f"Checksum mismatch: {name}")
    return inventory


def schedule(experiment, slot):
    """Canonical tuple order used to independently verify the guest sequence."""
    require(type(slot) is int and 0 <= slot < len(ROTATIONS), "Invalid batch slot")
    arms = ARMS[experiment]
    yield from schedule_round(arms, "warmup", 1, slot, slot)
    for round_index, rotation in enumerate(ROTATIONS[slot]):
        yield from schedule_round(arms, "measure", round_index + 1, rotation, slot + round_index)


def schedule_round(arms, phase, iteration, rotation, parity):
    order = list(range(len(BENCHMARKS)))
    for index in order[rotation:] + order[:rotation]:
        pair = arms if (parity + index) % 2 == 0 else arms[::-1]
        for arm in pair:
            yield BENCHMARKS[index], phase, iteration, arm


def check_timing(path, record):
    timing = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        key, value = line.split()
        require(key not in timing, f"Repeated timeit field: {key}")
        timing[key] = value
    require(timing.keys() == {"exit", "real", "user", "sys"}, "Incomplete timeit evidence")
    require(int(timing["exit"]) == 0, "Nonzero timeit program exit")
    for field in ("real", "user", "sys"):
        seconds = float(timing[field])
        value = record.get(field + "_seconds")
        require(type(value) in (int, float) and math.isfinite(value), f"Invalid {field} time")
        require(seconds == value and seconds >= 0, f"Wrong recorded {field} time")
    require(record["real_seconds"] > 0, "Nonpositive wall time")


def check_command(path, purpose):
    command = load_json(path)
    require(
        type(command.get("exit_code")) is int and command["exit_code"] == 0
        and command.get("timed_out") is False and command.get("started") is True
        and isinstance(command.get("argv"), list) and command["argv"],
        f"Invalid {purpose} command evidence",
    )
    return command


def parse_options(value):
    require(isinstance(value, str), "Missing ASan options")
    options = {}
    for field in value.split(":"):
        key, marker, setting = field.partition("=")
        require(marker and key and setting and key not in options, "Invalid or duplicate ASan option")
        options[key] = setting
    return options


def check_record(guest, experiment, slot, position, planned, record):
    benchmark, phase, iteration, arm = planned
    label = f"{experiment}-{benchmark}-{phase}-{iteration:02d}-{arm}"
    require(
        type(record.get("batch_slot")) is int and record["batch_slot"] == slot
        and record.get("experiment_id") == experiment
        and type(record.get("sequence")) is int and record["sequence"] == position
        and type(record.get("iteration")) is int
        and (record.get("benchmark"), record.get("phase"), record["iteration"], record.get("arm")) == planned
        and record.get("sample_id") == label,
        f"Unexpected schedule at position {position}, expected {label}",
    )
    require(record == load_json(guest / "metrics" / "records" / f"{position:03d}.json"),
            f"Individual record disagrees with ordered list: {label}")
    require(
        record.get("valid") is True and record.get("reference_match") is True
        and record.get("timed_out") is False and record.get("sanitizer_report") is False
        and type(record.get("exit_code")) is int and record["exit_code"] == 0
        and type(record.get("program_exit_code")) is int and record["program_exit_code"] == 0,
        f"Invalid sample: {label}",
    )
    check_timing(guest / "raw-outputs" / (label + ".time.txt"), record)
    check_command(guest / "logs" / (label + ".command.json"), "measurement")
    check_command(guest / "validation" / (label + ".command.json"), "reference")
    raw = guest / "raw-outputs" / (label + ".output.txt")
    normalized = guest / "validation" / "normalized-output" / (label + ".txt")
    reference = guest / "validation" / "normalized-reference" / (benchmark + ".txt")
    raw_data = raw.read_bytes()
    output_paths = (guest / "logs" / (label + ".stdout.log"), guest / "logs" / (label + ".stderr.log"))
    require(b"AddressSanitizer" not in raw_data and all(
        b"AddressSanitizer" not in path.read_bytes() for path in output_paths
    ), f"Unexpected sanitizer report: {label}")
    require(normalized.read_bytes() == raw_data.replace(b"\r\n", b"\n"),
            f"Normalized output disagrees with raw output: {label}")
    require(
        digest(raw) == record.get("output_sha256")
        and digest(normalized) == record.get("normalized_output_sha256")
        and digest(reference) == record.get("normalized_reference_sha256"),
        f"Output evidence digests disagree: {label}",
    )


def check_extension(guest, rows):
    binary_hashes = load_json(guest / "provenance" / "asan" / "binaries.json")
    definitions = load_json(guest / "config" / "arms.json")
    parsed = {}
    for arm, size in (("rz32", "32"), ("rz64", "64")):
        definition = definitions[arm]
        require(definition.get("build") == "asan", "Both redzone arms must use the same ASan build")
        options = parse_options(definition.get("asan_options"))
        require(options.pop("redzone", None) == size and options.pop("max_redzone", None) == size,
                f"Invalid fixed redzone bounds: {arm}")
        parsed[arm] = options
    require(parsed["rz32"] == parsed["rz64"], "Unplanned ASan option differences")
    for row in rows:
        binary = binary_hashes.get(row["benchmark"])
        require(is_digest(binary) and row.get("binary_sha256") == binary,
                f"Evidence does not bind the shared ASan binary: {row['sample_id']}")
        require(row.get("asan_options") == definitions[row["arm"]]["asan_options"],
                f"Options changed during the batch: {row['sample_id']}")


def summarize_batch(experiment, rows):
    first, second = ARMS[experiment]
    observations = {(name, arm): [] for name in BENCHMARKS for arm in (first, second)}
    for row in rows:
        if row["phase"] == "measure":
            observations[row["benchmark"], row["arm"]].append(row["real_seconds"])
    benchmarks = {}
    for name in BENCHMARKS:
        arms = {}
        for arm in (first, second):
            values = observations[name, arm]
            require(len(values) == 5, "A complete arm must contain five measurements")
            arms[arm] = {"mean_seconds": mean(values), "sample_sd_seconds": stdev(values), "n": len(values)}
        ratio = arms[second]["mean_seconds"] / arms[first]["mean_seconds"]
        require(math.isfinite(ratio) and ratio > 0, f"Invalid derived runtime ratio: {name}")
        benchmarks[name] = {
            "arms": arms,
            "runtime_ratio": ratio,
            "short_run_warning": min(arm["mean_seconds"] for arm in arms.values()) < 0.050,
        }
    ratios = [benchmarks[name]["runtime_ratio"] for name in BENCHMARKS]
    return {
        "benchmarks": benchmarks,
        "arithmetic_mean_runtime_ratio": mean(ratios),
        "geometric_mean_runtime_ratio": geometric_mean(ratios),
        "arithmetic_mean_runtime_ratio_without_mst": mean(
            benchmarks[name]["runtime_ratio"] for name in BENCHMARKS if name != "mst"
        ),
    }


def load_batch(run, experiment, manifest):
    slot = manifest["batch_slot"]
    guest = run / "guest-evidence" / "data" / manifest["run_id"]
    check_seal(guest)
    guest_manifest = load_json(guest / "run-manifest.json")
    require(
        guest_manifest.get("run_id") == manifest["run_id"]
        and guest_manifest.get("vm_id") == manifest["vm_id"]
        and type(guest_manifest.get("samples")) is int and guest_manifest["samples"] == 72
        and guest_manifest.get("kind") == "formal-olden-arm64"
        and guest_manifest.get("experiment_id") == experiment
        and type(guest_manifest.get("batch_slot")) is int and guest_manifest["batch_slot"] == slot
        and guest_manifest.get("status") == "passed_batch",
        "Guest manifest is not a matching passed formal batch",
    )
    rows = load_json(guest / "metrics" / "records.json")
    expected = list(schedule(experiment, slot))
    require(isinstance(rows, list) and len(rows) == len(expected), "Expected exactly 72 ordered observations")
    previous_end = None
    for position, (planned, row) in enumerate(zip(expected, rows), 1):
        check_record(guest, experiment, slot, position, planned, row)
        start = sample_time(row["started_at"])
        end = sample_time(row["finished_at"])
        require(start <= end and (previous_end is None or previous_end <= start),
                f"Wall timestamps contradict sequential execution at sample {position}")
        previous_end = end
    if experiment == "exp-002":
        check_extension(guest, rows)
    result = summarize_batch(experiment, rows)
    summary = load_json(guest / "metrics" / "summary.json")
    require(summary.get("experiment_id") == experiment and summary.get("batch_slot") == slot
            and summary.get("all_benchmarks_valid") is True, "Invalid guest statistics summary")
    for key in ("arithmetic_mean_runtime_ratio", "geometric_mean_runtime_ratio",
                "arithmetic_mean_runtime_ratio_without_mst"):
        compare_statistic(summary.get(key), result[key], key)
    programs = summary.get("benchmarks")
    require(isinstance(programs, list) and [row.get("benchmark") for row in programs] == list(BENCHMARKS),
            "Guest summary benchmark order or inventory differs")
    for row in programs:
        name = row["benchmark"]
        expected_program = result["benchmarks"][name]
        require(row.get("complete") is True
                and row.get("short_run_warning") is expected_program["short_run_warning"],
                f"Guest summary validity or short-run flag differs: {name}")
        compare_statistic(row.get("runtime_ratio"), expected_program["runtime_ratio"], name)
        for arm, expected_arm in expected_program["arms"].items():
            stats = row[arm]
            require(type(stats.get("valid_runs")) is int and stats["valid_runs"] == 5
                    and stats.get("complete") is True and stats.get("warmups_valid") is True,
                    f"Guest summary arm completeness differs: {name}/{arm}")
            compare_statistic(stats.get("mean_seconds"), expected_arm["mean_seconds"], f"{name}/{arm} mean")
            compare_statistic(stats.get("sample_stddev_seconds"), expected_arm["sample_sd_seconds"],
                              f"{name}/{arm} sample SD")
    return result


def sample_time(value):
    require(isinstance(value, str), "Expected an ISO-8601 sample timestamp")
    timestamp = datetime.fromisoformat(value.removesuffix("Z") + ("+00:00" if value.endswith("Z") else ""))
    require(timestamp.utcoffset() is not None, "Sample timestamps must include a timezone")
    return timestamp


def compare_statistic(actual, expected, label):
    require(type(actual) in (int, float) and math.isclose(actual, expected, rel_tol=1e-12),
            f"Guest summary disagrees with raw results: {label}")


def verdict(values, unresolved=False):
    if len(values) != 3 or unresolved:
        return "inconclusive"
    positive = sum(value > 1 for value in values)
    if positive == 3:
        return "supported"
    if positive == 2 and mean(values) > 1:
        return "partially_supported"
    if positive == 0:
        return "not_supported"
    return "inconclusive"


def across_batches(values):
    return {"batch_values": values, "mean": mean(values), "sample_sd": stdev(values), "n": len(values)}


def analyze(experiment, campaign, runs, unresolved_deviations=()):
    require(len(runs) <= 4, "The protocol allows at most four attempts")
    attempts = []
    valid = {}
    bindings = set()
    ids = set()
    conflicts = []
    duplicates = set()
    for run in runs:
        entry = {"run_id": run.name, "included": False}
        attempts.append(entry)
        try:
            inventory = check_seal(run)
            entry["outer_seal_sha256"] = digest(run / "SHA256SUMS.txt")
            manifest = load_json(run / "run-manifest.json")
            require(manifest.get("run_id") == run.name, "Host run ID and directory disagree")
            require(run.name not in ids, "Repeated run ID")
            ids.add(run.name)
            require(manifest.get("experiment_id") == experiment and manifest.get("campaign_id") == campaign,
                    "Run belongs to a different experiment or campaign")
            slot = manifest.get("batch_slot")
            require(type(slot) is int and 0 <= slot < 3, "Invalid host batch slot")
            entry["batch_slot"] = slot
            status = manifest.get("status")
            entry["status"] = status
            if status in OTHER_TERMINAL:
                entry["failure_class"] = manifest.get("failure_class")
                entry["reason"] = manifest.get("error") or manifest.get("reason") or status
                continue
            require(status == "passed_batch", "Unexpected terminal batch status")
            require(manifest.get("vm_id") == run.name, "Passed host batch requires an independent matching VM ID")
            hashes = (manifest.get("plan_sha256"), manifest.get("config_payload_sha256"))
            require(all(is_digest(value) for value in hashes), "Missing frozen plan/config binding")
            bindings.add(hashes)
            if slot in valid or slot in duplicates:
                duplicates.add(slot)
                conflicts.append(f"More than one passed run for slot {slot}")
                continue
            records_file = f"guest-evidence/data/{run.name}/metrics/records.json"
            entry["records_sha256"] = inventory.get(records_file)
            entry["batch"] = load_batch(run, experiment, manifest)
            entry["vm_id"] = manifest["vm_id"]
            entry["counts"] = {"warmups": 12, "measurements": 60, "measured_pairs": 30}
            entry["included"] = True
            valid[slot] = entry
        except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
            entry["reason"] = str(error)
            conflicts.append(f"{run.name}: {error}")
    for slot in duplicates:
        valid.pop(slot)["included"] = False
    if len(bindings) > 1:
        conflicts.append("Failed to establish a single frozen plan and config across batches")
    valid_slots = sorted(valid)
    batch_order = [valid[slot] for slot in valid_slots]
    primary_key = "arithmetic_mean_runtime_ratio"
    flags = list(unresolved_deviations) + conflicts
    result = {
        "experiment_id": experiment,
        "campaign_id": campaign,
        "attempts": attempts,
        "included_batch_slots": valid_slots,
        "missing_valid_batch_slots": sorted(set(range(3)) - valid.keys()),
        "included_counts": {
            "warmups": 12 * len(valid), "measurements": 60 * len(valid), "measured_pairs": 30 * len(valid),
        },
        "unresolved_deviations": flags,
        "verdict": verdict([entry["batch"][primary_key] for entry in batch_order], bool(flags)),
        "aggregate": None,
    }
    if len(bindings) == 1:
        result["plan_sha256"], result["config_payload_sha256"] = next(iter(bindings))
    if len(valid) != 3 or conflicts:
        return result
    aggregate = {}
    for metric in (primary_key, "geometric_mean_runtime_ratio", "arithmetic_mean_runtime_ratio_without_mst"):
        aggregate[metric] = across_batches([entry["batch"][metric] for entry in batch_order])
    aggregate["benchmarks"] = {
        name: across_batches([entry["batch"]["benchmarks"][name]["runtime_ratio"] for entry in batch_order])
        for name in BENCHMARKS
    }
    result["aggregate"] = aggregate
    if experiment == "exp-001":
        paper = 1.73
        difference = aggregate[primary_key]["mean"] - paper
        result["paper_figure_2_descriptive"] = {
            "paper_runtime_ratio": paper,
            "ratio_difference": difference,
            "relative_difference_percent": 100 * difference / paper,
            "overhead_difference_percentage_points": 100 * difference,
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", choices=ARMS, required=True)
    parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--unresolved-deviation", action="append", default=[])
    parser.add_argument("--output", type=Path)
    parser.add_argument("runs", metavar="RUN", type=Path, nargs="*")
    args = parser.parse_args()
    try:
        result = analyze(args.experiment, args.campaign_id, args.runs, args.unresolved_deviation)
        report = json.dumps(result, indent=2, allow_nan=False) + "\n"
        if args.output:
            with args.output.open("x", encoding="utf-8") as stream:
                stream.write(report)
        else:
            print(report, end="")
    except (OSError, ValueError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
