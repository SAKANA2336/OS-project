#!/usr/bin/env python3
"""Check, prepare, or execute a separately authorized native ARM64 exploratory pilot.

check is read-only. No command downloads sources, installs host tools, changes the
old environment active pointer, or authorizes itself. prepare and execute both
require an exact run/config/plan/decision-bound authorization record.
"""
import argparse
import base64
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import re
import selectors
import shutil
import signal
import statistics
import subprocess
import tarfile
import time

GIB = 1024 ** 3
MAX_ARCHIVE = 32 * 1024 ** 2
MAX_EXPANDED = 96 * 1024 ** 2
MAX_CONSOLE = 48 * 1024 ** 2
TERMINAL = {"passed_pilot", "failed", "stopped", "invalid_pilot"}
SOURCE_COMMIT = "72a946a42cbce06afef68b2326ff6c3869d09799"
RAW_SHA = "798ed3718b55590241cd1fd609d028cf50d58df513d832e46733d941f87641b4"
BINARY_SHA = "ac2bedc208267b51d0b47d385ebc9f1c44bd726b70de31bf20eeb1d5093c3376"
NATIVE_SOURCE_SHA = "480656d5ed6dfa1be8b302d85a61624b1f80bbb25416f17f4bff3d59f1bc5af2"
NAMES = {"bisort", "em3d", "mst", "perimeter", "treeadd", "tsp"}

class PilotError(RuntimeError):
    pass

def require(ok, text):
    if not ok:
        raise PilotError(text)

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def bytes_digest(data):
    return hashlib.sha256(data).hexdigest()

def pairs_unique(pairs):
    data = {}
    for key, value in pairs:
        require(key not in data, "Duplicate JSON key: " + key)
        data[key] = value
    return data

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=pairs_unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(PilotError("Non-finite JSON")))

def write_new(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")

def under(root, logical):
    name = PurePosixPath(logical)
    require(not name.is_absolute() and ".." not in name.parts and "\\" not in logical,
            "Unsafe logical path: " + logical)
    target = Path(root).joinpath(*name.parts)
    require(not target.is_symlink() and target.resolve().is_relative_to(Path(root).resolve()),
            "Input escapes declared root: " + logical)
    return target

def config_binding(cfg):
    payload = {k: v for k, v in cfg.items() if k not in {"execution_authorized", "execution_authorization"}}
    return bytes_digest(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode())

def verify_zone(root):
    root = Path(root).resolve()
    require(root.name == "OS-project-local" and (root / ".git").is_dir()
            and not (root / ".git").is_symlink(), "An independent OS-project-local work repository is required")
    require((root / ".local/workspace-role").read_text().strip() == "work", "Work role is required")
    top = subprocess.check_output(["git", "-C", str(root), "rev-parse", "--show-toplevel"], text=True).strip()
    require(Path(top).resolve() == root, "Git root mismatch")
    require(not subprocess.check_output(["git", "-C", str(root), "remote"], text=True).strip(),
            "A work repository with any remote is refused")
    return subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()

def validate_config(cfg):
    host = cfg.get("host_vm", {})
    require(cfg.get("kind") == "exploratory-workload-transfer", "Only the exploratory pilot is supported")
    require(cfg.get("overall_timeout_seconds") == 1200 and cfg.get("warmups") == 1
            and cfg.get("repetitions") == 5, "Expected 1200s / one warmup / five measurements")
    require({b.get("name") for b in cfg.get("benchmarks", [])} == NAMES
            and len(cfg["benchmarks"]) == 6, "The same six Olden workloads are required")
    require(cfg.get("source", {}).get("commit") == SOURCE_COMMIT, "Pinned LLVM source commit differs")
    require(cfg.get("limits", {}).get("cpus") == 2 and cfg["limits"].get("memory") == "2g"
            and cfg["limits"].get("pids") == 128 and cfg["limits"].get("tmpfs") == "768m",
            "Expected guest scope 2 CPU / 2 GiB / 128 tasks / 768 MiB tmpfs")
    for key, value in {"vcpus": 2, "memory_mib": 3072, "disk_max_bytes": 30 * GIB,
                       "timeout_seconds": 1800, "setup_timeout_seconds": 480}.items():
        require(host.get(key) == value, "Host VM bound differs: " + key)
    require(host.get("prepare_timeout_seconds", 300) == 300, "Preparation deadline must remain 300 seconds")
    return host

def authorize(root, cfg, run_id, phase):
    require(cfg.get("execution_authorized") is True, "Execution is not authorized; the gate is closed")
    record = cfg.get("execution_authorization")
    require(isinstance(record, dict), "A real, bound authorization record is required")
    require(record.get("run_id") == run_id and phase in record.get("scope", []),
            "Authorization does not cover this run and phase")
    instruction = record.get("user_instruction")
    require(isinstance(instruction, str) and len(instruction.strip()) >= 8,
            "Record the user's explicit execution instruction")
    stamp = datetime.fromisoformat(str(record.get("recorded_at", "")).replace("Z", "+00:00"))
    require(stamp.tzinfo is not None and stamp <= datetime.now(timezone.utc),
            "Authorization time must be timezone-aware and not in the future")
    plan = under(root, cfg["host_vm"].get("plan", "experiments/pilot-arm64-001/PLAN.md"))
    require(digest(plan) == record.get("plan_sha256"), "Authorization is not bound to the current plan")
    require(config_binding(cfg) == record.get("config_payload_sha256"), "Authorization configuration binding changed")
    decision = under(root, str(record.get("decision_path", "")))
    require(decision.is_file() and digest(decision) == record.get("decision_sha256")
            and instruction in decision.read_text(), "Explicit instruction and matching decision hash are required")
    seconds = record.get("budget", {}).get("activity_seconds")
    require(type(seconds) is int and 1860 <= seconds <= 2400, "An explicitly approved activity budget from 1860 through 2400s is required; larger budgets require a plan revision")
    prior = record.get("budget", {}).get("prior_activity_seconds")
    require(type(prior) is int and 0 <= prior < seconds, "Account for prior source/preparation/failed-attempt activity explicitly")
    return record

def verify_source(source, lock, cfg):
    source = Path(source).resolve()
    require(source.is_dir(), "needs_source: obtain the pinned LLVM checkout with local Git CLI first")
    require(lock.get("commit") == cfg["source"]["commit"] and len(lock.get("files", [])) == 222,
            "Expected exact 222-file LLVM lock")
    revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True, timeout=15).strip()
    require(revision == lock["commit"], "Source checkout Git HEAD differs from lock")
    seen = set()
    for item in lock["files"]:
        logical = item["path"]
        require(logical not in seen, "Duplicate source lock path")
        seen.add(logical)
        f = under(source, logical)
        require(f.is_file() and f.stat().st_size == item["bytes"] and digest(f) == item["sha256"],
                "Source input missing/changed: " + logical)
    for directory in cfg["source"]["sparse_directories"]:
        actual = {x.relative_to(source).as_posix() for x in under(source, directory).rglob("*") if x.is_file()}
        require(actual == {n for n in seen if n.startswith(directory + "/")}, "Extra benchmark source files")
    return {"git_commit": revision, "locked_files_verified": len(seen)}

def verify_assets(root):
    assets = read_json(root / "experiments/env-arm64-001/SOURCES.json")["assets"]
    receipt = {}
    for item in assets:
        f = under(root, item["logical_path"])
        require(f.is_file() and f.stat().st_size == item["bytes"] and digest(f) == item["sha256"],
                "Existing Ubuntu asset changed/missing: " + item["asset_id"])
        receipt[item["asset_id"]] = {"sha256": item["sha256"], "observed_mode": oct(f.stat().st_mode & 0o777),
                                          "use": "read-only access; not remounted or chmodded"}
    asset = root / ".local/arm64-vm/assets/ubuntu-noble-20261017"
    raw = asset / "extracted/noble-server-cloudimg-arm64.img"
    require(raw.is_file() and not raw.is_symlink() and raw.stat().st_mode & 0o222 == 0
            and digest(raw) == RAW_SHA, "Read-only extracted raw disk missing/changed")
    binary = root / ".local/arm64-vm/bin/run-arm64-vm"
    require(digest(binary) == BINARY_SHA and digest(root / "scripts/run-arm64-vm.m") == NATIVE_SOURCE_SHA,
            "Previously signed native launcher/source changed; require separately recorded rebuild")
    subprocess.run(["codesign", "--verify", "--strict", str(binary)], check=True, capture_output=True, timeout=15)
    receipt.update(raw_disk_sha256=RAW_SHA, signed_binary_sha256=BINARY_SHA)
    return asset, raw, binary, receipt

def host_resources(root):
    require(platform.system() == "Darwin" and platform.machine() == "arm64", "Native Apple Silicon macOS is required")
    pressure = subprocess.check_output(["sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True, timeout=10).strip()
    require(pressure == "1", "Host memory pressure must be normal (raw level 1)")
    free = shutil.disk_usage(root).free
    require(free >= 20 * GIB, "Host free disk is below 20 GiB")
    return {"host_system": platform.platform(), "architecture": platform.machine(),
            "memory_pressure_raw": int(pressure), "free_disk_bytes": free}

def preflight(root, cfg, source):
    commit = verify_zone(root)
    validate_config(cfg)
    resources = host_resources(root)
    lock_path = root / "workloads/llvm-suite-lock.json"
    lock = read_json(lock_path)
    source_receipt = verify_source(source, lock, cfg)
    asset, raw, binary, assets = verify_assets(root)
    return commit, resources, lock, source_receipt, asset, raw, binary, assets

def seal(run, manifest, status, error=None):
    manifest.update(status=status, finished_at=utc_now())
    if error:
        manifest["error"] = type(error).__name__ + ": " + str(error)
    path = run / "run-manifest.json"
    if path.exists():
        require(read_json(path).get("status") not in TERMINAL, "A terminal run is immutable")
        temporary = run / ".manifest.tmp"
        write_new(temporary, manifest)
        os.replace(temporary, path)
    else:
        write_new(path, manifest)
    files = [x for x in run.rglob("*") if x.is_file() and x.name != "SHA256SUMS.txt"]
    with (run / "SHA256SUMS.txt").open("x") as handle:
        handle.writelines(digest(x) + "  " + x.relative_to(run).as_posix() + "\n" for x in sorted(files))

def payload(root, config_path, source, lock):
    files = {"project/scripts/llvm-asan.py": root / "scripts/llvm-asan.py",
             "project/config/llvm-asan-arm64.json": config_path,
             "project/workloads/llvm-suite-lock.json": root / "workloads/llvm-suite-lock.json"}
    files.update({"suite/" + item["path"]: under(source, item["path"]) for item in lock["files"]})
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as archive:
        for logical, original in sorted(files.items()):
            data = original.read_bytes()
            info = tarfile.TarInfo(logical)
            info.size = len(data); info.mode = 0o644; info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    require(len(buf.getvalue()) < 24 * 1024 ** 2, "Input payload exceeds bounded seed allowance")
    return buf.getvalue(), {name: digest(f) for name, f in files.items()}

def guest_setup(run_id, commit, vm_id, epoch, input_sha):
    # All substituted identifiers are strict validated IDs/hashes, never arbitrary shell text.
    return r'''#!/bin/bash
set -u
export LC_ALL=C DEBIAN_FRONTEND=noninteractive
e=/var/log/arm64-pilot-evidence
mkdir -p "$e/setup" "$e/data"
exec > >(tee -a "$e/setup/setup.log" /dev/hvc0) 2>&1
finish() {
 rc=$?; trap - EXIT
 printf '%s\n' "$rc" > "$e/setup/setup-exit-code.txt"
 date -u +%FT%TZ > "$e/setup/finished-at.txt"
 du -sx -B1 "$e" > "$e/setup/evidence-size.txt"
 if [ "$(du -sx -B1 "$e" | cut -f1)" -le 100663296 ]; then
  tar -C "$e" -czf /tmp/pilot-evidence.tar.gz .
  if [ "$(stat -c%s /tmp/pilot-evidence.tar.gz)" -le 33554432 ]; then
   printf '\nPILOT_EVIDENCE_SHA256 %s\n' "$(sha256sum /tmp/pilot-evidence.tar.gz | cut -d' ' -f1)" > /dev/hvc0
   printf '\nPILOT_EVIDENCE_BEGIN\n' > /dev/hvc0
   base64 /tmp/pilot-evidence.tar.gz > /dev/hvc0
   printf '\nPILOT_EVIDENCE_END\n' > /dev/hvc0
  fi
 fi
 sync; /sbin/poweroff
}
trap finish EXIT
date -u +%FT%TZ > "$e/setup/clock-before.txt"
date -u -s '@EPOCH' > "$e/setup/clock-after.txt" || exit 19
uname -a > "$e/setup/uname.txt"
cp /etc/os-release "$e/setup/os-release.txt"
systemctl stop ssh.service ssh.socket 2>/dev/null || true
printf '%s  %s\n' 'INPUT_SHA' /opt/pilot-inputs.tar.gz | sha256sum -c - || exit 22
mkdir -p /opt/pilot /project /suite /evidence
tar -xzf /opt/pilot-inputs.tar.gz -C /opt/pilot --no-same-owner || exit 23
ip -json address > "$e/setup/network-before.json"
for n in /sys/class/net/*/statistics/rx_bytes; do printf '%s ' "$n"; cat "$n"; done > "$e/setup/network-rx-before.txt"
timeout -k 10s 480s bash -c 'timeout -k 5s 120s apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=30 update && timeout -k 5s 360s apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=30 install -y --no-install-recommends clang-18 llvm-18 libclang-rt-18-dev libc6-dev libstdc++-13-dev python3 make cmake ninja-build util-linux' > "$e/setup/apt.log" 2>&1 || exit 24
dpkg-query -W '-f=${binary:Package}\t${Version}\n' > "$e/setup/packages.txt"
for n in /sys/class/net/*/statistics/rx_bytes; do printf '%s ' "$n"; cat "$n"; done > "$e/setup/network-rx-after.txt"
for net in /sys/class/net/*; do d=$(basename "$net"); if [ "$d" != lo ]; then ip link set "$d" down; fi; done
ip -json address > "$e/setup/network-offline.json"
readlink /proc/self/ns/net > /run/llvm-asan-parent-netns
chmod 0444 /run/llvm-asan-parent-netns
useradd --create-home --shell /bin/bash pilotcheck 2>/dev/null || true
chown pilotcheck:pilotcheck "$e/data"
systemd-run --unit=arm64-pilot --wait --pipe --collect \
 --property=User=pilotcheck --property=CPUQuota=200% --property=MemoryMax=2G \
 --property=MemorySwapMax=0 --property=TasksMax=128 --property=LimitCORE=0 \
 --property=RuntimeMaxSec=1230 --property=PrivateNetwork=yes --property=NoNewPrivileges=yes \
 --property=CapabilityBoundingSet= --property=ProtectSystem=strict --property=ProtectHome=yes \
 --property=PrivateDevices=yes --property=ReadWritePaths=/evidence \
 --property=BindPaths="$e/data:/evidence" \
 --property=BindReadOnlyPaths='/opt/pilot/project:/project /opt/pilot/suite:/suite' \
 --property=TemporaryFileSystem='/tmp:rw,exec,nosuid,nodev,size=768M,mode=1777' \
 python3 /project/scripts/llvm-asan.py run --profile systemd-vm \
 --config /project/config/llvm-asan-arm64.json --source /suite \
 --parent-network-namespace-file /run/llvm-asan-parent-netns \
 --output /evidence/RUN_ID --run-id RUN_ID --project-commit PROJECT_COMMIT --vm-id VM_ID \
 > "$e/setup/pilot-command.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$e/setup/pilot-exit-code.txt"
exit "$rc"
'''.replace("EPOCH", str(epoch)).replace("INPUT_SHA", input_sha).replace("RUN_ID", run_id).replace("PROJECT_COMMIT", commit).replace("VM_ID", vm_id)

def prepare(root, config_path, cfg, source, run_id):
    entry_time = utc_now()
    auth = authorize(root, cfg, run_id, "prepare")
    commit, resources, lock, sources, asset, original, binary, assets = preflight(root, cfg, source)
    run = root / "runs" / run_id
    instance = root / ".local/arm64-pilot/instances" / run_id
    require(not run.exists() and not instance.exists(), "Create-only run or VM instance already exists")
    run.mkdir(); manifest = {"run_id": run_id, "vm_id": run_id, "kind": cfg["kind"], "status": "preparing",
                             "paper_claim_verdict": "inconclusive", "prepared_at": utc_now(),
                             "activity_budget_started_at": entry_time, "base_commit": commit,
                             "config_sha256": digest(config_path), "config_payload_sha256": config_binding(cfg),
                             "plan_sha256": auth["plan_sha256"], "source": sources}
    write_new(run / "run-manifest.json", manifest)
    try:
        instance.mkdir(parents=True)
        write_new(run / "provenance/host-preflight.json", resources)
        write_new(run / "provenance/input-assets.json", assets)
        for logical in ["scripts/run-arm64-pilot.py", "scripts/llvm-asan.py", "scripts/run-arm64-vm.m",
                        "workloads/llvm-suite-lock.json", cfg["host_vm"].get("plan", "experiments/pilot-arm64-001/PLAN.md"),
                        "docs/PROTOCOL.md", config_path.relative_to(root).as_posix()]:
            f = under(root, logical); target = run / "provenance/source" / logical
            target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(f.read_bytes())
        patch = subprocess.check_output(["git", "-C", str(root), "diff", "--binary", "HEAD", "--",
                                         "scripts/", "config/", "experiments/pilot-arm64-001/", "workloads/"])
        (run / "provenance/worktree.patch").write_bytes(patch)
        packed, hashes = payload(root, config_path, source, lock)
        write_new(run / "provenance/seed-inputs.json", hashes)
        disk = instance / "root.raw"
        subprocess.run(["cp", "-c", str(original), str(disk)], check=True, timeout=120)
        disk.chmod(0o600)
        with disk.open("r+b") as handle:
            handle.truncate(30 * GIB)
        original_kernel = asset / "boot/noble-server-cloudimg-arm64-vmlinuz-generic"
        kbytes = original_kernel.read_bytes()
        kernel = instance / "Image"; kernel.write_bytes(gzip.decompress(kbytes) if kbytes[:2] == b"\x1f\x8b" else kbytes)
        initrd = asset / "boot/noble-server-cloudimg-arm64-initrd-generic"
        epoch = int(time.time())
        setup = guest_setup(run_id, commit, run_id, epoch, bytes_digest(packed))
        (run / "config").mkdir(); (run / "config/guest-setup.sh").write_text(setup)
        cloud = {"hostname": "arm64-pilot", "ssh_pwauth": False, "disable_root": True,
                 "ssh_genkeytypes": [], "users": [{"name": "pilotcheck", "lock_passwd": True}],
                 "write_files": [{"path": "/opt/pilot-inputs.tar.gz", "encoding": "b64", "permissions": "0644", "content": base64.b64encode(packed).decode()},
                                 {"path": "/opt/pilot-setup.sh", "encoding": "b64", "permissions": "0755", "content": base64.b64encode(setup.encode()).decode()}],
                 "runcmd": [["bash", "/opt/pilot-setup.sh"]]}
        seed_files = instance / "seed-files"; seed_files.mkdir()
        (seed_files / "user-data").write_text("#cloud-config\n" + json.dumps(cloud) + "\n")
        (seed_files / "meta-data").write_text(json.dumps({"instance-id": run_id, "local-hostname": "arm64-pilot"}) + "\n")
        seed = instance / "seed.iso"
        subprocess.run(["hdiutil", "makehybrid", "-iso", "-joliet", "-default-volume-name", "cidata",
                        "-o", str(seed), str(seed_files)], check=True, capture_output=True, timeout=45)
        paths = {"disk": str(disk), "seed": str(seed), "kernel": str(kernel), "initrd": str(initrd), "binary": str(binary)}
        write_new(instance / "local-paths.json", paths)
        boot = {"run_id": run_id, "vcpus": 2, "memory_mib": 3072, "disk_max_bytes": disk.stat().st_size,
                "host_timeout_seconds": 1800, "host_directory_shares": [], "host_port_forwards": [],
                "host_seed_epoch": epoch, "payload_sha256": bytes_digest(packed),
                "files_sha256": {n: digest(f) for n, f in paths.items()},
                "guest_setup_sha256": bytes_digest(setup.encode()), "asset_receipt": assets}
        write_new(run / "config/boot-inputs.json", boot)
        manifest.update(status="ready", boot_inputs_sha256=digest(run / "config/boot-inputs.json"))
        temp = run / ".ready.tmp"; write_new(temp, manifest); os.replace(temp, run / "run-manifest.json")
        return {"run_id": run_id, "status": "ready", "vm_started": False}
    except (Exception, KeyboardInterrupt) as error:
        seal(run, manifest, "failed", error)
        raise

def bounded_prepare(root, config_path, cfg, source, run_id):
    def expired(_sig, _frame):
        raise TimeoutError("Preparation exceeded the proposed 300-second bound")
    previous = signal.signal(signal.SIGALRM, expired)
    signal.alarm(300)
    try:
        return prepare(root, config_path, cfg, source, run_id)
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous)

def parse_frame(console):
    require(len(console) <= MAX_CONSOLE, "Console capture exceeds bound")
    raw = console.replace(b"\r", b"")
    for marker in [rb"^PILOT_EVIDENCE_SHA256 [a-f0-9]{64}$", rb"^PILOT_EVIDENCE_BEGIN$", rb"^PILOT_EVIDENCE_END$"]:
        require(len(re.findall(marker, raw, re.M)) == 1, "Missing/duplicate serial evidence frame")
    match = re.search(rb"^PILOT_EVIDENCE_SHA256 ([a-f0-9]{64})\n\s*PILOT_EVIDENCE_BEGIN\n([A-Za-z0-9+/=\n]+)\nPILOT_EVIDENCE_END(?:\n|$)", raw, re.M)
    require(match is not None, "Malformed evidence frame")
    packed = base64.b64decode(re.sub(rb"\s+", b"", match[2]), validate=True)
    require(len(packed) <= MAX_ARCHIVE and bytes_digest(packed) == match[1].decode(), "Evidence archive SHA/bound mismatch")
    return packed

def extract_safe(packed, destination):
    require(len(packed) <= MAX_ARCHIVE, "Compressed evidence bound exceeded")
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as compressed:
        expanded = compressed.read(MAX_EXPANDED + 1)
    require(len(expanded) <= MAX_EXPANDED, "Expanded tar stream exceeds bound")
    with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as archive:
        members = archive.getmembers()
        require(len(members) <= 4096 and sum(x.size for x in members) <= MAX_EXPANDED, "Expanded evidence exceeds bound")
        seen = set()
        for item in members:
            name = PurePosixPath(item.name)
            require(not name.is_absolute() and ".." not in name.parts and "\\" not in item.name
                    and (item.isfile() or item.isdir()), "Unsafe evidence member")
            normalized = name.as_posix()
            require(normalized not in seen, "Duplicate archive member")
            seen.add(normalized)
        destination.mkdir(exist_ok=False)
        for item in members:
            path = destination.joinpath(*PurePosixPath(item.name).parts)
            if item.isdir(): path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as target: target.write(archive.extractfile(item).read())

def validate_records(records, cfg):
    expected = {(b["name"], a, phase, i) for b in cfg["benchmarks"] for a in ("baseline", "asan")
                for phase, count in (("warmup", 1), ("measure", 5)) for i in range(1, count + 1)}
    require(isinstance(records, list) and len(records) == 72, "Exactly 72 original records required")
    seen = set()
    for row in records:
        key = (row.get("benchmark"), row.get("arm"), row.get("phase"), row.get("iteration"))
        require(key in expected and key not in seen, "Missing/duplicate/unexpected sample identity")
        seen.add(key)
        require(row.get("valid") is True and row.get("reference_match") is True and row.get("timed_out") is False
                and type(row.get("iteration")) is int and type(row.get("exit_code")) is int
                and row.get("exit_code") == 0 and row.get("program_exit_code") == 0
                and row.get("sanitizer_report") is False,
                "Invalid sample or unverified reference output")
        value = row.get("real_seconds")
        require(type(value) in (float, int) and math.isfinite(value) and value > 0, "Invalid sample time")
    require(seen == expected, "Incomplete sample matrix")
    return len(seen)

def validate_statistics(records, summary):
    rows = summary.get("benchmarks", [])
    require(len(rows) == 6 and {r.get("benchmark") for r in rows} == NAMES, "Summary benchmark set differs")
    ratios = []
    for row in rows:
        means = {}
        for arm in ("baseline", "asan"):
            values = [r["real_seconds"] for r in records if r["benchmark"] == row["benchmark"]
                      and r["arm"] == arm and r["phase"] == "measure"]
            group = row[arm]; mean = statistics.mean(values); sd = statistics.stdev(values)
            require(group.get("complete") is True and group.get("valid_runs") == 5
                    and math.isclose(mean, group["mean_seconds"], rel_tol=1e-10)
                    and math.isclose(sd, group["sample_stddev_seconds"], rel_tol=1e-10, abs_tol=1e-12),
                    "Summary mean/sample standard deviation differs from raw records")
            means[arm] = mean
        ratio = means["asan"] / means["baseline"]; ratios.append(ratio)
        require(math.isclose(ratio, row["runtime_ratio"], rel_tol=1e-10), "Summary ratio differs")
    require(math.isclose(math.exp(statistics.mean(map(math.log, ratios))),
                         summary["geometric_mean_runtime_ratio"], rel_tol=1e-10), "Geometric mean differs")

def verify_guest(guest, run_id, cfg, commit, host_rc, lifecycle):
    require(host_rc == 0, "Host launcher failed/stopped")
    events = []
    for line in lifecycle.decode(errors="replace").splitlines():
        try: events.append(json.loads(line))
        except json.JSONDecodeError: pass
    require(any(e.get("event") == "host_finished" and e.get("reason") == "guest_powered_off"
                and e.get("exit_code") == 0 for e in events), "No verified normal guest poweroff")
    require((guest / "setup/setup-exit-code.txt").read_text().strip() == "0"
            and (guest / "setup/pilot-exit-code.txt").read_text().strip() == "0", "Guest setup or pilot failed")
    result = guest / "data" / run_id
    m = read_json(result / "run-manifest.json")
    require(m.get("status") == "passed_pilot" and m.get("kind") == cfg["kind"]
            and m.get("paper_claim_verdict") == "inconclusive", "Guest is not an explicit exploratory pass")
    require(m.get("run_id") == run_id and m.get("vm_id") == run_id and m.get("project_commit") == commit
            and m.get("profile") == "systemd-vm",
            "Guest run/VM/source identity mismatch")
    expected_runner = digest(guest.parent / "provenance/source/scripts/llvm-asan.py")
    require(m.get("runner_sha256") == expected_runner, "Guest runner differs from the prepared source snapshot")
    require(digest(result / "config/effective.json") == bytes_digest((json.dumps(cfg, indent=2, ensure_ascii=True) + "\n").encode()),
            "Guest effective configuration differs")
    records = read_json(result / "metrics/records.json")
    count = validate_records(records, cfg)
    for row in records:
        label = f'{row["benchmark"]}-{row["phase"]}-{row["iteration"]:02}-{row["arm"]}'
        raw = (result / "raw-outputs" / (label + ".output.txt")).read_bytes()
        require(bytes_digest(raw) == row.get("output_sha256") and b"AddressSanitizer" not in raw, "Raw output hash mismatch or sanitizer report")
        normalized_output = result / "validation/normalized-output" / (label + ".txt")
        normalized_reference = result / "validation/normalized-reference" / (row["benchmark"] + ".txt")
        require(normalized_output.read_bytes() == raw.replace(b"\r\n", b"\n")
                and digest(normalized_output) == row.get("normalized_output_sha256")
                and digest(normalized_reference) == row.get("normalized_reference_sha256"), "Normalized output/reference bytes or hashes differ")
        verification = read_json(result / "validation" / (label + ".command.json"))
        argv = verification.get("argv", [])
        prefix = "/evidence/" + run_id + "/validation/"
        require(len(argv) == 3 and PurePosixPath(argv[0]).name == "fpcmp"
                and argv[1] == prefix + "normalized-output/" + label + ".txt"
                and argv[2] == prefix + "normalized-reference/" + row["benchmark"] + ".txt"
                and verification.get("exit_code") == 0 and verification.get("timed_out") is False
                and verification.get("timeout_seconds") == 10, "Reference comparison command did not pass the original fpcmp criterion")
        timings = dict(line.split() for line in (result / "raw-outputs" / (label + ".time.txt")).read_text().splitlines())
        require(int(timings["exit"]) == 0 and all(float(timings[key]) == row[key + "_seconds"]
                for key in ("real", "user", "sys")), "Raw timer/record mismatch")
    summary = read_json(result / "metrics/summary.json")
    require(summary.get("all_benchmarks_valid") is True and summary.get("formal_claim_verdict") == "inconclusive",
            "Guest summary does not report complete exploratory evidence")
    validate_statistics(records, summary)
    # The finalized guest inventory must cover every evidence file.
    inventory = result / "SHA256SUMS.txt"
    require(inventory.is_file(), "Guest finalized hash inventory is missing")
    listed = set()
    for line in inventory.read_text().splitlines():
        value, logical = line.split("  ", 1)
        require(logical not in listed and re.fullmatch(r"[0-9a-f]{64}", value), "Invalid guest hash inventory")
        listed.add(logical); require(digest(under(result, logical)) == value, "Guest file checksum mismatch")
    actual = {f.relative_to(result).as_posix() for f in result.rglob("*") if f.is_file() and f != inventory}
    require(listed == actual, "Guest hash inventory is incomplete")
    return {"status": "passed_pilot", "records_checked": count, "guest_files_checked": len(listed),
            "paper_claim_verdict": "inconclusive", "scope": "ARM64 exploratory method-transfer only"}

def capture(argv, out, err, timeout):
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ, out)
    selector.register(process.stderr, selectors.EVENT_READ, err)
    sizes = {out: 0, err: 0}; deadline = time.monotonic() + timeout + 80
    try:
        while selector.get_map():
            require(time.monotonic() < deadline, "Host VM finalization watchdog expired")
            for key, _ in selector.select(0.5):
                block = os.read(key.fileobj.fileno(), 65536)
                if not block: selector.unregister(key.fileobj); key.fileobj.close(); continue
                target = key.data; sizes[target] += len(block)
                require(sizes[target] <= (MAX_CONSOLE if target is out else 4 * 1024 ** 2), "Host capture bound exceeded")
                target.write(block); target.flush()
        return process.wait(timeout=5)
    finally:
        selector.close()
        if process.poll() is None:
            process.terminate()
            try: process.wait(timeout=45)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)

def execute(root, config_path, cfg, run_id):
    auth = authorize(root, cfg, run_id, "execute")
    verify_zone(root); host_resources(root)
    run = root / "runs" / run_id; instance = root / ".local/arm64-pilot/instances" / run_id
    manifest = read_json(run / "run-manifest.json")
    require(manifest.get("status") == "ready", "Only a new ready run may execute; terminal runs are immutable")
    with (instance / ".execute.lock").open("x") as lock: lock.write(str(os.getpid()) + "\n")
    try:
        require(digest(config_path) == manifest["config_sha256"], "Config changed since preparation")
        started = datetime.fromisoformat(manifest["activity_budget_started_at"])
        remaining = auth["budget"]["activity_seconds"] - auth["budget"]["prior_activity_seconds"] - (datetime.now(timezone.utc) - started).total_seconds()
        require(remaining >= 1860, "Approved activity budget lacks VM and shutdown headroom")
        boot = read_json(run / "config/boot-inputs.json")
        require(digest(run / "config/boot-inputs.json") == manifest["boot_inputs_sha256"], "Boot configuration changed")
        require(0 <= time.time() - boot["host_seed_epoch"] <= 300, "Seed UTC is stale; create a separately budgeted new attempt")
        paths = read_json(instance / "local-paths.json")
        for n, f in paths.items(): require(digest(f) == boot["files_sha256"][n], "Prepared boot input changed: " + n)
        argv = [paths["binary"], "--disk", paths["disk"], "--seed", paths["seed"], "--kernel", paths["kernel"],
                "--initrd", paths["initrd"], "--network", "nat", "--timeout", "1800"]
        manifest.update(status="running", started_at=utc_now())
        temp = run / ".running.tmp"; write_new(temp, manifest); os.replace(temp, run / "run-manifest.json")
        (run / "logs").mkdir()
        write_new(run / "config/host-launch.json", {"argv_logical": ["signed-native-launcher", "--timeout", "1800"],
                                                     "binary_sha256": BINARY_SHA, "boot_sha256": manifest["boot_inputs_sha256"]})
        with (run / "logs/console.log").open("xb") as out, (instance / "lifecycle.raw.log").open("xb") as err:
            rc = capture(argv, out, err, 1800)
        lifecycle = (instance / "lifecycle.raw.log").read_bytes()
        (run / "logs/lifecycle.log").write_text(lifecycle.decode(errors="replace").replace(str(root), "<work-zone>"))
        packed = parse_frame((run / "logs/console.log").read_bytes())
        (instance / "guest-evidence.tar.gz").write_bytes(packed)
        extract_safe(packed, run / "guest-evidence")
        audit = verify_guest(run / "guest-evidence", run_id, cfg, manifest["base_commit"], rc,
                             lifecycle)
        manifest.update(host_exit_code=rc, archive_sha256=bytes_digest(packed), receiver_audit=audit,
                        raw_host_log_sha256=bytes_digest(lifecycle),
                        raw_host_log_logical_path=".local/arm64-pilot/instances/" + run_id + "/lifecycle.raw.log")
        seal(run, manifest, "passed_pilot")
        return {"run_id": run_id, "status": "passed_pilot", "paper_claim_verdict": "inconclusive"}
    except (Exception, KeyboardInterrupt) as error:
        raw_log = instance / "lifecycle.raw.log"
        if raw_log.is_file():
            manifest["raw_host_log_sha256"] = digest(raw_log)
            manifest["raw_host_log_logical_path"] = ".local/arm64-pilot/instances/" + run_id + "/lifecycle.raw.log"
            public = run / "logs/lifecycle.log"
            if not public.exists():
                public.write_text(raw_log.read_text(errors="replace").replace(str(root), "<work-zone>"))
        seal(run, manifest, "failed", error)
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=Path("config/llvm-asan-arm64.json"))
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("command", choices=["check", "prepare", "execute"])
    args = parser.parse_args(); root = args.root.resolve()
    require(re.fullmatch(r"run-[a-z0-9-]+-pilot-arm64-001-a[0-9]{2}", args.run_id), "Invalid unique pilot run ID")
    config = args.config.resolve() if args.config.is_absolute() else under(root, args.config.as_posix())
    require(config.is_relative_to(root), "Configuration must be in the work repository")
    cfg = read_json(config)
    def stop(_sig, _frame): raise KeyboardInterrupt("Signal received; stopping this task VM")
    signal.signal(signal.SIGTERM, stop)
    try:
        if args.command == "check":
            report = {"read_only": True, "execution_authorized": cfg.get("execution_authorized") is True,
                      "config_payload_sha256": config_binding(cfg), "vm_started": False}
            try:
                _, resources, _, sources, _, _, _, assets = preflight(root, cfg, args.source)
                report.update(status="ready_static", resources=resources, source=sources, assets=assets)
            except Exception as error:
                report.update(status="needs_source" if "needs_source" in str(error) else "blocked",
                              reason=type(error).__name__ + ": " + str(error))
            plan = under(root, cfg.get("host_vm", {}).get("plan", "experiments/pilot-arm64-001/PLAN.md"))
            if plan.is_file(): report["plan_sha256"] = digest(plan)
            print(json.dumps(report, sort_keys=True)); return 0 if report["status"] == "ready_static" else 2
        result = bounded_prepare(root, config, cfg, args.source.resolve(), args.run_id) if args.command == "prepare" else execute(root, config, cfg, args.run_id)
        print(json.dumps(result, sort_keys=True)); return 0
    except (Exception, KeyboardInterrupt) as error:
        print(json.dumps({"status": "blocked_or_failed", "error": type(error).__name__ + ": " + str(error), "vm_started": False if args.command == "prepare" else "inspect_run"})); return 1

if __name__ == "__main__":
    raise SystemExit(main())
