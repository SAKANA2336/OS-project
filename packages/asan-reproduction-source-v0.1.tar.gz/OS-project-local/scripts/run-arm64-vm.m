// Native ARM64 Linux VM launcher; stdout is guest hvc0, stderr is host JSON.
#import <Foundation/Foundation.h>
#import <Virtualization/Virtualization.h>
#include <sys/file.h>
#include <sys/mount.h>
#include <sys/sysctl.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <dispatch/dispatch.h>

static const uint64_t VM_MEMORY = 3ULL * 1024 * 1024 * 1024;
static const uint64_t MAX_DISK = 30ULL * 1024 * 1024 * 1024;
static const uint64_t FREE_FLOOR = 20ULL * 1024 * 1024 * 1024;
static NSString *const KERNEL_ARGS = @"console=hvc0 root=LABEL=cloudimg-rootfs rw rootwait panic=0";

static void Event(NSString *name, NSDictionary *fields) {
    NSMutableDictionary *payload = [NSMutableDictionary dictionaryWithDictionary:fields ?: @{}];
    payload[@"event"] = name;
    payload[@"at"] = [[NSISO8601DateFormatter new] stringFromDate:[NSDate date]];
    NSData *json = [NSJSONSerialization dataWithJSONObject:payload options:NSJSONWritingSortedKeys error:nil];
    if (json) { fwrite(json.bytes, 1, json.length, stderr); fputc('\n', stderr); fflush(stderr); }
}
static void Fail(NSString *message) { Event(@"host_preflight_failed", @{@"error":message}); exit(2); }
static NSURL *FileURL(NSString *path, NSString *label) {
    if (!path) Fail([@"Missing option: " stringByAppendingString:label]);
    NSURL *url = [[[NSURL fileURLWithPath:path] standardizedURL] URLByResolvingSymlinksInPath];
    NSNumber *regular = nil;
    NSError *error = nil;
    if (![url getResourceValue:&regular forKey:NSURLIsRegularFileKey error:&error] || !regular.boolValue || ![[NSFileManager defaultManager] isReadableFileAtPath:url.path]) {
        Fail([label stringByAppendingString:@" must be a readable regular file"]);
    }
    return url;
}
static uint64_t FileSize(NSURL *url) {
    return [[[NSFileManager defaultManager] attributesOfItemAtPath:url.path error:nil][NSFileSize] unsignedLongLongValue];
}
static uint64_t FreeSpace(NSURL *disk) {
    struct statfs status;
    if (statfs(disk.URLByDeletingLastPathComponent.fileSystemRepresentation, &status) != 0) return 0;
    return (uint64_t)status.f_bavail * status.f_bsize;
}

@interface VMController : NSObject <VZVirtualMachineDelegate>
@property(nonatomic,strong) VZVirtualMachine *machine;
@property(nonatomic,strong) NSURL *disk;
@property(nonatomic,strong) NSMutableArray *signalSources;
@property(nonatomic,strong) dispatch_source_t deadline;
@property(nonatomic,strong) dispatch_source_t monitor;
@property(nonatomic,strong) dispatch_source_t pressure;
@property(nonatomic,strong) dispatch_source_t stopDeadline;
@property(nonatomic,strong) dispatch_source_t finalDeadline;
@property(nonatomic) BOOL stopping;
@property(nonatomic) BOOL finished;
@property(nonatomic) int exitCode;
@property(nonatomic) int lockFD;
- (void)requestShutdown:(NSString *)reason exitCode:(int)code grace:(int)grace;
- (void)finish:(int)code reason:(NSString *)reason error:(NSError *)error;
@end

@implementation VMController
- (void)finish:(int)code reason:(NSString *)reason error:(NSError *)error {
    if (self.finished) return;
    self.finished = YES;
    NSMutableDictionary *fields = [@{@"reason":reason, @"exit_code":@(code), @"asan_acceptance_decided_by_host":@NO} mutableCopy];
    if (error) fields[@"error"] = error.localizedDescription;
    Event(@"host_finished", fields);
    if (self.lockFD >= 0) { flock(self.lockFD, LOCK_UN); close(self.lockFD); self.lockFD = -1; }
    exit(code);
}
- (void)tryGuestStop {
    if (self.machine.canRequestStop) {
        NSError *error = nil;
        if ([self.machine requestStopWithError:&error]) Event(@"guest_shutdown_requested", nil);
        else Event(@"guest_shutdown_request_failed", @{@"error":error.localizedDescription ?: @"unknown"});
    } else Event(@"guest_shutdown_request_unavailable", @{@"vm_state":@(self.machine.state)});
}
- (void)forceStop {
    if (self.finished) return;
    Event(@"force_stop_requested", @{@"vm_state":@(self.machine.state), @"disk_requires_review_before_reuse":@YES});
    __weak VMController *weakSelf = self;
    self.finalDeadline = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.finalDeadline, dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC), DISPATCH_TIME_FOREVER, 0);
    dispatch_source_set_event_handler(self.finalDeadline, ^{ VMController *s = weakSelf; if (s) [s finish:s.exitCode reason:@"host_exit_after_stop_deadline" error:nil]; });
    dispatch_resume(self.finalDeadline);
    if (self.machine.canStop) {
        [self.machine stopWithCompletionHandler:^(NSError *error) { VMController *s = weakSelf; if (s) [s finish:s.exitCode reason:error ? @"force_stop_failed" : @"force_stopped" error:error]; }];
    } else if (self.machine.state == VZVirtualMachineStateStopped || self.machine.state == VZVirtualMachineStateError) {
        [self finish:self.exitCode reason:@"already_stopped" error:nil];
    }
}
- (void)requestShutdown:(NSString *)reason exitCode:(int)code grace:(int)grace {
    if (self.stopping || self.finished) return;
    self.stopping = YES; self.exitCode = code;
    Event(@"shutdown_triggered", @{@"reason":reason, @"grace_seconds":@(grace)});
    [self tryGuestStop];
    __weak VMController *weakSelf = self;
    self.stopDeadline = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.stopDeadline, dispatch_time(DISPATCH_TIME_NOW, grace * NSEC_PER_SEC), DISPATCH_TIME_FOREVER, 0);
    dispatch_source_set_event_handler(self.stopDeadline, ^{ [weakSelf forceStop]; });
    dispatch_resume(self.stopDeadline);
}
- (void)guestDidStopVirtualMachine:(VZVirtualMachine *)virtualMachine { [self finish:self.exitCode reason:@"guest_powered_off" error:nil]; }
- (void)virtualMachine:(VZVirtualMachine *)virtualMachine didStopWithError:(NSError *)error { [self finish:1 reason:@"virtual_machine_error" error:error]; }
- (void)virtualMachine:(VZVirtualMachine *)virtualMachine networkDevice:(VZNetworkDevice *)networkDevice attachmentWasDisconnectedWithError:(NSError *)error {
    Event(@"network_attachment_disconnected", @{@"error":error.localizedDescription ?: @"unknown"});
    [self requestShutdown:@"network_attachment_failure" exitCode:1 grace:10];
}
- (void)runWithTimeout:(int)timeout {
    __weak VMController *weakSelf = self;
    self.signalSources = [NSMutableArray array];
    for (NSNumber *number in @[@(SIGINT), @(SIGTERM)]) {
        int signum = number.intValue;
        signal(signum, SIG_IGN);
        dispatch_source_t source = dispatch_source_create(DISPATCH_SOURCE_TYPE_SIGNAL, signum, 0, dispatch_get_main_queue());
        dispatch_source_set_event_handler(source, ^{ [weakSelf requestShutdown:[NSString stringWithFormat:@"signal_%d", signum] exitCode:128 + signum grace:30]; });
        [self.signalSources addObject:source]; dispatch_resume(source);
    }
    self.deadline = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.deadline, dispatch_time(DISPATCH_TIME_NOW, timeout * NSEC_PER_SEC), DISPATCH_TIME_FOREVER, 0);
    dispatch_source_set_event_handler(self.deadline, ^{ [weakSelf requestShutdown:@"host_timeout" exitCode:124 grace:30]; });
    dispatch_resume(self.deadline);
    self.monitor = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(self.monitor, dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), 5 * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(self.monitor, ^{
        VMController *s = weakSelf;
        if (s && !s.stopping && FreeSpace(s.disk) < FREE_FLOOR) [s requestShutdown:@"host_disk_below_20_gib_or_monitor_failed" exitCode:75 grace:10];
    });
    dispatch_resume(self.monitor);
    self.pressure = dispatch_source_create(DISPATCH_SOURCE_TYPE_MEMORYPRESSURE, 0, DISPATCH_MEMORYPRESSURE_WARN | DISPATCH_MEMORYPRESSURE_CRITICAL, dispatch_get_main_queue());
    dispatch_source_set_event_handler(self.pressure, ^{
        VMController *s = weakSelf; if (!s) return;
        unsigned long flags = dispatch_source_get_data(s.pressure);
        if (flags & DISPATCH_MEMORYPRESSURE_CRITICAL) [s requestShutdown:@"host_memory_pressure_critical" exitCode:75 grace:5];
        else [s requestShutdown:@"host_memory_pressure_warning" exitCode:75 grace:10];
    });
    dispatch_resume(self.pressure);
    Event(@"start_requested", nil);
    [self.machine startWithCompletionHandler:^(NSError *error) {
        VMController *s = weakSelf; if (!s) return;
        if (error) [s finish:1 reason:@"start_failed" error:error];
        else { Event(@"vm_started", nil); if (s.stopping) [s tryGuestStop]; }
    }];
}
@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
#if !defined(__arm64__)
        Fail(@"This launcher requires native Apple Silicon ARM64");
#endif
        NSMutableDictionary *options = [NSMutableDictionary dictionary];
        BOOL checkOnly = NO;
        NSSet *known = [NSSet setWithArray:@[@"--disk", @"--seed", @"--kernel", @"--initrd", @"--timeout", @"--network"]];
        for (int i = 1; i < argc; ++i) {
            NSString *key = @(argv[i]);
            if ([key isEqualToString:@"--help"]) {
                puts("Usage: run-arm64-vm --disk RAW --seed ISO --kernel IMAGE [--initrd INITRD] [--timeout SECONDS] [--network nat|none] [--check-only]\nFixed: 2 vCPUs, 3072 MiB RAM, disk <=30 GiB. Timeout 30..1800 s, default1200. Network default none.\nstdout: guest hvc0; stderr: JSON host events. Exit0 means guest powered off, not ASan acceptance.\nSIGINT/TERM requests shutdown; own VM is force-stopped after30s if needed.");
                return 0;
            }
            if ([key isEqualToString:@"--check-only"]) { if (checkOnly) Fail(@"Repeated --check-only"); checkOnly = YES; continue; }
            if (![known containsObject:key] || options[key] || i + 1 >= argc || [@(argv[i + 1]) hasPrefix:@"--"]) Fail([@"Unknown, repeated or incomplete option: " stringByAppendingString:key]);
            options[key] = @(argv[++i]);
        }
        NSURL *disk = FileURL(options[@"--disk"], @"--disk");
        NSURL *seed = FileURL(options[@"--seed"], @"--seed");
        NSURL *kernel = FileURL(options[@"--kernel"], @"--kernel");
        NSURL *initrd = options[@"--initrd"] ? FileURL(options[@"--initrd"], @"--initrd") : nil;
        NSArray *paths = initrd ? @[disk.path, seed.path, kernel.path, initrd.path] : @[disk.path, seed.path, kernel.path];
        if ([NSSet setWithArray:paths].count != paths.count) Fail(@"Input files must be distinct");
        NSString *seconds = options[@"--timeout"] ?: @"1200";
        NSScanner *scanner = [NSScanner scannerWithString:seconds];
        NSInteger timeout;
        if (![scanner scanInteger:&timeout] || !scanner.isAtEnd || timeout < 30 || timeout > 1800) Fail(@"--timeout must be an integer from30 through1800");
        NSString *network = options[@"--network"] ?: @"none";
        if (![@[@"nat", @"none"] containsObject:network]) Fail(@"--network must be nat or none");
        if (![[NSFileManager defaultManager] isWritableFileAtPath:disk.path] || FileSize(disk) == 0 || FileSize(disk) > MAX_DISK) Fail(@"Raw VM disk must be writable, nonempty and <=30 GiB");
        if (FileSize(seed) == 0 || FileSize(seed) > 16ULL * 1024 * 1024) Fail(@"Seed image must be nonempty and <=16 MiB");
        NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:kernel.path];
        NSData *header = [handle readDataOfLength:64]; [handle closeFile];
        const unsigned char *bytes = header.bytes;
        if (header.length < 64 || bytes[56] != 0x41 || bytes[57] != 0x52 || bytes[58] != 0x4d || bytes[59] != 0x64) Fail(@"Kernel must be an uncompressed ARM64 Linux Image (ARM64 magic missing)");
        int pressureLevel = 0;
        size_t pressureSize = sizeof(pressureLevel);
        if (sysctlbyname("kern.memorystatus_vm_pressure_level", &pressureLevel, &pressureSize, NULL, 0) != 0 || pressureSize != sizeof(pressureLevel)) Fail(@"Cannot independently read host memory-pressure level");
        Event(@"host_memory_pressure_preflight", @{@"raw_level":@(pressureLevel), @"normal_level":@1});
        if (pressureLevel != 1) Fail(@"Host memory pressure is not normal; refusing VM startup");
        if (!VZVirtualMachine.supported) Fail(@"Apple Virtualization is unavailable");
        if (NSProcessInfo.processInfo.physicalMemory < 6ULL * 1024 * 1024 * 1024) Fail(@"Host RAM is insufficient for the fixed3 GiB VM");
        if (FreeSpace(disk) < FREE_FLOOR) Fail(@"Host free disk space is below20 GiB");
        int lockFD = open([[disk.path stringByAppendingString:@".host-lock"] fileSystemRepresentation], O_RDWR | O_CREAT | O_CLOEXEC, 0600);
        if (lockFD < 0 || flock(lockFD, LOCK_EX | LOCK_NB) != 0) Fail(@"Task VM lock unavailable; refusing concurrent use");
        NSError *error = nil;
        VZVirtualMachineConfiguration *config = [[VZVirtualMachineConfiguration alloc] init];
        VZGenericPlatformConfiguration *platform = [[VZGenericPlatformConfiguration alloc] init];
        platform.machineIdentifier = [[VZGenericMachineIdentifier alloc] init]; config.platform = platform;
        config.CPUCount = 2; config.memorySize = VM_MEMORY;
        VZLinuxBootLoader *loader = [[VZLinuxBootLoader alloc] initWithKernelURL:kernel];
        loader.initialRamdiskURL = initrd; loader.commandLine = KERNEL_ARGS; config.bootLoader = loader;
        VZDiskImageStorageDeviceAttachment *rootAttachment = [[VZDiskImageStorageDeviceAttachment alloc] initWithURL:disk readOnly:NO error:&error];
        if (!rootAttachment) Fail(error.localizedDescription);
        VZDiskImageStorageDeviceAttachment *seedAttachment = [[VZDiskImageStorageDeviceAttachment alloc] initWithURL:seed readOnly:YES error:&error];
        if (!seedAttachment) Fail(error.localizedDescription);
        VZVirtioBlockDeviceConfiguration *rootDevice = [[VZVirtioBlockDeviceConfiguration alloc] initWithAttachment:rootAttachment]; rootDevice.blockDeviceIdentifier = @"osproject-root";
        VZVirtioBlockDeviceConfiguration *seedDevice = [[VZVirtioBlockDeviceConfiguration alloc] initWithAttachment:seedAttachment]; seedDevice.blockDeviceIdentifier = @"osproject-seed";
        config.storageDevices = @[rootDevice, seedDevice];
        VZVirtioConsoleDeviceSerialPortConfiguration *console = [[VZVirtioConsoleDeviceSerialPortConfiguration alloc] init];
        console.attachment = [[VZFileHandleSerialPortAttachment alloc] initWithFileHandleForReading:nil fileHandleForWriting:NSFileHandle.fileHandleWithStandardOutput]; config.serialPorts = @[console];
        config.entropyDevices = @[[[VZVirtioEntropyDeviceConfiguration alloc] init]];
        if ([network isEqualToString:@"nat"]) {
            VZVirtioNetworkDeviceConfiguration *net = [[VZVirtioNetworkDeviceConfiguration alloc] init]; net.MACAddress = VZMACAddress.randomLocallyAdministeredAddress; net.attachment = [[VZNATNetworkDeviceAttachment alloc] init]; config.networkDevices = @[net];
        } else config.networkDevices = @[];
        config.directorySharingDevices = @[]; config.socketDevices = @[]; config.graphicsDevices = @[];
        if (![config validateWithError:&error]) Fail(error.localizedDescription ?: @"VM configuration validation failed");
        Event(@"configuration_validated", @{@"backend":@"Apple Virtualization.framework", @"guest_architecture":@"aarch64", @"vcpus":@2, @"memory_bytes":@(VM_MEMORY), @"disk_bytes_max":@(MAX_DISK), @"timeout_seconds":@(timeout), @"network":network, @"shared_directories":@0, @"published_ports":@0, @"host_os":NSProcessInfo.processInfo.operatingSystemVersionString, @"boot":@"direct_linux", @"kernel_command_line":KERNEL_ARGS, @"root_disk":disk.lastPathComponent, @"seed_disk":seed.lastPathComponent, @"kernel":kernel.lastPathComponent, @"initrd":initrd.lastPathComponent ?: @"none"});
        if (checkOnly) { Event(@"host_finished", @{@"reason":@"check_only_no_vm_started", @"exit_code":@0, @"asan_acceptance_decided_by_host":@NO}); flock(lockFD, LOCK_UN); close(lockFD); return 0; }
        static VMController *controller;
        controller = [VMController new]; controller.machine = [[VZVirtualMachine alloc] initWithConfiguration:config]; controller.machine.delegate = controller; controller.disk = disk; controller.lockFD = lockFD;
        [controller runWithTimeout:(int)timeout];
        dispatch_main();
    }
}
