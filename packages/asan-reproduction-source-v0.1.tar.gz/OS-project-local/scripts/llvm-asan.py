#!/usr/bin/env python3
"""Acquire pinned LLVM workloads and run a bounded ASan pilot on Linux."""

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import statistics
import subprocess
import sys
import time
import tempfile
import traceback
import uuid


ROOT = Path(__file__).resolve().parents[1]


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + "\n")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize_crlf_bytes(data):
    return data.replace(b"\r\n", b"\n")


def normalize_crlf(source, destination):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        stream.write(normalize_crlf_bytes(Path(source).read_bytes()))


def within(root, relative):
    relative = Path(relative)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Only confined relative paths are allowed")
    candidate = (Path(root) / relative).resolve()
    if not candidate.is_relative_to(Path(root).resolve()):
        raise ValueError("Path escapes its declared root")
    return candidate


class Deadline:
    """One monotonic wall-clock budget shared by every child process."""
    def __init__(self, seconds):
        if not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds <= 0:
            raise ValueError("Overall timeout must be finite and positive")
        self.started = time.monotonic()
        self.expires = self.started + seconds

    def remaining(self):
        return max(0.0, self.expires - time.monotonic())

    def check(self):
        if self.remaining() <= 0:
            raise TimeoutError("Overall monotonic time budget exhausted")


def kill_group(process):
    if os.name == "nt":
        process.kill()
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    process.wait()


def command(argv, prefix, timeout, cwd=None, env=None, deadline=None):
    """Append-only command evidence; every timeout kills the entire child group."""
    prefix = Path(prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    destinations = [prefix.with_suffix(s) for s in (".stdout.log", ".stderr.log", ".command.json")]
    if any(p.exists() for p in destinations):
        raise FileExistsError("Command evidence already exists: " + str(prefix))
    metadata = {"argv": [str(x) for x in argv], "timeout_seconds": timeout,
                "exit_code": None, "timed_out": False, "started": False}
    start = time.monotonic()
    process = None
    pending = None
    with destinations[0].open("xb") as out, destinations[1].open("xb") as err:
        try:
            effective = min(timeout, deadline.remaining()) if deadline else timeout
            metadata["effective_timeout_seconds"] = effective
            if effective <= 0:
                metadata.update(timed_out=True, overall_budget_exhausted=True)
                raise TimeoutError("Overall monotonic time budget exhausted before launch")
            process = subprocess.Popen(
                [str(x) for x in argv], cwd=cwd, env=env, stdout=out, stderr=err,
                start_new_session=(os.name != "nt"),
            )
            metadata["started"] = True
            try:
                metadata["exit_code"] = process.wait(timeout=effective)
            except subprocess.TimeoutExpired:
                kill_group(process)
                metadata.update(exit_code=process.returncode, timed_out=True,
                                overall_budget_exhausted=bool(deadline and deadline.remaining() <= 0))
        except BaseException as error:
            if process is not None and process.poll() is None:
                kill_group(process)
                metadata["exit_code"] = process.returncode
            metadata["error"] = type(error).__name__ + ": " + str(error)
            err.write((metadata["error"] + "\n").encode("utf-8", errors="replace"))
            if not isinstance(error, Exception):
                pending = error
        finally:
            metadata["elapsed_seconds"] = time.monotonic() - start
            save(destinations[2], metadata)
    if pending is not None:
        raise pending
    return metadata


def checked(argv, prefix, timeout, **kwargs):
    result = command(argv, prefix, timeout, **kwargs)
    if result["timed_out"] or result["exit_code"] != 0:
        raise RuntimeError("Command failed; inspect " + str(prefix) + ".stderr.log")
    return result


def check_source(source, config, deadline=None):
    source = Path(source).resolve()
    lock = load(ROOT / "workloads/llvm-suite-lock.json")
    if lock["commit"] != config["source"]["commit"]:
        raise ValueError("Workload lock and configuration disagree")
    if lock.get("file_count") != len(lock["files"]) or len({f["path"] for f in lock["files"]}) != len(lock["files"]):
        raise ValueError("Invalid or duplicate workload lock inventory")
    for item in lock["files"]:
        if deadline:
            deadline.check()
        path = within(source, item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
            raise ValueError("Upstream file missing or changed: " + item["path"])
    # The exported tree may omit .git, but may not introduce new source/support
    # files beyond the pinned inventory. Do not traverse Git metadata.
    inventory = set()
    for parent, directories, filenames in os.walk(source, followlinks=False):
        if deadline:
            deadline.check()
        directories[:] = [name for name in directories if not (Path(parent) == source and name == ".git")]
        for name in directories + filenames:
            path = Path(parent) / name
            if path.is_symlink():
                raise ValueError("Symlink in upstream source export: " + str(path.relative_to(source)))
        for name in filenames:
            if Path(parent) == source and name == ".git":
                continue
            inventory.add((Path(parent) / name).relative_to(source).as_posix())
    if inventory != {item["path"] for item in lock["files"]}:
        raise ValueError("Source export inventory differs from lock")
    # CMake discovers sources using globs: reject extra sources as well.
    directories = {b["directory"] for b in config["benchmarks"]} | set(config["source"].get("sparse_directories", []))
    for directory in sorted(directories):
        actual = {
            p.relative_to(source).as_posix()
            for p in within(source, directory).rglob("*") if p.is_file()
        }
        expected = {f["path"] for f in lock["files"] if f["path"].startswith(directory + "/")}
        if actual != expected:
            raise ValueError("Unexpected files in benchmark: " + directory)
    return {"commit": lock["commit"], "files_verified": len(lock["files"]),
            "verification": "configured commit equals lock; all locked content hashes and selected directory inventories match",
            "git_head_in_guest": "not asserted; exported source need not contain .git"}


def fetch(args, config):
    source = Path(args.source).resolve()
    logs = ROOT / "scratch" / ("llvm-fetch-" + time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + uuid.uuid4().hex[:8])
    logs.mkdir(parents=True, exist_ok=False)
    deadline = Deadline(config.get("source_fetch_timeout_seconds", config.get("host_vm", {}).get("source_fetch_timeout_seconds", 300)))
    git = ["git", "-c", "credential.helper="]
    if args.proxy is not None:
        git += ["-c", "http.proxy=" + args.proxy]
    git += ["-c", "http.lowSpeedLimit=1024", "-c", "http.lowSpeedTime=25"]
    needs_checkout = not source.exists()
    if needs_checkout:
        source.parent.mkdir(parents=True, exist_ok=True)
        # The source lock hashes the original Windows Git checkout bytes.
        checked(
            git + ["clone", "--depth", "1", "--filter=blob:none", "--no-checkout",
                   "--config", "core.autocrlf=true", "--branch", config["source"]["tag"],
                   "--single-branch", config["source"]["url"], str(source)],
            logs / "clone", 300, deadline=deadline,
        )
    checked(["git", "-C", str(source), "rev-parse", "HEAD"], logs / "revision", 15, deadline=deadline)
    revision = (logs / "revision.stdout.log").read_text().strip()
    if revision != config["source"]["commit"]:
        raise ValueError("Existing checkout has a different commit; use another destination")
    if needs_checkout:
        lock = load(ROOT / "workloads/llvm-suite-lock.json")
        patterns = ["/" + item["path"] for item in lock["files"]]
        checked(
            git + ["-C", str(source), "sparse-checkout", "set", "--no-cone", "--"] + patterns,
            logs / "sparse", 30, deadline=deadline,
        )
        checked(
            git + ["-C", str(source), "checkout", "--detach", revision],
            logs / "checkout", 180, deadline=deadline,
        )
    print(json.dumps(check_source(source, config, deadline), indent=2))


def parse_time(path):
    data = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        key, value = line.split()
        data[key] = int(value) if key == "exit" else float(value)
    if not {"exit", "real", "user", "sys"}.issubset(data):
        raise ValueError("Incomplete upstream timeit output")
    return data


def check_container_isolation(config, source, output):
    limits = config["limits"]
    memory_unit = {"m": 1024 ** 2, "g": 1024 ** 3}
    memory_budget = int(limits["memory"][:-1]) * memory_unit[limits["memory"][-1].lower()]
    cgroup = Path("/sys/fs/cgroup")
    cpu_quota, cpu_period = (cgroup / "cpu.max").read_text().split()
    status = dict(
        line.split(":", 1) for line in Path("/proc/self/status").read_text().splitlines()
        if ":" in line
    )
    checks = {
        "non_root": os.geteuid() != 0,
        "cpu_limit": cpu_quota != "max" and int(cpu_quota) / int(cpu_period) <= limits["cpus"],
        "memory_limit": int((cgroup / "memory.max").read_text()) <= memory_budget,
        "no_swap": (cgroup / "memory.swap.max").read_text().strip() == "0",
        "pid_limit": int((cgroup / "pids.max").read_text()) <= limits["pids"],
        "no_capabilities": int(status["CapEff"].strip(), 16) == 0,
        "no_new_privileges": status["NoNewPrivs"].strip() == "1",
        "network_disabled": set(os.listdir("/sys/class/net")) == {"lo"},
        "readonly_root": bool(os.statvfs("/").f_flag & os.ST_RDONLY),
        "readonly_project": bool(os.statvfs(ROOT).f_flag & os.ST_RDONLY),
        "readonly_source": bool(os.statvfs(source).f_flag & os.ST_RDONLY),
    }
    save(output / "validation/isolation.json", checks)
    if not all(checks.values()):
        raise ValueError("Container isolation differs from plan; inspect validation/isolation.json")


def memory_bytes(value):
    if isinstance(value, int):
        return value
    value = str(value).strip().lower()
    return int(value[:-1]) * {"m": 1024 ** 2, "g": 1024 ** 3}[value[-1]]


def read_cgroup_ancestry(cgroup_root=Path("/sys/fs/cgroup"), membership=Path("/proc/self/cgroup")):
    """Resolve unified membership and retain every visible ancestor's controls.

    A cgroup namespace can hide outer ancestors; an explicit limit must be visible
    here to pass. A hidden, stricter ancestor cannot weaken a visible upper bound.
    """
    members = [line[3:] for line in membership.read_text().splitlines() if line.startswith("0::")]
    if len(members) != 1 or not members[0].startswith("/") or ".." in Path(members[0]).parts:
        raise ValueError("A single valid cgroup-v2 membership is required")
    root = Path(cgroup_root).resolve()
    leaf = within(root, members[0].lstrip("/"))
    if not leaf.is_dir():
        raise ValueError("Current cgroup is not visible under cgroup-v2 mount")
    rows = []
    current = leaf
    while True:
        row = {"path": "/" + current.relative_to(root).as_posix().lstrip(".")}
        for name in ("cpu.max", "memory.max", "memory.swap.max", "pids.max"):
            path = current / name
            row[name] = path.read_text().strip() if path.is_file() else None
        rows.append(row)
        if current == root:
            break
        current = current.parent
    return rows


def effective_limits(rows):
    effective = {}
    for name in ("memory.max", "memory.swap.max", "pids.max"):
        values = [int(r[name]) for r in rows if r[name] not in (None, "max")]
        if any(n < 0 for n in values):
            raise ValueError("Negative cgroup control")
        effective[name] = min(values) if values else None
    ratios = []
    for row in rows:
        if row["cpu.max"] is not None:
            quota, period = row["cpu.max"].split()
            if int(period) <= 0:
                raise ValueError("Invalid CPU period")
            if quota != "max":
                if int(quota) <= 0:
                    raise ValueError("Invalid CPU quota")
                ratios.append(int(quota) / int(period))
    effective["cpus"] = min(ratios) if ratios else None
    return effective


def vm_observation(config, source, parent_network_namespace_file=None):
    status = dict(line.split(":", 1) for line in Path("/proc/self/status").read_text().splitlines() if ":" in line)
    rows = read_cgroup_ancestry()
    parent_file = Path(parent_network_namespace_file or "/run/llvm-asan-parent-netns")
    if parent_network_namespace_file is None:
        try:
            parent_namespace = os.readlink("/proc/1/ns/net")
            parent_source = "/proc/1/ns/net"
        except PermissionError:
            parent_namespace = None
    else:
        parent_namespace = None
    if parent_namespace is None:
        if parent_file.is_symlink() or parent_file.stat().st_uid != 0 or parent_file.stat().st_mode & 0o022:
            raise ValueError("Parent network namespace record must be root-owned and not writable by group/other")
        parent_namespace = parent_file.read_text().strip()
        parent_source = str(parent_file)
    if re.fullmatch(r"net:\[[0-9]+\]", parent_namespace) is None:
        raise ValueError("Invalid parent network namespace identity")
    return {
        "parent_network_namespace": parent_namespace, "parent_network_namespace_source": parent_source,
        "system": platform.system(), "machine": platform.machine(), "euid": os.geteuid(),
        "cgroup_ancestry": rows, "effective_limits": effective_limits(rows),
        "cap_eff": status.get("CapEff", "").strip(),
        "no_new_privs": status.get("NoNewPrivs", "").strip(),
        "network_interfaces": sorted(os.listdir("/sys/class/net")),
        "network_namespace": os.readlink("/proc/self/ns/net"),
        "root_readonly": bool(os.statvfs("/").f_flag & os.ST_RDONLY),
        "project_readonly": bool(os.statvfs(ROOT).f_flag & os.ST_RDONLY),
        "source_readonly": bool(os.statvfs(source).f_flag & os.ST_RDONLY),
    }


def evaluate_vm_isolation(config, observation):
    actual = observation["effective_limits"]
    limits = config["limits"]
    memory = min(memory_bytes(limits["memory"]), 2 * 1024 ** 3)
    cpus = min(limits["cpus"], 2)
    pids = min(limits["pids"], 128)
    return {
        "linux_arm64": observation["system"] == "Linux" and observation["machine"].lower() in ("aarch64", "arm64"),
        "non_root": observation["euid"] != 0,
        "cpu_limit": actual["cpus"] is not None and 0 < actual["cpus"] <= cpus,
        "memory_limit": actual["memory.max"] is not None and 0 < actual["memory.max"] <= memory,
        "no_swap": actual["memory.swap.max"] == 0,
        "pid_limit": actual["pids.max"] is not None and 0 < actual["pids.max"] <= pids,
        "no_capabilities": bool(observation["cap_eff"]) and int(observation["cap_eff"], 16) == 0,
        "no_new_privileges": observation["no_new_privs"] == "1",
        "network_disabled": observation["network_interfaces"] == ["lo"],
        "private_network_namespace": bool(observation["network_namespace"]) and bool(observation["parent_network_namespace"]) and observation["network_namespace"] != observation["parent_network_namespace"],
        "readonly_project": observation["project_readonly"] is True,
        "readonly_source": observation["source_readonly"] is True,
    }


def check_isolation(config, source, output, profile="container", parent_network_namespace_file=None):
    if profile == "container":
        # Retain every original constraint, including readonly root. Do not route
        # container runs through the less restrictive VM root-filesystem policy.
        return check_container_isolation(config, source, output)
    if profile != "systemd-vm":
        raise ValueError("Unknown isolation profile")
    record = {"profile": profile, "checks": {}, "root_filesystem_policy": "observed only; not claimed readonly"}
    try:
        record["observation"] = vm_observation(config, source, parent_network_namespace_file)
        record["checks"] = evaluate_vm_isolation(config, record["observation"])
        if not all(record["checks"].values()):
            raise ValueError("ARM64 VM isolation differs from plan")
    except Exception as error:
        record["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        save(Path(output) / "validation/isolation.json", record)


def summarize(records, config):
    rows = []
    for benchmark in config["benchmarks"]:
        name = benchmark["name"]
        groups = {}
        for arm in ("baseline", "asan"):
            samples = [
                r for r in records
                if r["benchmark"] == name and r["arm"] == arm and r["phase"] == "measure"
            ]
            indexes = [r["iteration"] for r in samples]
            complete = sorted(indexes) == list(range(1, config["repetitions"] + 1))
            valid = [
                r for r in samples
                if r["valid"] and isinstance(r.get("real_seconds"), (float, int))
                and math.isfinite(r["real_seconds"]) and r["real_seconds"] > 0
            ]
            times = [r["real_seconds"] for r in valid]
            warmups = [
                r for r in records
                if r["benchmark"] == name and r["arm"] == arm and r["phase"] == "warmup"
            ]
            warmup_complete = (
                sorted(r["iteration"] for r in warmups)
                == list(range(1, config["warmups"] + 1))
                and all(r["valid"] for r in warmups)
            )
            ok = complete and len(valid) == config["repetitions"] and warmup_complete
            groups[arm] = {
                "complete": ok, "valid_runs": len(valid),
                "warmups_valid": warmup_complete,
                "invalid_or_missing": max(0, config["repetitions"] - len(valid)),
                "mean_seconds": statistics.mean(times) if times else None,
                "sample_stddev_seconds": statistics.stdev(times) if len(times) >= 2 else None,
            }
        complete = all(g["complete"] for g in groups.values())
        baseline_mean = groups["baseline"]["mean_seconds"]
        asan_mean = groups["asan"]["mean_seconds"]
        ratio = asan_mean / baseline_mean if complete else None
        rows.append({
            "benchmark": name, **groups,
            "status": "valid_pilot" if complete else "incomplete_or_invalid",
            "runtime_ratio": ratio,
            "overhead_percent": (ratio - 1) * 100 if ratio is not None else None,
            "short_run_warning": complete and min(baseline_mean, asan_mean)
            < config["minimum_interpretable_seconds"],
        })
    complete = all(row["status"] == "valid_pilot" for row in rows)
    ratios = [row["runtime_ratio"] for row in rows] if complete else []
    return {
        "kind": config["kind"], "formal_claim_verdict": "inconclusive",
        "reason": "Different workloads/toolchain; exploratory pilot, not SPEC CPU2006 reproduction.",
        "all_benchmarks_valid": complete,
        "geometric_mean_runtime_ratio": math.exp(statistics.mean(map(math.log, ratios)))
        if ratios else None,
        "benchmarks": rows,
    }


def write_report(output, records, config):
    (output / "metrics").mkdir(parents=True, exist_ok=True)
    summary = summarize(records, config)
    save(output / "metrics/summary.json", summary)
    with (output / "metrics/samples.csv").open("x", newline="", encoding="utf-8") as stream:
        columns = [
            "benchmark", "arm", "phase", "iteration", "valid", "real_seconds",
            "user_seconds", "sys_seconds", "exit_code", "reference_match", "output_sha256",
        ]
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    lines = [
        "# LLVM / ASan exploratory pilot", "",
        "This is workload-transfer evidence, not a reproduction of SPEC CPU2006 values.",
        "Wall time includes process startup and program output; units are seconds.",
        "Standard deviation is the sample standard deviation (n-1).",
        "Runtime ratio = mean(ASan) / mean(baseline). No failed sample is a speedup.", "",
        "| Benchmark | Baseline mean +/- SD | ASan mean +/- SD | Ratio | Status |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in summary["benchmarks"]:
        def formatted(arm):
            group = row[arm]
            if not group["complete"]:
                return "invalid/missing (" + str(group["valid_runs"]) + " valid)"
            return f'{group["mean_seconds"]:.4f} +/- {group["sample_stddev_seconds"]:.4f}'
        ratio = f'{row["runtime_ratio"]:.3f}x' if row["runtime_ratio"] is not None else "N/A"
        status = row["status"] + ("; short run" if row["short_run_warning"] else "")
        lines.append(f'| {row["benchmark"]} | {formatted("baseline")} | {formatted("asan")} | {ratio} | {status} |')
    lines += ["", "Failed, missing, very short or sanitizer-reporting runs require investigation.",
              "No benchmark replacement or outlier removal was applied.", ""]
    with (output / "README.md").open("x", encoding="utf-8") as stream:
        stream.write("\n".join(lines))
    return summary


def sample_schedule(config):
    """Original 72-sample order: workload, warmup/measure, index, alternating arm."""
    for benchmark in config["benchmarks"]:
        for phase, count in (("warmup", config["warmups"]), ("measure", config["repetitions"])):
            for iteration in range(1, count + 1):
                arms = ("baseline", "asan") if iteration % 2 else ("asan", "baseline")
                for arm in arms:
                    yield benchmark, phase, iteration, arm


def copy_new(source, destination):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with Path(source).open("rb") as src, destination.open("xb") as dst:
        shutil.copyfileobj(src, dst)


def run(args, config):
    output = Path(args.output).resolve()
    source = Path(args.source).resolve()
    # A bootstrap host directory is never a guest run directory. Container wrappers
    # must use /evidence/guest-run; the VM wrapper uses /evidence/<new run ID>.
    output.mkdir(parents=True, exist_ok=False)
    manifest = {
        "run_id": args.run_id, "status": "started", "kind": config.get("kind"),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "project_commit": args.project_commit,
        "profile": getattr(args, "profile", "container"),
        "vm_id": getattr(args, "vm_id", None),
        "image_id": args.image if getattr(args, "profile", "container") == "container" else None,
        "vm_image_descriptor": args.image if getattr(args, "profile", "container") == "systemd-vm" else None,
        "runner_sha256": sha256(__file__), "paper_claim_verdict": "inconclusive",
        "platform": "-".join((platform.system(), platform.release(), platform.machine())), "python": sys.version,
    }
    records = []
    deadline = None
    build_root = None
    try:
        for directory in ("logs", "raw-outputs", "metrics", "config", "provenance", "validation"):
            (output / directory).mkdir()
        save(output / "run-intent.json", manifest)
        save(output / "config/effective.json", config)
        manifest["config_sha256"] = sha256(output / "config/effective.json")
        deadline = Deadline(config["overall_timeout_seconds"])
        if platform.system() != "Linux":
            raise ValueError("Execution requires Linux in the explicitly selected isolation profile")
        if config.get("execution_profile", manifest["profile"]) != manifest["profile"]:
            raise ValueError("CLI profile and configured execution_profile disagree")
        if not config.get("benchmarks") or not isinstance(config.get("warmups"), int) or config["warmups"] < 1 or not isinstance(config.get("repetitions"), int) or config["repetitions"] < 2:
            raise ValueError("Nonempty workloads, warmups and at least two measurements are required")
        if config["kind"] != "exploratory-workload-transfer":
            raise ValueError("This runner only produces exploratory-workload-transfer evidence")
        if manifest["profile"] == "systemd-vm" and config.get("execution_authorized") is not True:
            raise ValueError("VM execution is not authorized in this configuration; preparation only")
        save(output / "config/profile-differences.json", {
            "profile": manifest["profile"],
            "legacy_runner_sha256": "19e3c4cf039ffd462a35d0b12b7119e5f444fef1e7a0e5de3dbfa4c77f342a29",
            "preserved": ["configured upstream source content", "configure flags", "timeit and fpcmp semantics", "benchmark/phase/iteration/alternating-arm order", "mean and sample SD; equal-workload geometric mean"],
            "changes": ["systemd-vm explicitly checks ARM64 cgroup ancestry and actual readonly project/source; root readonly is recorded only", "one monotonic overall deadline; subprocess process-group kill", "create-only run, command and per-record evidence; terminal manifest written once", "portable Git TLS backend selection (no forced OpenSSL)", "container host wrapper must target fresh /evidence/guest-run"],
            "configured_differences": config.get("profile_differences", {}),
        })
        copy_new(ROOT / "workloads/llvm-suite-lock.json", output / "provenance/llvm-suite-lock.json")
        copy_new(__file__, output / "provenance/llvm-asan.py")
        check_isolation(config, source, output, manifest["profile"], getattr(args, "parent_network_namespace_file", None))
        manifest["source"] = check_source(source, config, deadline)
        for name, relative in (("LLVM-LICENSE.TXT", "LICENSE.TXT"),
                               ("OLDEN-LICENSE.TXT", "MultiSource/Benchmarks/Olden/LICENSE.TXT")):
            copy_new(source / relative, output / "provenance" / name)
        for label, argv in (("compiler", [config["cc"], "--version"]),
                            ("kernel", ["uname", "-a"]), ("cpu", ["lscpu"]),
                            ("packages", ["dpkg-query", "-W"])):
            checked(argv, output / "provenance" / label, 20, deadline=deadline)
            if label == "compiler" and config.get("expected_compiler_version"):
                text = (output / "provenance/compiler.stdout.log").read_text()
                version = re.search(r"clang version ([0-9]+\.[0-9]+\.[0-9]+)", text)
                manifest["compiler_version"] = version.group(1) if version else None
                if manifest["compiler_version"] != config["expected_compiler_version"]:
                    raise ValueError("Compiler version differs from configured exact pin")
        if manifest["profile"] == "systemd-vm":
            for tool in ("cmake", "ninja"):
                checked([tool, "--version"], output / "provenance" / tool,
                        20, deadline=deadline)
        for label, path in (("os-release", "/etc/os-release"),
                            ("cpuinfo", "/proc/cpuinfo"),
                            ("self-cgroup", "/proc/self/cgroup"),
                            ("self-status", "/proc/self/status"),
                            ("mountinfo", "/proc/self/mountinfo")):
            copy_new(path, output / "provenance" / (label + ".txt"))
        env = dict(os.environ, ASAN_OPTIONS=config["asan_options"], LC_ALL="C", TZ="UTC")
        env.pop("LD_PRELOAD", None)
        # Each invocation owns a fresh build directory; it is not reused or cleaned
        # into a new result. Its identity is retained, but binaries stay outside Git.
        build_root = Path(tempfile.mkdtemp(prefix="llvm-asan-build-", dir="/tmp"))
        manifest["build_directory"] = str(build_root)
        for arm in ("baseline", "asan"):
            print("Building " + arm, flush=True)
            build = build_root / arm
            sanitizer = " " + config["asan_flags"] if arm == "asan" else ""
            configure = [
                "cmake", "-G", "Ninja", "-S", str(source), "-B", str(build),
                "-DCMAKE_C_COMPILER=" + config["cc"],
                "-DCMAKE_CXX_COMPILER=" + config["cxx"],
                "-DTEST_SUITE_HOST_CC=" + config["cc"],
                "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_C_FLAGS_RELEASE=",
                "-DCMAKE_CXX_FLAGS_RELEASE=",
                "-DCMAKE_C_FLAGS=" + config["c_flags"] + sanitizer,
                "-DCMAKE_CXX_FLAGS=" + config["cxx_flags"] + sanitizer,
                "-DCMAKE_EXE_LINKER_FLAGS=" + sanitizer.strip(),
                "-DTEST_SUITE_COLLECT_CODE_SIZE=OFF",
                "-DTEST_SUITE_COLLECT_COMPILE_TIME=OFF",
                "-DTEST_SUITE_COPY_DATA=ON",
                "-DTEST_SUITE_SUBDIRS=" + ";".join(b["directory"] for b in config["benchmarks"]),
            ]
            checked(configure, output / "logs" / ("configure-" + arm),
                    config["configure_timeout_seconds"], env=env, deadline=deadline)
            checked(["cmake", "--build", str(build), "--parallel",
                     str(config["limits"]["build_jobs"])],
                    output / "logs" / ("build-" + arm),
                    config["build_timeout_seconds"], env=env, deadline=deadline)
            provenance = output / "provenance" / arm
            provenance.mkdir()
            copy_new(build / "CMakeCache.txt", provenance / "cmake-cache.txt")
            copy_new(build / "build.ninja", provenance / "build.ninja")
            save(provenance / "binaries.json", {
                b["name"]: sha256(build / b["directory"] / b["name"])
                for b in config["benchmarks"]
            })
            for b in config["benchmarks"]:
                copy_new(build / b["directory"] / (b["name"] + ".test"),
                                provenance / (b["name"] + ".test"))
        available = sorted(os.sched_getaffinity(0))
        os.sched_setaffinity(0, {available[0]})
        manifest["cpu_affinity"] = sorted(os.sched_getaffinity(0))
        timer = build_root / "baseline/tools/timeit"
        compare = build_root / "baseline/tools/fpcmp"
        if manifest["profile"] == "systemd-vm":
            save(output / "provenance" / "measurement-tools.json", {
                "timeit": sha256(timer), "fpcmp": sha256(compare),
            })
        for b, phase, iteration, arm in sample_schedule(config):
            if phase == "warmup" and iteration == 1 and arm == "baseline":
                print("Running " + b["name"], flush=True)
            label = f'{b["name"]}-{phase}-{iteration:02}-{arm}'
            raw = output / "raw-outputs"
            stdout = raw / (label + ".output.txt")
            timing = raw / (label + ".time.txt")
            if stdout.exists() or timing.exists():
                raise FileExistsError("Raw sample evidence already exists: " + label)
            deadline.check()
            executable = build_root / arm / b["directory"] / b["name"]
            argv = [
                str(timer), "--timeout", str(config["command_timeout_seconds"]),
                "--limit-core", "0", "--append-exitstatus",
                "--redirect-output", str(stdout), "--summary", str(timing),
                "--chdir", str(executable.parent), str(executable),
            ] + b["args"]
            result = command(argv, output / "logs" / label,
                             config["command_timeout_seconds"] + 5, env=env, deadline=deadline)
            record = {
                "benchmark": b["name"], "arm": arm, "phase": phase,
                "iteration": iteration, "sample_id": label, "valid": False,
                "exit_code": result["exit_code"],
                "timed_out": result["timed_out"], "reference_match": False,
            }
            if timing.exists():
                measured = parse_time(timing)
                record.update(real_seconds=measured["real"],
                              user_seconds=measured["user"],
                              sys_seconds=measured["sys"],
                              program_exit_code=measured["exit"])
            if stdout.exists():
                record["output_sha256"] = sha256(stdout)
                reference = source / b["directory"] / (b["name"] + ".reference_output")
                normalized_output = (
                    output / "validation" / "normalized-output" / (label + ".txt")
                )
                normalized_reference = (
                    output / "validation" / "normalized-reference"
                    / (b["name"] + ".txt")
                )
                normalize_crlf(stdout, normalized_output)
                if not normalized_reference.exists():
                    normalize_crlf(reference, normalized_reference)
                verification = command(
                    [str(compare), str(normalized_output), str(normalized_reference)],
                    output / "validation" / label, 10, env=env, deadline=deadline,
                )
                record["reference_match"] = not verification["timed_out"] and verification["exit_code"] == 0
                record["reference_line_endings"] = config["reference_line_endings"]
                record["normalized_output_sha256"] = sha256(normalized_output)
                record["normalized_reference_sha256"] = sha256(normalized_reference)
                record["sanitizer_report"] = b"AddressSanitizer" in stdout.read_bytes()
            record["valid"] = (
                not result["timed_out"] and result["exit_code"] == 0
                and record.get("program_exit_code") == 0
                and record["reference_match"] and not record.get("sanitizer_report", False)
            )
            records.append(record)
            save(output / "metrics/records" / f"{len(records):03d}.json", record)
            deadline.check()
        manifest["status"] = "passed_pilot" if summarize(records, config)["all_benchmarks_valid"] else "invalid_pilot"
    except BaseException as error:
        manifest.update(status="failed", error=type(error).__name__ + ": " + str(error))
        (output / "logs").mkdir(exist_ok=True)
        with (output / "logs/failure.log").open("x", encoding="utf-8") as stream:
            traceback.print_exc(file=stream)
    finally:
        manifest["samples"] = len(records)
        manifest["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if deadline:
            manifest["elapsed_seconds"] = time.monotonic() - deadline.started
            manifest["overall_budget_exhausted"] = deadline.remaining() <= 0
        try:
            save(output / "metrics/records.json", records)
            write_report(output, records, config)
        except Exception as error:
            manifest.update(status="failed", finalization_error=type(error).__name__ + ": " + str(error))
        manifest["evidence_sha256"] = {
            p.relative_to(output).as_posix(): sha256(p)
            for p in sorted(output.rglob("*")) if p.is_file() and p.name != "run-manifest.json"
        }
        save(output / "run-manifest.json", manifest)
        with (output / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
            for path in sorted(output.rglob("*")):
                if path.is_file() and path.name != "SHA256SUMS.txt":
                    stream.write(sha256(path) + "  " + path.relative_to(output).as_posix() + "\n")
    print("Evidence: " + str(output), flush=True)
    return 0 if manifest["status"] == "passed_pilot" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("fetch", "check-source", "run", "analyze"))
    parser.add_argument("--config", default=str(ROOT / "config/llvm-asan.json"))
    parser.add_argument("--source", default=str(ROOT / "workloads/downloads/llvm-test-suite"))
    parser.add_argument("--proxy", default=None)
    parser.add_argument("--output", default="/evidence")
    parser.add_argument("--report-dir")
    parser.add_argument("--run-id", default="unassigned")
    parser.add_argument("--project-commit", default="unassigned")
    parser.add_argument("--image", default=None)
    parser.add_argument("--vm-id")
    parser.add_argument("--parent-network-namespace-file")
    parser.add_argument("--profile", choices=("container", "systemd-vm"), default="container")
    args = parser.parse_args()
    config = load(args.config)
    if args.action == "fetch":
        fetch(args, config)
    elif args.action == "check-source":
        print(json.dumps(check_source(args.source, config), indent=2))
    elif args.action == "analyze":
        output = Path(args.output).resolve()
        config = load(output / "config/effective.json")
        manifest = load(output / "run-manifest.json")
        for relative, expected in manifest["evidence_sha256"].items():
            if sha256(within(output, relative)) != expected:
                raise ValueError("Run evidence changed: " + relative)
        report = Path(args.report_dir) if args.report_dir else ROOT / "results" / output.name
        report.mkdir(parents=True, exist_ok=False)
        write_report(report, load(output / "metrics/records.json"), config)
    else:
        return run(args, config)
    return 0


if __name__ == "__main__":
    sys.exit(main())
