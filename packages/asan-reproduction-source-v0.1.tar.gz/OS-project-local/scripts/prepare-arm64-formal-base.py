#!/usr/bin/env python3
"""Build the approved ARM64 dependency base and seal its provisioning evidence."""
import argparse
import base64
from datetime import datetime, timezone
import gzip
import json
import re
import runpy
import shlex
import signal
import subprocess
import time
from pathlib import Path


GIB = 1024 ** 3
PACKAGE_PINS = {
    "clang-18": "1:18.1.3-1ubuntu1",
    "llvm-18": "1:18.1.3-1ubuntu1",
    "libclang-rt-18-dev": "1:18.1.3-1ubuntu1",
    "libc6-dev": "2.39-0ubuntu8.12",
    "libstdc++-13-dev": "13.3.0-6ubuntu2~24.04.1",
    "python3": "3.12.3-0ubuntu2.1",
    "make": "4.3-4.1build2",
    "cmake": "3.28.3-1build7",
    "ninja-build": "1.11.1-2",
    "util-linux": "2.39.3-9ubuntu6.6",
}
SCRIPT = r'''#!/bin/bash
set -eu
export LC_ALL=C DEBIAN_FRONTEND=noninteractive
e=/var/log/arm64-formal-base
mkdir -p "$e"
exec > >(tee -a "$e/setup.log" /dev/hvc0) 2>&1
finish() {
    rc=$?
    trap - EXIT
    printf '%s\n' "$rc" > "$e/exit-code.txt"
    date -u +%FT%TZ > "$e/finished-at.txt"
    if [ "$(du -sx -B1 "$e" | cut -f1)" -lt 4000000 ]; then
        tar -C "$e" -czf /tmp/formal-base-evidence.tar.gz .
        printf '\nPILOT_EVIDENCE_SHA256 %s\n\nPILOT_EVIDENCE_BEGIN\n' "$(sha256sum /tmp/formal-base-evidence.tar.gz | cut -d' ' -f1)" > /dev/hvc0
        base64 /tmp/formal-base-evidence.tar.gz > /dev/hvc0
        printf '\nPILOT_EVIDENCE_END\n' > /dev/hvc0
    fi
    sync
    /sbin/poweroff
}
trap finish EXIT
date -u +%FT%TZ > "$e/clock-before.txt"
date -u -s '@EPOCH_VALUE' > "$e/clock-after.txt"
uname -r > "$e/kernel.txt"
uname -m > "$e/architecture.txt"
cp /etc/os-release "$e/os-release.txt"
for item in /etc/apt/sources.list /etc/apt/sources.list.d/*.sources; do
    if [ -f "$item" ]; then cat "$item"; fi
done > "$e/apt-sources.txt"
systemctl stop ssh.service ssh.socket 2>/dev/null || true
for n in /sys/class/net/*/statistics/rx_bytes; do printf '%s ' "$n"; cat "$n"; done > "$e/network-rx-before.txt"
timeout -k 5s 80s apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=20 update > "$e/apt-update.log" 2>&1
timeout -k 5s 140s apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=20 -o APT::Keep-Downloaded-Packages=true install -y --no-install-recommends PACKAGE_VALUES > "$e/apt-install.log" 2>&1
dpkg-query -W '-f=${binary:Package}\t${Version}\n' | sort > "$e/packages.txt"
for n in /sys/class/net/*/statistics/rx_bytes; do printf '%s ' "$n"; cat "$n"; done > "$e/network-rx-after.txt"
for net in /sys/class/net/*; do d=$(basename "$net"); if [ "$d" != lo ]; then ip link set "$d" down; fi; done
ip -json address > "$e/network-offline.json"
clang-18 --version > "$e/clang.txt"
cmake --version > "$e/cmake.txt"
ninja --version > "$e/ninja.txt"
if ! id pilotcheck >/dev/null 2>&1; then useradd --create-home --shell /bin/bash pilotcheck; fi
printf '%s\n' 'int main(void) { return 0; }' >/tmp/formal-asan-smoke.c
clang-18 -O2 -fsanitize=address /tmp/formal-asan-smoke.c -o /tmp/formal-asan-smoke
runuser -u pilotcheck -- env ASAN_OPTIONS='ASAN_32:help=1' timeout 10s /tmp/formal-asan-smoke > "$e/asan-rz32.log" 2>&1
runuser -u pilotcheck -- env ASAN_OPTIONS='ASAN_64:help=1' timeout 10s /tmp/formal-asan-smoke > "$e/asan-rz64.log" 2>&1
find /var/cache/apt/archives -name '*.deb' -print0 | sort -z | xargs -0 -r sha256sum > "$e/apt-cache-sha256.txt"
rm /tmp/formal-asan-smoke.c /tmp/formal-asan-smoke
'''

def approve(root, pilot):
    decisions = (root / "docs/DECISIONS.md").read_text()
    pilot["require"]("## D-025 " in decisions and "批准，开始推进" in decisions,
                     "D-025 execution authorization is required")

def seal(run, manifest, pilot):
    pilot["write_new"](run / "run-manifest.json", manifest)
    with (run / "SHA256SUMS.txt").open("x") as out:
        for path in sorted(run.rglob("*")):
            if path.is_file() and path != run / "SHA256SUMS.txt":
                out.write(pilot["digest"](path) + "  " + path.relative_to(run).as_posix() + "\n")

def check_diagnostics(evidence, options):
    for size in (32, 64):
        text = (evidence / ("asan-rz%d.log" % size)).read_text()
        for name in ("redzone", "max_redzone"):
            pattern = r"(?m)^\s*" + name + r"\s*\n[^\n]*Current Value:\s*" + str(size) + r"\b"
            if re.search(pattern, text) is None:
                raise ValueError("Runtime redzone option verification failed: " + name)
    for filename, expected in (
        ("kernel.txt", "6.8.0-147-generic"), ("architecture.txt", "aarch64"),
        ("clang.txt", "Ubuntu clang version 18.1.3 (1ubuntu1)"),
        ("cmake.txt", "cmake version 3.28.3"), ("ninja.txt", "1.11.1"),
    ):
        if (evidence / filename).read_text().splitlines()[0] != expected:
            raise ValueError("Dependency base version differs: " + filename)
    packages = dict(line.split("\t", 1) for line in (evidence / "packages.txt").read_text().splitlines())
    for name, version in PACKAGE_PINS.items():
        if packages.get(name, packages.get(name + ":arm64")) != version:
            raise ValueError("Dependency base package differs: " + name)
    for iface in json.loads((evidence / "network-offline.json").read_text()):
        if iface["ifname"] != "lo" and "UP" in iface["flags"]:
            raise ValueError("Preflight guest network was not isolated")
    if "Ubuntu 24.04.5 LTS" not in (evidence / "os-release.txt").read_text():
        raise ValueError("Dependency base OS differs")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--limit-seconds", type=int, default=420)
    parser.add_argument("--from-pilot", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    if not ((100 if args.from_pilot else 300) <= args.limit_seconds <= 480 and
            re.fullmatch(r"run-\d{8}t\d{6}z-exp-001-a\d{2}", args.run_id)):
        parser.error("Invalid run ID or provisioning time limit")
    pilot = runpy.run_path(str(root / "scripts/run-arm64-pilot.py"))
    pilot["verify_zone"](root)
    approve(root, pilot)
    run = root / "runs" / args.run_id
    instance = root / ".local/arm64-formal/dependency-base" / args.run_id
    instance.mkdir(parents=True, exist_ok=False)
    run.mkdir(exist_ok=False)
    t0 = time.monotonic()
    manifest = {"run_id": args.run_id, "kind": "dependency-base-preflight",
                "started_at": pilot["utc_now"](), "status": "failed",
                "activity_limit_seconds": args.limit_seconds}
    def expire(_signum, _frame):
        raise TimeoutError("Formal dependency-base preparation limit")
    signal.signal(signal.SIGALRM, expire)
    signal.signal(signal.SIGTERM, expire)
    signal.alarm(args.limit_seconds - (24 if args.from_pilot else 45))
    try:
        pressure = pilot["host_resources"](root)
        if args.from_pilot:
            historical = "run-20261118t151453z-pilot-arm64-001-a02"
            history = root / "runs" / historical
            pilot["require"](pilot["read_json"](history / "run-manifest.json")["status"] == "passed_pilot",
                             "Source pilot archival evidence is missing")
            asset = root / ".local/arm64-vm/assets/ubuntu-noble-20261017"
            historical_instance = root / ".local/arm64-pilot/instances" / historical
            original = historical_instance / "root.raw"
            binary = root / ".local/arm64-vm/bin/run-arm64-vm"
            pilot["require"](original.is_file() and not original.is_symlink() and original.stat().st_size == 30 * GIB,
                             "Source pilot disk is unavailable")
            pilot["require"](pilot["digest"](binary) == pilot["BINARY_SHA"], "Launcher changed")
            subprocess.run(["codesign", "--verify", "--strict", str(binary)], check=True, capture_output=True, timeout=10)
            receipts = {"source_pilot": historical, "pilot_manifest_sha256": pilot["digest"](history / "run-manifest.json"),
                        "source_disk_path": original.relative_to(root).as_posix(),
                        "signed_binary_sha256": pilot["digest"](binary)}
            manifest["derived_from_passed_pilot"] = historical
        else:
            asset, original, binary, receipts = pilot["verify_assets"](root)
        source_state = root / "workloads/downloads/llvm-test-suite"
        lock = pilot["read_json"](root / "workloads/llvm-suite-lock.json")
        cfg = pilot["read_json"](root / "config/llvm-asan-arm64.json")
        pilot["verify_source"](source_state, lock, cfg)
        pilot["write_new"](run / "provenance/host-preflight.json", pressure)
        pilot["write_new"](run / "provenance/input-assets.json", receipts)
        pilot["write_new"](run / "provenance/package-pins.json", PACKAGE_PINS)
        (run / "provenance/prepare-arm64-formal-base.py").write_bytes(Path(__file__).read_bytes())
        disk = instance / "root.raw"
        subprocess.run(["cp", "-c", str(original), str(disk)], check=True, timeout=80)
        disk.chmod(0o600)
        with disk.open("r+b") as f:
            f.truncate(30 * GIB)
        compressed_kernel = asset / "boot/noble-server-cloudimg-arm64-vmlinuz-generic"
        kernel = instance / "Image"
        data = compressed_kernel.read_bytes()
        kernel.write_bytes(gzip.decompress(data) if data.startswith(b"\x1f\x8b") else data)
        initrd = asset / "boot/noble-server-cloudimg-arm64-initrd-generic"
        opts32 = cfg["asan_options"]
        opts64 = opts32.replace(":redzone=32:max_redzone=32:", ":redzone=64:max_redzone=64:")
        if opts32 == opts64 or not re.fullmatch(r"[a-z0-9_=:]+", opts32):
            raise ValueError("Unexpected approved ASan flags")
        template = SCRIPT
        if args.from_pilot:
            template = "\n".join(line for line in SCRIPT.split("\n") if not line.startswith("timeout -k 5s "))
            template = template.replace('systemctl stop ssh.service ssh.socket 2>/dev/null || true',
                        'systemctl stop ssh.service ssh.socket 2>/dev/null || true\n'
                        'rm -rf -- /opt/pilot /var/log/arm64-pilot-evidence\n'
                        'rm -f -- /opt/pilot-inputs.tar.gz /opt/pilot-setup.sh /tmp/pilot-evidence.tar.gz\n'
                        'dmesg > "$e/guest-kernel.log"\n'
                        "if grep -Eiq 'EXT4-fs error|checksum invalid|Buffer I/O error' $e/guest-kernel.log; then exit 29; fi")
        setup = (template.replace("EPOCH_VALUE", str(int(time.time())))
                 .replace("PACKAGE_VALUES", shlex.join(f"{k}={v}" for k, v in PACKAGE_PINS.items()))
                 .replace("ASAN_32", opts32).replace("ASAN_64", opts64))
        (run / "config").mkdir()
        (run / "config/setup.sh").write_text(setup)
        cloud = {
            "hostname": "arm64-formal-base", "ssh_pwauth": False, "disable_root": True,
            "ssh_genkeytypes": [], "users": [{"name": "pilotcheck", "lock_passwd": True}],
            "write_files": [{"path": "/opt/formal-base-setup.sh", "encoding": "b64", "permissions": "0755",
                             "content": base64.b64encode(setup.encode()).decode()}],
            "runcmd": [["bash", "/opt/formal-base-setup.sh"]],
        }
        seed_dir = instance / "seed-files"
        seed_dir.mkdir()
        (seed_dir / "user-data").write_text("#cloud-config\n" + json.dumps(cloud) + "\n")
        (seed_dir / "meta-data").write_text(json.dumps({"instance-id": args.run_id, "local-hostname": "arm64-formal-base"}))
        seed = instance / "seed.iso"
        subprocess.run(["hdiutil", "makehybrid", "-iso", "-joliet", "-default-volume-name", "cidata",
                        "-o", str(seed), str(seed_dir)], check=True, capture_output=True, timeout=45)
        available = int(args.limit_seconds - (time.monotonic() - t0) - (59 if args.from_pilot else 90))
        bound = min(66 if args.from_pilot else 300, available)
        if bound < (50 if args.from_pilot else 120):
            raise TimeoutError("Insufficient room for guest setup, shutdown and sealing")
        print(json.dumps({"event": "base_provisioning_vm", "run_id": args.run_id, "vm_timeout": bound}), flush=True)
        (run / "logs").mkdir()
        argv = [str(binary), "--disk", str(disk), "--seed", str(seed), "--kernel", str(kernel),
                "--initrd", str(initrd), "--network", "none" if args.from_pilot else "nat", "--timeout", str(bound)]
        with (run / "logs/console.log").open("xb") as out, (run / "logs/lifecycle.log").open("xb") as err:
            rc = pilot["capture"](argv, out, err, bound)
        if args.from_pilot:
            signal.alarm(max(1, int(args.limit_seconds - (time.monotonic() - t0) - 3)))
        manifest["host_exit_code"] = rc
        packed = pilot["parse_frame"]((run / "logs/console.log").read_bytes())
        evidence = run / "guest-evidence"
        pilot["extract_safe"](packed, evidence)
        if rc or (evidence / "exit-code.txt").read_text().strip() != "0":
            raise RuntimeError("Guest setup did not finish normally; inspect guest-evidence and lifecycle")
        if '"reason":"guest_powered_off"' not in (run / "logs/lifecycle.log").read_text():
            raise RuntimeError("Guest shutdown not verified")
        check_diagnostics(evidence, opts32)
        disk.chmod(0o444)
        disk_hash = pilot["digest"](disk)
        expected_guest = {
            "packages_sha256": pilot["digest"](evidence / "packages.txt"),
            "kernel_release": "6.8.0-147-generic", "compiler_version": "18.1.3",
            "cmake_version": "3.28.3", "ninja_version": "1.11.1",
        }
        disk_receipt = {"base_disk_path": disk.relative_to(root).as_posix(),
                        "base_sha256": disk_hash, "bytes": disk.stat().st_size,
                        "kernel_path": kernel.relative_to(root).as_posix(),
                        "kernel_sha256": pilot["digest"](kernel),
                        "initrd_path": initrd.relative_to(root).as_posix(),
                        "initrd_sha256": pilot["digest"](initrd),
                        "expected_guest": expected_guest, "archive_sha256": pilot["bytes_digest"](packed)}
        pilot["write_new"](run / "validation/base.json", disk_receipt)
        manifest.update(status="passed_preflight", **disk_receipt)
        print(json.dumps(disk_receipt), flush=True)
    except (Exception, KeyboardInterrupt) as error:
        manifest["error"] = str(error).replace(str(root), "<work-zone>")
        print(json.dumps(manifest), flush=True)
    finally:
        signal.alarm(0)
        manifest.update(finished_at=pilot["utc_now"](), elapsed_seconds=time.monotonic() - t0)
        seal(run, manifest, pilot)
    return 0 if manifest["status"] == "passed_preflight" else 1

if __name__ == "__main__":
    raise SystemExit(main())
