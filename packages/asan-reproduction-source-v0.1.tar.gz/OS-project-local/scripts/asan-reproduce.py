#!/usr/bin/env python3
"""Prepare and replay the fixed Olden method without historical machine state.

The original sealed runner modules are used as libraries. Their command-line
activation gates and the archived execution configuration are never modified.
"""
import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import runpy
import shlex
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import time
import threading
import urllib.request
from types import SimpleNamespace


TEMPLATE = "config/asan-reproduction.json"
PLAN = "experiments/reproduction-001/PLAN.md"
STATE = ".local/asan-reproduction/sessions"
MAX_TOTAL = 10800
CAPS = {"fetch": 1800, "prepare": 900, "freeze": 120, "run": 3600}
MODULES = ("scripts/asan-reproduce.py", "scripts/run-arm64-formal.py",
           "scripts/run-arm64-pilot.py", "scripts/llvm-asan-formal.py",
           "scripts/llvm-asan.py", "scripts/analyze-asan-formal.py",
           "scripts/prepare-arm64-formal-base.py", "scripts/fetch-arm64-ubuntu.py",
           "scripts/run-arm64-vm.m", "config/arm64-vm.entitlements.plist",
           "workloads/llvm-suite-lock.json", TEMPLATE, PLAN)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def inside(root, logical):
    p = PurePosixPath(logical)
    require(not p.is_absolute() and p.parts and ".." not in p.parts and "\\" not in logical,
            "Expected a repository-relative path")
    target = root.joinpath(*p.parts)
    current = root
    for part in p.parts:
        current = current / part
        require(not current.is_symlink(), "Symlink in input path")
    require(target.resolve().is_relative_to(root) and not target.is_symlink(), "Path escapes work zone")
    return target


def identity(value):
    require(bool(re.fullmatch(r"[a-z0-9][a-z0-9-]{2,70}", value)), "Use a unique lowercase kebab-case identifier")
    return value


def zone(root):
    require(root.name == "OS-project-local" and (root / ".git").is_dir()
            and not (root / ".git").is_symlink(), "Use an independent OS-project-local Git repository")
    require((root / ".local/workspace-role").read_text().strip() == "work", "Work role marker is required")
    top = subprocess.check_output(["git", "-C", str(root), "rev-parse", "--show-toplevel"], text=True).strip()
    require(Path(top).resolve() == root, "Git root differs")
    require(not subprocess.check_output(["git", "-C", str(root), "remote"], text=True).strip(),
            "Work repository has a remote; leave it unchanged and use an independent work copy")
    common = subprocess.check_output(["git", "-C", str(root), "rev-parse", "--git-common-dir"], text=True).strip()
    require((root / common).resolve() == (root / ".git").resolve(), "Shared Git metadata is not allowed")
    result = subprocess.run(["git", "-C", str(root), "rev-parse", "--verify", "HEAD"],
                            capture_output=True, text=True, timeout=10)
    return result.stdout.strip() if result.returncode == 0 else "uncommitted"


def modules(root):
    return {name: runpy.run_path(str(root / "scripts" / file)) for name, file in (
        ("pilot", "run-arm64-pilot.py"), ("formal", "run-arm64-formal.py"),
        ("base", "prepare-arm64-formal-base.py"), ("suite", "llvm-asan.py"),
        ("analysis", "analyze-asan-formal.py"))}


def template(root):
    cfg = load(root / TEMPLATE)
    require(cfg.get("kind") == "asan-reproduction-template" and cfg.get("schema_version") == 1,
            "Unsupported public method template")
    require(not any(key in cfg for key in ("execution_authorized", "campaign_id", "base_disk_path")),
            "Template contains machine state or a prior activation")
    return cfg


def host(root):
    require(sys.version_info >= (3, 9), "Host Python 3.9 or later is required")
    require(platform.system() == "Darwin" and platform.machine() == "arm64", "Use an Apple Silicon Mac")
    for tool in ("git", "curl", "xcrun", "codesign", "hdiutil", "clang"):
        require(shutil.which(tool), "Missing host tool: " + tool)
    probe = subprocess.check_output(["sysctl", "-n", "kern.hv_support"], text=True, timeout=5).strip()
    require(probe == "1", "Hardware virtualization is unavailable")
    return modules(root)["pilot"]["host_resources"](root)


def power():
    lines = subprocess.check_output(["/usr/bin/pmset", "-g", "batt"], text=True, timeout=5).splitlines()
    require(lines and "AC Power" in lines[0], "Connect AC power before preparing or measuring")
    return {"source": lines[0], "settings": subprocess.check_output(
        ["/usr/bin/pmset", "-g", "custom"], text=True, timeout=5)}


def execute(argv, prefix, seconds, cwd=None, env=None):
    require(seconds > 0, "No stage budget remains")
    prefix = Path(prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    save(prefix.with_suffix(".command.json"), {"argv": [str(a).replace(str(cwd), "<work-zone>") if cwd else str(a) for a in argv], "timeout_seconds": seconds})
    # A process group ensures timeout never leaves a downloader or VM behind.
    with prefix.with_suffix(".stdout.log").open("xb") as out, prefix.with_suffix(".stderr.log").open("xb") as err:
        proc = subprocess.Popen([str(a) for a in argv], cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
        try:
            rc = proc.wait(timeout=seconds)
        except BaseException:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=40)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
            raise
    require(rc == 0, "Command failed (exit %s); inspect %s logs" % (rc, prefix.name))


def session_path(root, name):
    return inside(root, STATE + "/" + identity(name))


@contextmanager
def stage(root, session, phase, allowance):
    require(type(allowance) is int and 0 < allowance <= CAPS[phase], "Stage budget exceeds its documented cap")
    require(session.is_dir() and not session.is_symlink(), "Create a new session with fetch first")
    with (session / "activity.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        intent = load(session / "intent.json")
        ledger = session / "activity.jsonl"
        previous = [json.loads(line) for line in ledger.read_text().splitlines()] if ledger.exists() else []
        # An unfinished previous stage has unknown use and must be reviewed.
        require(not list(session.glob("active-*.json")), "An interrupted stage needs review; its budget is not reset")
        used = sum(item["elapsed_seconds"] for item in previous)
        require(used + allowance <= intent["total_budget_seconds"], "Insufficient cumulative session budget")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz")
        run_id = "run-%s-reproduction-001-a%02d" % (stamp, len(previous) + 1)
        run = root / "runs" / run_id
        run.mkdir(parents=True, exist_ok=False)
        active = session / ("active-" + phase + ".json")
        save(active, {"run_id": run_id, "phase": phase, "allowance_seconds": allowance})
        started = time.monotonic()
        previous_handler = signal.getsignal(signal.SIGUSR1)
        def stage_expired(signum, frame):
            raise TimeoutError("Stage reached its stop deadline; shutdown reserve retained")
        signal.signal(signal.SIGUSR1, stage_expired)
        timer = threading.Timer(allowance - 60 if allowance > 60 else allowance, lambda: os.kill(os.getpid(), signal.SIGUSR1))
        timer.daemon = True
        timer.start()
        receipt = {"run_id": run_id, "phase": phase, "session": session.name, "started_at": utc(),
                   "allowance_seconds": allowance, "prior_activity_seconds": used, "status": "failed"}
        remaining = lambda: max(0.0, allowance - (time.monotonic() - started))
        try:
            yield run, remaining
            require(remaining() > 0, "Stage exceeded its elapsed-time budget")
            receipt["status"] = "passed"
        except BaseException as error:
            receipt["error"] = str(error).replace(str(root), "<work-zone>")
            raise
        finally:
            timer.cancel()
            signal.signal(signal.SIGUSR1, previous_handler)
            receipt.update(finished_at=utc(), elapsed_seconds=time.monotonic() - started)
            save(run / "run-manifest.json", receipt)
            with (run / "SHA256SUMS.txt").open("x") as inventory:
                for file in sorted(run.rglob("*")):
                    if file.is_file() and file.name != "SHA256SUMS.txt":
                        inventory.write(sha(file) + "  " + file.relative_to(run).as_posix() + "\n")
            with ledger.open("a") as stream:
                stream.write(json.dumps(receipt, sort_keys=True) + "\n")
            active.unlink()


def asset_files(cfg):
    return cfg["ubuntu"]["assets"]


def verify_assets(folder, cfg):
    for item in asset_files(cfg):
        file = inside(folder, item["path"])
        require(file.is_file() and file.stat().st_size == item["bytes"] and sha(file) == item["sha256"],
                "Pinned Ubuntu input differs: " + item["path"])


def fetch(root, args):
    zone(root)
    host(root)
    require(type(args.total_budget_seconds) is int and 0 < args.total_budget_seconds <= MAX_TOTAL,
            "Set an explicit total session budget at most 10800 seconds")
    session = session_path(root, args.session)
    if getattr(args, "resume", False):
        intent = load(session / "intent.json")
        require(intent["total_budget_seconds"] == args.total_budget_seconds, "Resume cannot change the approved total budget")
        require(not (session / "fetch.json").exists(), "Fetch is already complete")
    else:
        session.mkdir(parents=True, exist_ok=False)
        save(session / "intent.json", {"session": args.session, "created_at": utc(),
         "total_budget_seconds": args.total_budget_seconds, "scope": "independent_method_reproduction",
         "invocation": [str(v).replace(str(root), "<work-zone>") for v in sys.argv[1:]],
         "historical_approval_reused": False})
    cfg = template(root)
    ledger = session / "activity.jsonl"
    previous = [json.loads(line) for line in ledger.read_text().splitlines()] if ledger.exists() else []
    spent_fetch = sum(row["elapsed_seconds"] for row in previous if row["phase"] == "fetch")
    require(args.activity_limit_seconds + spent_fetch <= CAPS["fetch"], "Resume exceeds the cumulative download-stage ceiling")
    with stage(root, session, "fetch", args.activity_limit_seconds) as (run, left):
        for asset_set, dest in (("disk", session / "assets"), ("boot", session / "assets/boot")):
            if dest.exists():
                expected = [item for item in asset_files(cfg) if (item["path"].startswith("boot/") == (asset_set == "boot"))]
                for item in expected:
                    existing = inside(session / "assets", item["path"])
                    require(existing.is_file() and existing.stat().st_size == item["bytes"] and sha(existing) == item["sha256"], "Partial acquisition needs review: " + item["path"])
                continue
            execute([sys.executable, "-B", root / "scripts/fetch-arm64-ubuntu.py", "--destination", dest,
                     "--evidence", run / ("ubuntu-" + asset_set), "--asset-set", asset_set],
                    run / ("fetch-" + asset_set), min(left(), 1000), root)
        verify_assets(session / "assets", cfg)
        source = session / "source"
        if source.exists():
            source = session / ("source-a%02d" % (len(previous) + 1))
        log_config = run / "source-config.json"
        save(log_config, cfg)
        transport = dict(os.environ)
        existing_proxies = urllib.request.getproxies()
        for scheme in ("http", "https"):
            if scheme in existing_proxies:
                transport.setdefault(scheme + "_proxy", existing_proxies[scheme])
        save(run / "transport.json", {"http_version": "HTTP/1.1", "proxy_source": "existing_os_or_environment_configuration",
             "https_proxy_present": "https_proxy" in transport or "HTTPS_PROXY" in transport, "proxy_values_recorded": False})
        offset = int(transport.get("GIT_CONFIG_COUNT", "0"))
        transport.update(GIT_CONFIG_COUNT=str(offset + 1), **{"GIT_CONFIG_KEY_%d" % offset: "http.version", "GIT_CONFIG_VALUE_%d" % offset: "HTTP/1.1"})
        before = set((root / "scratch").glob("llvm-fetch-*")) if (root / "scratch").exists() else set()
        try:
            execute([sys.executable, "-B", root / "scripts/llvm-asan.py", "fetch", "--config", log_config,
                     "--source", source], run / "fetch-source", min(left(), 320), root, env=transport)
        finally:
            after = set((root / "scratch").glob("llvm-fetch-*")) if (root / "scratch").exists() else set()
            for log in sorted(after - before):
                shutil.copytree(log, run / "source-acquisition" / log.name)
        save(session / "fetch.json", {"run_id": run.name, "assets": asset_files(cfg), "source_path": source.relative_to(root).as_posix(),
                                       "template_sha256": sha(root / TEMPLATE)})
    print(json.dumps({"session": session.name, "stage": "fetch", "status": "passed"}))


def extract_disk(archive, destination):
    destination.mkdir(exist_ok=False)
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        candidates = [m for m in members if m.name == "noble-server-cloudimg-arm64.img"]
        require(len(candidates) == 1 and candidates[0].isfile() and 0 < candidates[0].size <= 30 * 1024 ** 3,
                "Expected one bounded regular raw cloud image")
        member = candidates[0]
        path = destination / member.name
        # Only the one known file is extracted; archive paths/links are never followed.
        with source.extractfile(member) as inp, path.open("xb") as out:
            shutil.copyfileobj(inp, out, 4 * 1024 * 1024)
    with path.open("rb") as probe:
        require(probe.read(4) != b"QFI\xfb", "QCOW2 input is not supported")
    path.chmod(0o444)
    return path


def cloud_seed(instance, run_id, script, payload=None):
    files = [{"path": "/opt/reproduction-setup.sh", "encoding": "b64", "permissions": "0755",
              "content": base64.b64encode(script.encode()).decode()}]
    if payload is not None:
        files.append({"path": "/opt/pilot-inputs.tar.gz", "encoding": "b64", "permissions": "0644",
                      "content": base64.b64encode(payload).decode()})
    cloud = {"hostname": "asan-reproduction", "ssh_pwauth": False, "disable_root": True,
             "ssh_genkeytypes": [], "package_update": False, "package_upgrade": False,
             "users": [{"name": "pilotcheck", "lock_passwd": True}], "write_files": files,
             "runcmd": [["bash", "/opt/reproduction-setup.sh"]]}
    folder = instance / "seed-files"
    folder.mkdir()
    (folder / "user-data").write_text("#cloud-config\n" + json.dumps(cloud) + "\n")
    (folder / "meta-data").write_text(json.dumps({"instance-id": run_id, "local-hostname": "asan-reproduction"}))
    return folder


def prepare(root, args):
    zone(root)
    host(root)
    session = session_path(root, args.session)
    cfg = template(root)
    lib = modules(root)
    with stage(root, session, "prepare", args.activity_limit_seconds) as (run, left):
        require(load(session / "fetch.json")["template_sha256"] == sha(root / TEMPLATE), "Method template changed")
        verify_assets(session / "assets", cfg)
        save(run / "host-power.json", power())
        source = inside(root, load(session / "fetch.json")["source_path"])
        lib["suite"]["check_source"](source, cfg)
        instance = session / "base"
        instance.mkdir(exist_ok=False)
        raw = extract_disk(session / "assets/noble-server-cloudimg-arm64.tar.gz", instance / "original")
        launcher = session / "run-arm64-vm"
        sdk = subprocess.check_output(["xcrun", "--show-sdk-path"], text=True, timeout=10).strip()
        compile_argv = ["xcrun", "clang", "-fobjc-arc", "-fblocks", "-isysroot", sdk,
                        "-framework", "Foundation", "-framework", "Virtualization",
                        root / "scripts/run-arm64-vm.m", "-o", launcher]
        execute(compile_argv, run / "launcher-build", min(left(), 90), root)
        execute(["codesign", "--force", "--sign", "-", "--entitlements", root / "config/arm64-vm.entitlements.plist", launcher],
                run / "launcher-sign", min(left(), 20), root)
        execute(["codesign", "--verify", "--strict", launcher], run / "launcher-verify", min(left(), 20), root)
        save(run / "launcher.json", {"source_sha256": sha(root / "scripts/run-arm64-vm.m"),
             "binary_sha256": sha(launcher), "sdk_version": subprocess.check_output(
                 ["xcrun", "--show-sdk-version"], text=True, timeout=10).strip(),
             "compiler": subprocess.check_output(["xcrun", "clang", "--version"], text=True, timeout=10),
             "sdk_path_role": "machine-local SDK selected by xcrun", "signature": "local ad-hoc"})
        disk = instance / "root.raw"
        execute(["cp", "-c", raw, disk], run / "disk-copy", min(left(), 90), root)
        disk.chmod(0o600)
        with disk.open("r+b") as handle:
            handle.truncate(30 * 1024 ** 3)
        kernel_bytes = (session / "assets/boot/noble-server-cloudimg-arm64-vmlinuz-generic").read_bytes()
        kernel = instance / "Image"
        kernel.write_bytes(gzip.decompress(kernel_bytes) if kernel_bytes.startswith(b"\x1f\x8b") else kernel_bytes)
        initrd = session / "assets/boot/noble-server-cloudimg-arm64-initrd-generic"
        script = (lib["base"]["SCRIPT"].replace("EPOCH_VALUE", str(int(time.time())))
                  .replace("PACKAGE_VALUES", shlex.join(k + "=" + v for k, v in lib["base"]["PACKAGE_PINS"].items()))
                  .replace("ASAN_32", cfg["asan_options"])
                  .replace("ASAN_64", cfg["asan_options"].replace("redzone=32:max_redzone=32", "redzone=64:max_redzone=64")))
        (run / "setup.sh").write_text(script)
        seed_files = cloud_seed(instance, run.name, script)
        seed = instance / "seed.iso"
        execute(["hdiutil", "makehybrid", "-iso", "-joliet", "-default-volume-name", "cidata", "-o", seed, seed_files],
                run / "seed", min(left(), 45), root)
        bound = min(600, int(left() - 100))
        require(bound >= 300, "Insufficient stage time for bounded setup and shutdown")
        (run / "logs").mkdir()
        with (run / "logs/console.log").open("xb") as out, (run / "logs/lifecycle.log").open("xb") as err:
            rc = lib["pilot"]["capture"]([str(launcher), "--disk", str(disk), "--kernel", str(kernel), "--initrd", str(initrd),
                  "--seed", str(seed), "--network", "nat", "--timeout", str(bound)], out, err, bound)
        evidence = run / "guest-evidence"
        packed = lib["pilot"]["parse_frame"]((run / "logs/console.log").read_bytes())
        lib["pilot"]["extract_safe"](packed, evidence)
        events = [json.loads(line) for line in (run / "logs/lifecycle.log").read_text().splitlines() if line.startswith("{")]
        require(rc == 0 and any(e.get("reason") == "guest_powered_off" and e.get("exit_code") == 0 for e in events)
                and (evidence / "exit-code.txt").read_text().strip() == "0", "Base preparation or normal shutdown failed")
        lib["base"]["check_diagnostics"](evidence, cfg["asan_options"])
        disk.chmod(0o444)
        receipt = {"run_id": run.name, "base_disk_path": disk.relative_to(root).as_posix(), "base_sha256": sha(disk),
            "kernel_path": kernel.relative_to(root).as_posix(), "kernel_sha256": sha(kernel),
            "initrd_path": initrd.relative_to(root).as_posix(), "initrd_sha256": sha(initrd),
            "launcher_path": launcher.relative_to(root).as_posix(), "launcher_sha256": sha(launcher),
            "expected_guest": {"packages_sha256": sha(evidence / "packages.txt"), "kernel_release": "6.8.0-147-generic",
               "compiler_version": "18.1.3", "cmake_version": "3.28.3", "ninja_version": "1.11.1", "os_version": "24.04.5 LTS"},
            "source_path": source.relative_to(root).as_posix(),
            "template_sha256": sha(root / TEMPLATE), "archive_sha256": hashlib.sha256(packed).hexdigest()}
        save(run / "validation/base.json", receipt)
        save(session / "base.json", receipt)
    print(json.dumps({"session": session.name, "stage": "prepare", "status": "passed"}))


def freeze(root, args):
    revision = zone(root)
    host(root)
    require(2400 <= args.activity_limit_seconds <= CAPS["run"], "Campaign budget must be 2400..3600 seconds")
    session = session_path(root, args.session)
    campaign = identity(args.campaign)
    with stage(root, session, "freeze", 120) as (run, left):
        base = load(session / "base.json")
        cfg = template(root)
        require(base["template_sha256"] == sha(root / TEMPLATE), "Method changed since base preparation")
        for key in ("base", "kernel", "initrd", "launcher"):
            path = inside(root, base["base_disk_path"] if key == "base" else base[key + "_path"])
            require(sha(path) == base[key + "_sha256"], "Prepared asset changed: " + key)
        frozen = {k: v for k, v in cfg.items() if k not in ("ubuntu", "schema_version", "template_version", "kind")}
        bindings = {name: sha(root / name) for name in MODULES}
        frozen.update(base, kind="formal-olden-arm64", collection_role="independent_reproduction", frozen=True,
            execution_authorized=True, experiment_id=args.experiment, campaign_id=campaign, session=args.session,
            project_commit=revision, plan_path=PLAN, plan_sha256=bindings[PLAN], plan_version=re.search(r"\|\s*`exact_version`\s*\|\s*`([^`]+)`", (root / PLAN).read_text()).group(1),
            reproduction_bindings=bindings, expected_host_power=power(), campaign_budget_seconds=args.activity_limit_seconds,
            formal_guest_sha256=bindings["scripts/llvm-asan-formal.py"], pilot_runner_sha256=bindings["scripts/llvm-asan.py"],
            lock_sha256=bindings["workloads/llvm-suite-lock.json"], frozen_at=utc(),
            operator_request={"record_kind": "explicit_cli_request", "run_budget_seconds": args.activity_limit_seconds,
                              "historical_approval_reused": False})
        if args.experiment == "exp-002":
            main = load(session / "main.json")
            verify(root, SimpleNamespace(campaign=main["campaign_id"]))
            frozen["main_campaign_id"] = main["campaign_id"]
            frozen["main_completion_sha256"] = sha(root / "results" / main["campaign_id"] / "completion.json")
        path = session / (campaign + ".json")
        require(not (root / "results" / campaign).exists(), "Campaign output already exists")
        save(path, frozen)
        save(run / "freeze.json", {"config_path": path.relative_to(root).as_posix(), "config_sha256": sha(path),
                                   "bindings": bindings, "new_prepared_base": base["run_id"]})
    print(json.dumps({"status": "frozen", "config": path.relative_to(root).as_posix()}))


def validate_frozen(root, path):
    cfg = load(path)
    require(cfg.get("collection_role") == "independent_reproduction" and cfg.get("frozen") is True
            and cfg.get("execution_authorized") is True and cfg.get("experiment_id") in ("exp-001", "exp-002"),
            "Expected a new frozen reproduction configuration")
    identity(cfg["campaign_id"])
    require(set(cfg["reproduction_bindings"]) == set(MODULES), "Incomplete source binding")
    for logical, expected in cfg["reproduction_bindings"].items():
        require(sha(inside(root, logical)) == expected, "Source changed since freeze: " + logical)
    for name, logical in (("base", "base_disk_path"), ("kernel", "kernel_path"), ("initrd", "initrd_path"), ("launcher", "launcher_path")):
        asset = inside(root, cfg[logical])
        require(sha(asset) == cfg[name + "_sha256"], "Frozen asset changed: " + name)
    require(not stat.S_IMODE(inside(root, cfg["base_disk_path"]).stat().st_mode) & 0o222, "Dependency base must be read-only")
    modules(root)["suite"]["check_source"](inside(root, cfg["source_path"]), cfg)
    return cfg


def batch(root, config_path, cfg, slot, number, left, lib):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz")
    run_id = "run-%s-%s-a%02d" % (stamp, cfg["experiment_id"], number)
    run = root / "runs" / run_id
    instance = inside(root, ".local/asan-reproduction/instances/" + run_id)
    run.mkdir(exist_ok=False)
    instance.mkdir(parents=True, exist_ok=False)
    formal, pilot = lib["formal"], lib["pilot"]
    started = time.monotonic()
    manifest = {"run_id": run_id, "vm_id": run_id, "campaign_id": cfg["campaign_id"],
                "experiment_id": cfg["experiment_id"], "batch_slot": slot, "status": "preparing",
                "kind": "formal-olden-arm64", "collection_role": "independent_reproduction", "started_at": utc(),
                "project_commit": cfg["project_commit"], "plan_sha256": cfg["plan_sha256"],
                "config_payload_sha256": sha(config_path)}
    try:
        require(left() >= 960, "Not enough remaining budget for one batch and final audit")
        with formal["phase_budget"](150, "preparation_timeout"):
            save(run / "config/effective.json", cfg)
            for logical in MODULES:
                target = run / "provenance/source" / logical
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((root / logical).read_bytes())
            source = inside(root, cfg["source_path"])
            payload, hashes = formal["input_archive"](root, config_path, source, load(root / "workloads/llvm-suite-lock.json"))
            save(run / "provenance/guest-inputs.json", hashes)
            save(run / "provenance/host-preflight.json", host(root))
            require(power() == cfg["expected_host_power"], "Power profile changed since freeze")
            disk = instance / "root.raw"
            execute(["cp", "-c", inside(root, cfg["base_disk_path"]), disk], run / "clone", 90, root)
            disk.chmod(0o600)
            require(sha(disk) == cfg["base_sha256"], "Fresh clone differs")
            script = formal["setup_text"](run_id, cfg["project_commit"], slot, hashlib.sha256(payload).hexdigest(), int(time.time()))
            (run / "config/guest-setup.sh").write_text(script)
            seed_files = cloud_seed(instance, run_id, script, payload)
            seed = instance / "seed.iso"
            execute(["hdiutil", "makehybrid", "-iso", "-joliet", "-default-volume-name", "cidata", "-o", seed, seed_files],
                    run / "seed", 40, root)
            launcher = inside(root, cfg["launcher_path"])
            execute(["codesign", "--verify", "--strict", launcher], run / "launcher-verify", 15, root)
        require(left() >= 810, "Budget cannot cover VM, shutdown, sealing and audit")
        argv = [str(launcher), "--disk", str(disk), "--kernel", str(inside(root, cfg["kernel_path"])),
                "--initrd", str(inside(root, cfg["initrd_path"])), "--seed", str(seed), "--network", "none", "--timeout", "420"]
        rc = formal["launch_batch"](argv, run, instance, pilot)
        with formal["phase_budget"](90, "sealing_timeout"):
            manifest["archive_sha256"] = formal["recover_guest"](run, instance, rc, pilot)
            files, count = formal["verify_guest_artifacts"](run / "guest-evidence", cfg, cfg["project_commit"], slot, run_id, source, pilot)
            manifest.update(status="passed_batch", samples=count, guest_files_checked=files, host_exit_code=rc)
    except BaseException as error:
        manifest.update(status="failed", failure_class=getattr(error, "category", "operational"),
                        error=str(error).replace(str(root), "<work-zone>"))
    manifest["elapsed_seconds"] = time.monotonic() - started
    formal["seal"](run, manifest, pilot)
    require(manifest["status"] == "passed_batch", "Batch failed; preserve " + run.name + " and inspect its manifest")
    return run


def collect(root, args):
    zone(root)
    host(root)
    path = args.config.resolve()
    require(path.is_relative_to(root), "Config must be inside the work zone")
    # Expensive checks are charged to the same stage, not outside its ledger.
    cfg = load(path)
    session = session_path(root, cfg["session"])
    with stage(root, session, "run", cfg["campaign_budget_seconds"]) as (receipt, left):
        cfg = validate_frozen(root, path)
        if cfg["experiment_id"] == "exp-002":
            require(sha(root / "results" / identity(cfg["main_campaign_id"]) / "completion.json") == cfg["main_completion_sha256"], "Main prerequisite changed")
            verify(root, SimpleNamespace(campaign=cfg["main_campaign_id"]))
        output = root / "results" / cfg["campaign_id"]
        output.mkdir(parents=True, exist_ok=False)
        save(output / "effective.json", cfg)
        save(output / "intent.json", {"config_sha256": sha(path), "session": cfg["session"],
                                       "collection_role": "independent_reproduction"})
        lib = modules(root)
        runs = []
        try:
            for slot in range(3):
                runs.append(batch(root, path, cfg, slot, slot + 1, left, lib))
            require(left() > 0, "No time remains for final audit")
            summary = lib["analysis"]["analyze"](cfg["experiment_id"], cfg["campaign_id"], runs)
            require(summary["included_batch_slots"] == [0, 1, 2] and not summary["missing_valid_batch_slots"]
                    and not summary["unresolved_deviations"] and summary["aggregate"] is not None, "Final audit rejected campaign evidence")
            save(output / "summary.json", summary)
            save(output / "completion.json", {"status": "complete", "campaign_id": cfg["campaign_id"],
                  "run_ids": [r.name for r in runs], "summary_sha256": sha(output / "summary.json"),
                  "config_path": (output / "effective.json").relative_to(root).as_posix(), "config_sha256": sha(output / "effective.json"),
                  "collection_role": "independent_reproduction"})
            if cfg["experiment_id"] == "exp-001":
                save(session / "main.json", {"campaign_id": cfg["campaign_id"], "completion_sha256": sha(output / "completion.json")})
        except BaseException as error:
            save(output / "stopped.json", {"status": "stopped", "completed_runs": [r.name for r in runs],
                    "error": str(error).replace(str(root), "<work-zone>"), "receipt_run": receipt.name})
            raise
    print(json.dumps({"campaign": cfg["campaign_id"], "status": "complete"}))


def verify(root, args):
    identity(args.campaign)
    output = root / "results" / args.campaign
    receipt = load(output / "completion.json")
    require(receipt["status"] == "complete" and receipt["campaign_id"] == args.campaign,
            "No complete campaign")
    cfg_path = inside(root, receipt["config_path"])
    require(sha(cfg_path) == receipt["config_sha256"], "Effective config changed")
    cfg = load(cfg_path)
    runs = [inside(root, "runs/" + identity(name)) for name in receipt["run_ids"]]
    actual = modules(root)["analysis"]["analyze"](cfg["experiment_id"], args.campaign, runs)
    require(actual["included_batch_slots"] == [0, 1, 2] and not actual["missing_valid_batch_slots"]
            and not actual["unresolved_deviations"] and actual["aggregate"] is not None, "Campaign audit is incomplete or invalid")
    require(sha(output / "summary.json") == receipt["summary_sha256"]
            and actual == load(output / "summary.json"), "Recomputed summary differs")
    print(json.dumps({"campaign": args.campaign, "status": "verified", "batches": len(runs)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check")
    for name in ("fetch", "prepare", "freeze"):
        child = commands.add_parser(name)
        child.add_argument("--session", required=True)
        child.add_argument("--activity-limit-seconds", required=True, type=int)
        if name == "fetch":
            child.add_argument("--total-budget-seconds", required=True, type=int)
            child.add_argument("--resume", action="store_true", help="Continue a failed fetch without resetting its ledger or total budget")
        if name == "freeze":
            child.add_argument("--experiment", required=True, choices=("exp-001", "exp-002"))
            child.add_argument("--campaign", required=True)
    child = commands.add_parser("run")
    child.add_argument("--config", required=True, type=Path)
    child = commands.add_parser("verify")
    child.add_argument("--campaign", required=True)
    args = parser.parse_args()
    def stop_requested(signum, frame):
        raise KeyboardInterrupt("Host termination requested")
    signal.signal(signal.SIGTERM, stop_requested)
    root = args.root.resolve()
    try:
        if args.command == "check":
            revision = zone(root)
            require(all((root / name).is_file() for name in MODULES), "Public package is incomplete")
            template(root)
            resources = host(root)
            print(json.dumps({"status": "passed_host_check", "project_commit": revision, "resources": resources, "vm_started": False}))
        else:
            {"fetch": fetch, "prepare": prepare, "freeze": freeze, "run": collect, "verify": verify}[args.command](root, args)
    except (Exception, KeyboardInterrupt) as error:
        print(json.dumps({"status": "failed", "error": str(error).replace(str(root), "<work-zone>")}), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
