# Historical formal experiment plans

These byte-exact copies document the completed November 19, 2026 experiments. They are recovery material, not active instructions or permission for a new run. Relative links inside snapshots retain their original repository-path meaning.

Use the current reproduction guide and reproduction-001 plan for new work. Preserve these snapshots and their manifest hashes. Original decisions, machine-specific execution configurations, disk images and personal inputs are not part of this package.
