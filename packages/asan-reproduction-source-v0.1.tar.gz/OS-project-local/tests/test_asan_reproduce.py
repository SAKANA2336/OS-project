"""Offline checks for independent replay staging; no VM, network or benchmark."""
import contextlib
import io
import json
from pathlib import Path
import runpy
import stat
import subprocess
import sys
import tarfile
import tempfile
import unittest
from types import SimpleNamespace
from unittest import mock


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/asan-reproduce.py"
if not SCRIPT.is_file():
    SCRIPT = Path(__file__).with_name("asan-reproduce.py")
PUBLIC = runpy.run_path(str(SCRIPT))
# runpy returns a copy: patch the functions' actual shared global namespace.
CODE = PUBLIC["save"].__globals__


class ReplayTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name).resolve() / "OS-project-local"
        self.root.mkdir()

    def session(self, budget=1200):
        session = CODE["session_path"](self.root, "test-session")
        session.mkdir(parents=True)
        CODE["save"](session / "intent.json", {"total_budget_seconds": budget})
        return session

    def frozen_fixture(self):
        """Fresh local assets and scripts, with no historical run directories."""
        for logical in CODE["MODULES"]:
            path = self.root / logical
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(("fixture " + logical).encode())
        cfg = {"collection_role": "independent_reproduction", "frozen": True,
               "execution_authorized": True, "experiment_id": "exp-001",
               "campaign_id": "new-campaign", "source_path": "new-source",
               "reproduction_bindings": {p: CODE["sha"](self.root / p) for p in CODE["MODULES"]}}
        (self.root / cfg["source_path"]).mkdir()
        for name, logical_key in (("base", "base_disk_path"), ("kernel", "kernel_path"),
                                  ("initrd", "initrd_path"), ("launcher", "launcher_path")):
            logical = "new-assets/" + name
            path = self.root / logical
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(("asset " + name).encode())
            cfg[logical_key] = logical
            cfg[name + "_sha256"] = CODE["sha"](path)
        (self.root / cfg["base_disk_path"]).chmod(0o444)
        path = self.root / "new-frozen.json"
        CODE["save"](path, cfg)
        return path, cfg

    def test_json_rejects_duplicate_keys_and_nonfinite_numbers(self):
        path = self.root / "input.json"
        for data in ('{"a":1,"a":2}', '{"x":NaN}', '{"x":Infinity}', '{"x":-Infinity}'):
            with self.subTest(data=data):
                path.write_text(data)
                with self.assertRaises(ValueError):
                    CODE["load"](path)
        path.write_text('{"a":1,"b":[2,3]}')
        self.assertEqual(CODE["load"](path), {"a": 1, "b": [2, 3]})

    def test_evidence_save_never_overwrites(self):
        path = self.root / "evidence.json"
        CODE["save"](path, {"original": True})
        before = path.read_bytes()
        with self.assertRaises(FileExistsError):
            CODE["save"](path, {"original": False})
        self.assertEqual(path.read_bytes(), before)

    def test_paths_reject_traversal_absolute_backslash_and_symlinks(self):
        for logical in ("../escape", "/absolute", "a/../../escape", "a\\b", "."):
            with self.subTest(path=logical), self.assertRaises(ValueError):
                CODE["inside"](self.root, logical)
        outside = Path(self.directory.name) / "outside"
        outside.mkdir()
        (self.root / "escape").symlink_to(outside, target_is_directory=True)
        (self.root / "leaf").symlink_to(outside)
        for logical in ("escape/new-file", "leaf"):
            with self.subTest(path=logical), self.assertRaises(ValueError):
                CODE["inside"](self.root, logical)
        self.assertEqual(CODE["inside"](self.root, "runs/new-run"), self.root / "runs/new-run")

    def test_identifier_rejects_shell_and_path_material(self):
        for value in ("../other", "MixedCase", "two words", "a;echo", "$(id)", "ab", "a" * 73):
            with self.subTest(value=value), self.assertRaises(ValueError):
                CODE["identity"](value)
        self.assertEqual(CODE["identity"]("independent-main-001"), "independent-main-001")

    def test_session_path_cannot_follow_an_external_parent_symlink(self):
        parent = self.root / CODE["STATE"]
        parent.parent.mkdir(parents=True)
        outside = Path(self.directory.name) / "external-sessions"
        outside.mkdir()
        parent.symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, r"escapes|[Ss]ymlink"):
            CODE["session_path"](self.root, "independent-session")
        self.assertEqual(list(outside.iterdir()), [])

    def test_public_template_rejects_prior_activation_and_machine_state(self):
        path = self.root / CODE["TEMPLATE"]
        path.parent.mkdir(parents=True)
        clean = {"kind": "asan-reproduction-template", "schema_version": 1}
        path.write_text(json.dumps(clean))
        self.assertEqual(CODE["template"](self.root), clean)
        for field, value in (("execution_authorized", False), ("campaign_id", "old-campaign"),
                             ("base_disk_path", ".local/old-image")):
            with self.subTest(field=field):
                path.write_text(json.dumps({**clean, field: value}))
                with self.assertRaisesRegex(ValueError, "machine state|activation"):
                    CODE["template"](self.root)

    def test_source_fetch_uses_existing_cli_and_keeps_failed_acquisition_logs(self):
        cfg = {"kind": "asan-reproduction-template", "schema_version": 1, "ubuntu": {"assets": []}}
        original = b"source fetch failed before benchmark\n"

        def execute_fixture(argv, prefix, seconds, cwd=None, env=None):
            values = [str(value) for value in argv]
            if any(value.endswith("/llvm-asan.py") for value in values):
                self.assertIn("--source", values)
                self.assertNotIn("--destination", values)
                self.assertNotIn("--evidence", values)
                logs = self.root / "scratch/llvm-fetch-fixture"
                logs.mkdir(parents=True)
                (logs / "clone.stderr.log").write_bytes(original)
                raise RuntimeError("source fixture failure")

        replacements = {"zone": lambda root: "revision", "host": lambda root: {},
                        "template": lambda root: cfg, "verify_assets": lambda *a: None,
                        "execute": execute_fixture}
        args = SimpleNamespace(session="fetch-fixture", total_budget_seconds=2400,
                               activity_limit_seconds=1800)
        with mock.patch.dict(CODE, replacements), self.assertRaisesRegex(RuntimeError, "source fixture failure"):
            CODE["fetch"](self.root, args)
        run, = (self.root / "runs").iterdir()
        self.assertEqual((run / "source-acquisition/llvm-fetch-fixture/clone.stderr.log").read_bytes(), original)
        self.assertEqual(CODE["load"](run / "run-manifest.json")["status"], "failed")

    def resume_fixture(self, used=99.33):
        session = self.session(budget=7200)
        intent = {"session": session.name, "created_at": "2026-11-25T00:00:00+00:00",
                  "total_budget_seconds": 7200, "scope": "independent_method_reproduction",
                  "historical_approval_reused": False}
        (session / "intent.json").write_text(json.dumps(intent) + "\n")
        previous = {"run_id": "run-prior-failed-fetch", "phase": "fetch", "status": "failed",
                    "elapsed_seconds": used, "prior_activity_seconds": 0}
        (session / "activity.jsonl").write_text(json.dumps(previous) + "\n")
        assets = []
        for logical, content in (("disk.img", b"verified fixture disk"), ("boot/kernel", b"verified fixture kernel")):
            asset = session / "assets" / logical
            asset.parent.mkdir(parents=True, exist_ok=True)
            asset.write_bytes(content)
            assets.append({"path": logical, "bytes": len(content), "sha256": CODE["sha"](asset)})
        cfg = {"kind": "asan-reproduction-template", "schema_version": 1, "ubuntu": {"assets": assets}}
        CODE["save"](self.root / CODE["TEMPLATE"], cfg)
        return session

    def test_fetch_resume_cannot_replace_the_original_total_budget(self):
        session = self.resume_fixture()
        intent = (session / "intent.json").read_bytes()
        ledger = (session / "activity.jsonl").read_bytes()
        execute = mock.Mock(side_effect=AssertionError("Resume budget rejection must precede network work"))
        args = SimpleNamespace(session=session.name, total_budget_seconds=10800,
                               activity_limit_seconds=1000, resume=True)
        with mock.patch.dict(CODE, {"zone": lambda root: "revision", "host": lambda root: {}, "execute": execute}):
            with self.assertRaises(ValueError):
                CODE["fetch"](self.root, args)
        execute.assert_not_called()
        self.assertEqual((session / "intent.json").read_bytes(), intent)
        self.assertEqual((session / "activity.jsonl").read_bytes(), ledger)

    def test_fetch_resume_counts_the_failed_attempt_against_fetch_cap(self):
        session = self.resume_fixture(used=99.33)
        original_intent = (session / "intent.json").read_bytes()
        execute = mock.Mock(side_effect=AssertionError("An exhausted fetch cap must prevent all network work"))
        # 99.33 + 1701 exceeds the unchanged 1800-second fetch cap.
        args = SimpleNamespace(session=session.name, total_budget_seconds=7200,
                               activity_limit_seconds=1701, resume=True)
        with mock.patch.dict(CODE, {"zone": lambda root: "revision", "host": lambda root: {}, "execute": execute}):
            with self.assertRaises(ValueError):
                CODE["fetch"](self.root, args)
        execute.assert_not_called()
        self.assertEqual((session / "intent.json").read_bytes(), original_intent)
        first = json.loads((session / "activity.jsonl").read_text().splitlines()[0])
        self.assertEqual(first["elapsed_seconds"], 99.33)

    def test_fetch_resume_reuses_verified_assets_and_preserves_partial_source(self):
        session = self.resume_fixture()
        original_intent = (session / "intent.json").read_bytes()
        old_source = session / "source"
        old_source.mkdir()
        partial = old_source / "partial-acquisition.txt"
        partial.write_text("retain this failed attempt")
        invocations = []

        def fetch_fixture(argv, prefix, seconds, cwd=None, env=None):
            values = [str(value) for value in argv]
            self.assertTrue(any(value.endswith("/llvm-asan.py") for value in values),
                            "Verified Ubuntu assets must not be downloaded again")
            self.assertIn("--source", values)
            self.assertIsNotNone(env)
            transport_slot = int(env["GIT_CONFIG_COUNT"]) - 1
            self.assertEqual(env["GIT_CONFIG_KEY_%d" % transport_slot], "http.version")
            self.assertEqual(env["GIT_CONFIG_VALUE_%d" % transport_slot], "HTTP/1.1")
            new_source = Path(values[values.index("--source") + 1])
            self.assertNotEqual(new_source, old_source)
            self.assertTrue(new_source.name.startswith("source-a"))
            new_source.mkdir()
            (new_source / "acquired.txt").write_text("new source attempt")
            invocations.append(new_source)

        args = SimpleNamespace(session=session.name, total_budget_seconds=7200,
                               activity_limit_seconds=1000, resume=True)
        replacements = {"zone": lambda root: "revision", "host": lambda root: {}, "execute": fetch_fixture}
        with mock.patch.dict(CODE, replacements), contextlib.redirect_stdout(io.StringIO()):
            CODE["fetch"](self.root, args)
        self.assertEqual(len(invocations), 1)
        receipt = CODE["load"](session / "fetch.json")
        self.assertEqual(self.root / receipt["source_path"], invocations[0])
        self.assertEqual(partial.read_text(), "retain this failed attempt")
        self.assertEqual((session / "intent.json").read_bytes(), original_intent)
        events = [json.loads(line) for line in (session / "activity.jsonl").read_text().splitlines()]
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["elapsed_seconds"], 99.33)
        self.assertEqual(events[1]["prior_activity_seconds"], 99.33)

    def test_work_zone_accepts_new_independent_repo_and_rejects_remote(self):
        subprocess.run(["git", "init", "-q", str(self.root)], check=True)
        marker = self.root / ".local/workspace-role"
        marker.parent.mkdir()
        marker.write_text("work\n")
        self.assertEqual(CODE["zone"](self.root), "uncommitted")
        subprocess.run(["git", "-C", str(self.root), "remote", "add", "origin", "https://example.invalid/repo.git"], check=True)
        with self.assertRaisesRegex(ValueError, "remote"):
            CODE["zone"](self.root)
        # A failed role check leaves the configured remote untouched.
        actual = subprocess.check_output(["git", "-C", str(self.root), "remote", "get-url", "origin"], text=True)
        self.assertEqual(actual.strip(), "https://example.invalid/repo.git")

    def test_work_zone_rejects_linked_git_metadata(self):
        other = Path(self.directory.name) / "metadata"
        other.mkdir()
        (self.root / ".git").symlink_to(other, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "independent"):
            CODE["zone"](self.root)

    def test_stage_budget_uses_elapsed_ledger_and_does_not_reset(self):
        session = self.session(budget=12)
        with mock.patch.object(CODE["time"], "monotonic", side_effect=(100.0, 101.0, 102.0)):
            with CODE["stage"](self.root, session, "prepare", 10) as (run, left):
                (run / "diagnostic.txt").write_text("kept")
        receipt = CODE["load"](run / "run-manifest.json")
        self.assertEqual(receipt["elapsed_seconds"], 2)
        self.assertEqual(receipt["status"], "passed")
        with self.assertRaisesRegex(ValueError, "cumulative"):
            with CODE["stage"](self.root, session, "prepare", 11):
                self.fail("Budget exhaustion must precede stage work")
        self.assertEqual(len(list((self.root / "runs").iterdir())), 1)

    def test_stage_failure_keeps_diagnostics_and_charges_time(self):
        session = self.session()
        with mock.patch.object(CODE["time"], "monotonic", side_effect=(10.0, 14.0)):
            with self.assertRaisesRegex(RuntimeError, "fixture failure"):
                with CODE["stage"](self.root, session, "prepare", 20) as (run, left):
                    (run / "failure.log").write_text("original failure")
                    raise RuntimeError("fixture failure")
        receipt = CODE["load"](run / "run-manifest.json")
        self.assertEqual(receipt["status"], "failed")
        self.assertEqual(receipt["elapsed_seconds"], 4)
        self.assertEqual((run / "failure.log").read_text(), "original failure")
        self.assertFalse(list(session.glob("active-*.json")))
        self.assertIn('"elapsed_seconds": 4.0', (session / "activity.jsonl").read_text())

    def test_interrupted_or_concurrent_stage_cannot_start(self):
        session = self.session()
        CODE["save"](session / "active-prepare.json", {"unknown_elapsed": True})
        with self.assertRaisesRegex(ValueError, "interrupted"):
            with CODE["stage"](self.root, session, "prepare", 10):
                self.fail("An interrupted session may not reset its budget")
        (session / "active-prepare.json").unlink()
        with CODE["stage"](self.root, session, "prepare", 20):
            with self.assertRaises(BlockingIOError):
                with CODE["stage"](self.root, session, "prepare", 10):
                    self.fail("The session lock must serialize real operations")

    def test_stage_refuses_excessive_or_noninteger_allowance(self):
        session = self.session()
        for amount in (0, -1, 901, True, 1.5):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                with CODE["stage"](self.root, session, "prepare", amount):
                    self.fail("Invalid allowance must fail before work")

    def test_timeout_terminates_child_and_preserves_logs(self):
        prefix = self.root / "timeout"
        with self.assertRaises(subprocess.TimeoutExpired):
            CODE["execute"]([sys.executable, "-c", "import time; print('started', flush=True); time.sleep(5)"], prefix, 0.1)
        self.assertEqual(prefix.with_suffix(".stdout.log").read_text().strip(), "started")
        self.assertTrue(prefix.with_suffix(".stderr.log").is_file())

    def archive(self, items, name="input.tar.gz"):
        archive = self.root / name
        with tarfile.open(archive, "w:gz") as out:
            for logical, payload, link in items:
                info = tarfile.TarInfo(logical)
                if link is None:
                    info.size = len(payload)
                    out.addfile(info, io.BytesIO(payload))
                else:
                    info.type = tarfile.SYMTYPE
                    info.linkname = link
                    out.addfile(info)
        return archive

    def test_extract_selects_only_known_regular_raw_image(self):
        archive = self.archive([("noble-server-cloudimg-arm64.img", b"RAW0payload", None),
                                ("../escape", b"untrusted", None), ("ignored-link", b"", "../outside")])
        dest = self.root / "unpacked"
        result = CODE["extract_disk"](archive, dest)
        self.assertEqual(result.read_bytes(), b"RAW0payload")
        self.assertEqual(stat.S_IMODE(result.stat().st_mode), 0o444)
        self.assertEqual([p.name for p in dest.iterdir()], ["noble-server-cloudimg-arm64.img"])
        self.assertFalse((self.root / "escape").exists())

    def test_extract_rejects_links_duplicate_empty_and_qcow_images(self):
        filename = "noble-server-cloudimg-arm64.img"
        cases = [[(filename, b"", "outside")], [(filename, b"RAW0", None), (filename, b"RAW1", None)],
                 [(filename, b"", None)], [(filename, b"QFI\xfbextra", None)]]
        for index, entries in enumerate(cases):
            with self.subTest(index=index):
                archive = self.archive(entries, "input-%d.tar.gz" % index)
                with self.assertRaises(ValueError):
                    CODE["extract_disk"](archive, self.root / ("unpacked-%d" % index))

    def test_frozen_validation_uses_only_new_assets_not_historical_state(self):
        path, cfg = self.frozen_fixture()
        checker = mock.Mock(return_value={"files_verified": 222})
        with mock.patch.dict(CODE, {"modules": lambda root: {"suite": {"check_source": checker}}}):
            self.assertEqual(CODE["validate_frozen"](self.root, path), cfg)
        checker.assert_called_once_with(self.root / cfg["source_path"], cfg)
        self.assertFalse((self.root / "runs").exists())
        self.assertFalse((self.root / ".local").exists())

    def test_frozen_validation_rejects_changed_sources_and_writable_base(self):
        path, cfg = self.frozen_fixture()
        changed = self.root / next(iter(cfg["reproduction_bindings"]))
        original = changed.read_bytes()
        changed.write_bytes(original + b"tampered")
        with self.assertRaisesRegex(ValueError, "Source changed"):
            CODE["validate_frozen"](self.root, path)
        changed.write_bytes(original)
        (self.root / cfg["base_disk_path"]).chmod(0o644)
        with self.assertRaisesRegex(ValueError, "read-only"):
            CODE["validate_frozen"](self.root, path)

    def test_frozen_validation_rejects_historical_role_and_missing_binding(self):
        path, cfg = self.frozen_fixture()
        for changes in ({"collection_role": "confirmatory"}, {"execution_authorized": False},
                        {"reproduction_bindings": {}}):
            with self.subTest(changes=changes):
                value = {**cfg, **changes}
                path.write_text(json.dumps(value))
                with self.assertRaises(ValueError):
                    CODE["validate_frozen"](self.root, path)

    def test_incomplete_analysis_cannot_promote_campaign_to_complete(self):
        session = self.session(budget=2400)
        cfg = {"session": session.name, "campaign_id": "new-campaign", "campaign_budget_seconds": 1200,
               "experiment_id": "exp-001"}
        path = self.root / "config.json"
        CODE["save"](path, cfg)
        (self.root / "results").mkdir()
        incomplete = {"included_batch_slots": [0, 1], "missing_valid_batch_slots": [2],
                      "unresolved_deviations": ["bad seal"], "aggregate": None, "verdict": "inconclusive"}
        patches = {"zone": lambda root: "revision", "host": lambda root: {},
                   "validate_frozen": lambda root, path: cfg,
                   "batch": lambda root, path, cfg, slot, number, left, lib: self.root / ("batch-%d" % slot),
                   "modules": lambda root: {"analysis": {"analyze": lambda *a: incomplete}}}
        with mock.patch.dict(CODE, patches), self.assertRaises(ValueError):
            CODE["collect"](self.root, SimpleNamespace(config=path))
        self.assertFalse((self.root / "results/new-campaign/completion.json").exists())
        self.assertTrue((self.root / "results/new-campaign/stopped.json").is_file())

    def test_collect_creates_results_on_a_fresh_package_and_writes_complete_receipt(self):
        session = self.session(budget=3600)
        cfg = {"session": session.name, "campaign_id": "clean-main", "campaign_budget_seconds": 2400,
               "experiment_id": "exp-001", "collection_role": "independent_reproduction"}
        path = self.root / "config.json"
        CODE["save"](path, cfg)
        self.assertFalse((self.root / "results").exists())
        known_summary = {"included_batch_slots": [0, 1, 2], "missing_valid_batch_slots": [],
                         "unresolved_deviations": [], "verdict": "supported",
                         "aggregate": {"arithmetic_mean_runtime_ratio": {
                             "batch_values": [1.1, 1.2, 1.3], "mean": 1.2, "sample_sd": 0.1, "n": 3}}}
        batches = []

        def completed_fixture(root, path, cfg, slot, number, left, lib):
            run = root / "runs" / ("independent-fixture-%d" % number)
            run.mkdir()
            batches.append(run)
            return run

        analyze = mock.Mock(return_value=known_summary)
        replacements = {"zone": lambda root: "revision", "host": lambda root: {},
                        "validate_frozen": lambda root, path: cfg, "batch": completed_fixture,
                        "modules": lambda root: {"analysis": {"analyze": analyze}}}
        with mock.patch.dict(CODE, replacements), contextlib.redirect_stdout(io.StringIO()):
            CODE["collect"](self.root, SimpleNamespace(config=path))
        analyze.assert_called_once_with("exp-001", "clean-main", batches)
        output = self.root / "results/clean-main"
        self.assertEqual(CODE["load"](output / "summary.json"), known_summary)
        self.assertEqual(CODE["load"](output / "effective.json"), cfg)
        receipt = CODE["load"](output / "completion.json")
        self.assertEqual(receipt["status"], "complete")
        self.assertEqual(receipt["run_ids"], [run.name for run in batches])
        self.assertEqual(receipt["summary_sha256"], CODE["sha"](output / "summary.json"))
        self.assertEqual(receipt["config_sha256"], CODE["sha"](self.root / receipt["config_path"]))
        self.assertEqual(CODE["load"](session / "main.json")["completion_sha256"],
                         CODE["sha"](output / "completion.json"))
        self.assertFalse((output / "stopped.json").exists())

    def test_verify_refuses_self_consistent_but_incomplete_summary(self):
        output = self.root / "results/new-campaign"
        output.mkdir(parents=True)
        cfg_path = self.root / "config.json"
        CODE["save"](cfg_path, {"experiment_id": "exp-001"})
        incomplete = {"included_batch_slots": [0], "missing_valid_batch_slots": [1, 2],
                      "unresolved_deviations": [], "aggregate": None, "verdict": "inconclusive"}
        CODE["save"](output / "summary.json", incomplete)
        CODE["save"](output / "completion.json", {"status": "complete", "campaign_id": "new-campaign",
             "config_path": "config.json", "config_sha256": CODE["sha"](cfg_path),
             "run_ids": ["independent-batch-001"], "summary_sha256": CODE["sha"](output / "summary.json")})
        with mock.patch.dict(CODE, {"modules": lambda root: {"analysis": {"analyze": lambda *a: incomplete}}}):
            with self.assertRaises(ValueError), contextlib.redirect_stdout(io.StringIO()):
                CODE["verify"](self.root, SimpleNamespace(campaign="new-campaign"))


if __name__ == "__main__":
    unittest.main()
