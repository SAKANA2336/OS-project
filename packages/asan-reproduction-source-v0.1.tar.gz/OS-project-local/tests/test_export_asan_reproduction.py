"""Check public package boundaries and byte-exact provenance without a VM."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/export-asan-reproduction.py"
EXPORT = runpy.run_path(str(SCRIPT))


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / "source"
        self.root.mkdir()
        self.destination = self.base / "public"
        self.commit = "a" * 40

    def write(self, logical, data):
        target = self.root / logical
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data.encode() if isinstance(data, str) else data)
        return target

    def test_exports_only_allowlist_and_preserves_crlf_hashes(self):
        raw = b'{\r\n  "files": []\r\n}\r\n'
        self.write("workloads/lock.json", raw)
        self.write("docs/guide.md", "A public guide.\n")
        self.write(".local/private-secret.txt", "not exported")
        self.write("course.pdf", b"private input")
        entries = (("workloads/lock.json", "workloads/lock.json"), ("docs/guide.md", "README.md"))
        manifest = EXPORT["stage_package"](self.root, self.destination, self.commit, entries)
        self.assertEqual((self.destination / "workloads/lock.json").read_bytes(), raw)
        self.assertEqual(manifest["files"][0]["sha256"], sha256(raw).hexdigest())
        self.assertEqual({p.relative_to(self.destination).as_posix() for p in self.destination.rglob("*") if p.is_file()},
                         {"workloads/lock.json", "README.md", "package-manifest.json", *EXPORT["GENERATED_FILES"]})
        self.assertEqual(json.loads((self.destination / "package-manifest.json").read_text()), manifest)
        self.assertNotIn(str(self.root), (self.destination / "package-manifest.json").read_text())

    def test_root_readme_links_are_relocated_and_provenance_retains_source_hash(self):
        raw = b"[plan](../experiments/reproduction-001/PLAN.md) [self](reproduction.md#run) [web](https://example.com)\n"
        self.write("docs/reproduction.md", raw)
        entries = (("docs/reproduction.md", "README.md"), ("docs/reproduction.md", "docs/reproduction.md"))
        result = EXPORT["stage_package"](self.root, self.destination, self.commit, entries)
        readme = (self.destination / "README.md").read_text()
        self.assertIn("](experiments/reproduction-001/PLAN.md)", readme)
        self.assertIn("](docs/reproduction.md#run)", readme)
        self.assertIn("](https://example.com)", readme)
        self.assertEqual((self.destination / "docs/reproduction.md").read_bytes(), raw)
        self.assertEqual(result["files"][0]["source_sha256"], sha256(raw).hexdigest())
        self.assertEqual(result["files"][0]["transformation"], "resolve_relative_readme_links")

    def test_missing_input_fails_before_destination_creation(self):
        with self.assertRaisesRegex(ValueError, "missing"):
            EXPORT["stage_package"](self.root, self.destination, self.commit, (("scripts/missing.py", "scripts/missing.py"),))
        self.assertFalse(self.destination.exists())

    def test_existing_destination_is_untouched(self):
        self.write("docs/guide.md", "guide")
        self.destination.mkdir()
        retained = self.destination / "retained.txt"
        retained.write_text("retain this")
        with self.assertRaisesRegex(ValueError, "already exists"):
            EXPORT["stage_package"](self.root, self.destination, self.commit, (("docs/guide.md", "README.md"),))
        self.assertEqual(retained.read_text(), "retain this")
        self.assertEqual(list(self.destination.iterdir()), [retained])

    def test_sensitive_paths_binary_and_oversize_are_rejected(self):
        for value in ("../escape.py", "/escape.py", ".local/file.txt", ".ssh/id_rsa", "file.pdf", "dir/../escape.py"):
            with self.subTest(path=value), self.assertRaises(ValueError):
                EXPORT["logical_path"](value)
        self.write("scripts/binary.py", b"abc\0def")
        with self.assertRaisesRegex(ValueError, "Binary"):
            EXPORT["plan_export"](self.root, (("scripts/binary.py", "scripts/binary.py"),))
        target = self.write("docs/large.md", b"")
        with target.open("r+b") as stream:
            stream.truncate(EXPORT["MAX_FILE_BYTES"] + 1)
        with self.assertRaisesRegex(ValueError, "50 MB"):
            EXPORT["plan_export"](self.root, (("docs/large.md", "docs/large.md"),))

    def test_private_paths_keys_and_active_authorizations_are_rejected(self):
        contents = ["/" + "Users/fixture/private/source.py", "-----BEGIN " + "PRIVATE KEY-----",
                    json.dumps({"execution_authorized": True}),
                    json.dumps({"execution_authorization": {"run_id": "past-run"}})]
        for content in contents:
            with self.subTest(content=content), self.assertRaises(ValueError):
                EXPORT["check_content"](content.encode(), "config/input.json" if content.startswith("{") else "docs/input.md")

    def test_symlink_and_casefold_collisions_are_rejected(self):
        actual = self.write("docs/guide.md", "guide")
        (self.root / "docs/link.md").symlink_to(actual)
        with self.assertRaisesRegex(ValueError, "Symlink"):
            EXPORT["plan_export"](self.root, (("docs/link.md", "README.md"),))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            EXPORT["plan_export"](self.root, (("docs/guide.md", "README.md"), ("docs/guide.md", "readme.md")))

    def test_omitted_literal_runtime_dependency_is_rejected(self):
        self.write("scripts/driver.py", 'import runpy\nrunpy.run_path("scripts/guest.py")\n')
        entries = (("scripts/driver.py", "scripts/driver.py"),)
        with self.assertRaisesRegex(ValueError, "Missing local script dependencies"):
            EXPORT["plan_export"](self.root, entries)
        self.write("scripts/guest.py", "pass\n")
        self.assertEqual(len(EXPORT["plan_export"](self.root, entries + (("scripts/guest.py", "scripts/guest.py"),))),
                         2 + len(EXPORT["GENERATED_FILES"]))

    def test_sibling_runtime_dependency_is_rejected(self):
        self.write("scripts/driver.py", 'from pathlib import Path\nx = Path(__file__).with_name("helper.py")\n')
        with self.assertRaisesRegex(ValueError, "helper.py"):
            EXPORT["plan_export"](self.root, (("scripts/driver.py", "scripts/driver.py"),))

    def test_check_does_not_write_files(self):
        self.write("docs/guide.md", "guide")
        result = EXPORT["plan_export"](self.root, (("docs/guide.md", "README.md"),))
        self.assertEqual(result[0]["bytes"], 5)
        self.assertFalse(self.destination.exists())

    def test_reviewed_evidence_config_is_inert_and_matches_original_bytes(self):
        snapshot, original = next(iter(EXPORT["INERT_CONFIG_SNAPSHOTS"].items()))
        raw = json.dumps({"execution_authorized": True, "execution_authorization": {"run_id": "recorded"}}).encode()
        self.write(original, raw)
        self.write(snapshot, raw)
        result = EXPORT["stage_package"](self.root, self.destination, self.commit, ((snapshot, snapshot),))
        self.assertEqual(result["files"][0]["role"], "historical_evidence")
        self.assertEqual((self.destination / snapshot).read_bytes(), raw)
        self.assertFalse((self.destination / original).exists())
        self.write(snapshot, raw.replace(b"recorded", b"changed"))
        with self.assertRaisesRegex(ValueError, "differs from its recorded original"):
            EXPORT["plan_export"](self.root, ((snapshot, snapshot),))
        with self.assertRaisesRegex(ValueError, "Unreviewed"):
            EXPORT["check_content"](raw, "results/unreviewed.json.snapshot")

    def test_manifest_marks_historical_context_separately(self):
        self.write("docs/plan.md.snapshot", "Frozen original.\n")
        result = EXPORT["stage_package"](self.root, self.destination, self.commit,
                                        (("docs/plan.md.snapshot", "archive/2026-11-19-formal/plan.md.snapshot"),))
        self.assertEqual(result["files"][0]["role"], "historical_plan")


if __name__ == "__main__":
    unittest.main()
