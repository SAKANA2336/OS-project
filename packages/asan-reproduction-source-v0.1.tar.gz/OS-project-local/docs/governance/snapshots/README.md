# Frozen historical plan snapshots

Read these files as byte-exact records of the completed formal experiments. Their relative links describe the original repository layout. They are not active execution instructions, permission, or the new reproduction plan.

Use experiments/reproduction-001/PLAN.md and the reproduction guide for new runs. The package manifest records source and destination hashes.
